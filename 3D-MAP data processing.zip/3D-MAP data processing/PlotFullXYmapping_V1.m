clear all;close all;clc;

Foldername='12-30-19 in vivo good';
Xratio=0.676;%from calibration data
Yratio=0.676;%from calibration data
Zratio=1.2;
Filename='IUE_ChroME-BFP;mDlx-ChroME;P51_123019b_18_good';
cellNum='B';
load([Foldername '/' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;

UX=ToSave.Data.UX*Xratio;
UY=ToSave.Data.UY*Yratio;
Nz=size(ToSave.Data.XY,3);
NX=numel(UX);
NY=numel(UY);
% PXX=reshape(ToSave.Data.PXX*Xratio,[NX NY Nz]);
% PYY=reshape(ToSave.Data.PYY*Yratio,[NX NY Nz]);

repeatNum=size(ToSave.Data.XY,2);
VoltageNum=size(ToSave.Score,2);

Ind_ori=ToSave.Ind;

seqL=ToSave.Stim.Npeaks;
Score3D=zeros(NX,NY,repeatNum);
NumofSeq=size(ToSave.Data.XY,1);

S=zeros(NX,NY,Nz);
% t=linspace(0,0.003/150*465,465);
%%
for nz=Nz
    switch ToSave.Stim.FreqHZ 
        case 40
        DataMatrix3D=zeros(NX*NY,1230,repeatNum);
        case 50
        DataMatrix3D=zeros(NX*NY,980,repeatNum);
        case 80
        DataMatrix3D=zeros(NX*NY,605,repeatNum);
        case 100
        DataMatrix3D=zeros(NX*NY,480,repeatNum);
    end
for kk=0
    if kk==0
        ToSave.Ind=Ind_ori;
    else
        shiftN=kk;
        ToSave.Ind(1:shiftN,:)=Ind_ori(end-shiftN+1:end,:);
        ToSave.Ind(shiftN+1:end,:)=Ind_ori(1:end-shiftN,:);
    end
    
if ProcessData==1
    if repeatNum==1
        startpoint=1;
    else
        startpoint=2;
    end
    
    for j=startpoint:repeatNum
        for i=1:NumofSeq
                CurrentData=ToSave.Data.XY{i,j,nz};
                CurrentData=medfilt1(CurrentData,5);
%                 ToSave.Stim.baseline=mean(CurrentData(1:50));
                CurrentData=CurrentData.*ToSave.Stim.CropMask';
                CurrentData(CurrentData==0)=[];
                DataMatrix=reshape(CurrentData,[numel(CurrentData)/seqL,seqL]);
                DataMatrix=abs(DataMatrix');
                DataMatrix3D(1+(i-1)*seqL:i*seqL,:,j)=DataMatrix;
%                 if i==1 && j==1
%                     for p=11:seqL
%                        [ Score3D(ToSave.Ind(p-10,1),ToSave.Ind(p-10,2),j), odata,spikeremoveflag] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(p,:),spikeremoveflag);            
%                     end
%                 else
                 
                    for p=1:seqL
%                     figure(1);subplot(11,11,p);plot(t,DataMatrix(:,p));
%                     title(['repeat=' num2str(j) ' p=' num2str(p)]);
%                     flatten=linspace(mean(DataMatrix(1:20,p,j)),mean(DataMatrix(end-19:end,p,j)),1985);
%                     DataMatrix(:,p,j)=DataMatrix(:,p,j)./flatten';
                        cx=ToSave.Ind(p+(i-1)*seqL,1);
                        cy=ToSave.Ind(p+(i-1)*seqL,2);
                        if startpoint==1
                            [ Score3D(cx,cy,j), odata,~] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(p,:),spikeremoveflag);            
                        else
                            [ Score3D(cx,cy,j-1), odata,~] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(p,:),spikeremoveflag);            
                        end
                     end
%                 end
        end
    end
else
    Score3D=ToSave.Score;
end
DataMatrix2D=squeeze(mean(DataMatrix3D,3));
Score2D=mean(Score3D,3);
end
    S(:,:,nz)=Score2D;  

end

% title(num2str(kk));drawnow;

% figure();set(gcf, 'Position',  [0, 0,1300, 900]);
% for p=1:NX*NY
%     subplot = @(m,n,p) subtightplot (m, n, p);
%     q=sub2ind([NX,NY],ToSave.Ind(p,1),ToSave.Ind(p,2));
%     subplot(NX,NY,q);plot(DataMatrix2D(p,1:20:end));
%     ylim([min(DataMatrix2D(:)) max(DataMatrix2D(:))]);
%     axis off
%     disp(p);
% end
% dim = [0.1 0.66 0.3 0.3];
% str = {['ymin' num2str(min(DataMatrix2D(:))), ' ymax ' num2str(max(DataMatrix2D(:))), '. time(ms) ' num2str(ToSave.Stim.DurationMS)]};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% saveas(gcf,[Foldername '\' Filename 'trace' num2str(ProcessData) 'Z' num2str(ToSave.Data.UZ(nz)) '.tif']);

%% hot plot
figure();
set(gcf,'position',[100, 100, 500, 400]);
% subplot(1,2,1);
% imagesc(UX,UY,Score3D_random(:,:,5)');
% axis image;xlabel('x(\mum)');ylabel('y(\mum)');
% caxis([min(min(Score3D(:)),min(Score3D_random(:))),max(max(Score3D(:)),max(Score3D_random(:)))]);
% colormap('hot');
% set(gca,'fontsize',16);
% subplot(1,2,2);
% imagesc(UX,UY,Score3D(:,:,5)');
% axis image;
% caxis([min(min(Score3D(:)),min(Score3D_random(:))),max(max(Score3D(:)),max(Score3D_random(:)))]);
% colormap('hot');xlabel('x(\mum)');ylabel('y(\mum)');
% set(gca,'fontsize',16);

for nz=1:Nz
subplot(1,Nz,nz);
imagesc(UX,UY,S(:,:,nz)');
title(['Z = ' num2str(ToSave.Data.UZ(nz),2) '\mum']);
axis image;
xlabel('x(\mum)');ylabel('y(\mum)');
% set(gca,'fontsize',16);
% axis off;
caxis([min((S(:))) max((S(:)))]);
% colormap('hot');
end
saveas(gcf,[Foldername '\' Filename '_hotmap.fig']);
saveas(gcf,[Foldername '\' Filename '_hotmap.pdf']);
%%
logflag=1;

for nz=1:Nz
if logflag==1
    imagesc(UX,UY,log(S(:,:,nz))');
    title(['Cell ' cellNum ' [log]', ' r=' num2str(ToSave.Stim.TargetRadius), ' Z=' num2str(ToSave.Data.UZ(nz),2),' V=' num2str(ToSave.Stim.Voltage,2)]);
    caxis([min(log(S(:))) max(log(S(:)))]);
else
    imagesc(UX,UY,S(:,:,nz)');
    title(['Cell ' cellNum , ' r=' num2str(ToSave.Stim.TargetRadius), ' Z=' num2str(ToSave.Data.UZ(nz),2), ' V=' num2str(ToSave.Stim.Voltage,2)]);
    caxis([min(S(:)) max(S(:))]);
end
axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
colorbar;
set(gca,'FontSize',16);
saveas(gcf,[Foldername '/' Filename 'plot_Z' num2str(ToSave.Data.UZ(nz)) '.tif']);
saveas(gcf,[Foldername '/' Filename 'plot_Z' num2str(ToSave.Data.UZ(nz)) '.fig']);
end
save([Foldername '/MappingXY_' Filename '_' cellNum '.mat'],'S');

%% plot part of the region
Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
[indx_roi,indy_roi]=meshgrid(12:18,1:6);
Indaim=sub2ind([NX,NY],indx_roi(:),indy_roi(:));
[~,irandom,iroi] = intersect(Indrandom,Indaim,'sorted'); 
figure();set(gcf, 'Position',  [100, 100,size(indx_roi,2)*50, size(indx_roi,1)*50]);
for p=1:numel(Indaim)
    subplot = @(m,n,p) subtightplot (m, n, p);
subplot(size(indx_roi,1),size(indx_roi,2),p);
plot(DataMatrix2D(irandom(p),1:40:end));
% ylim([-0.8 -0.07]);
ylim([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
axis off
disp(p);
end
dim = [0.1 0.66 0.3 0.3];
str = {['ymin' num2str(min(min(DataMatrix2D(irandom,:)))), ' ymax ' num2str(max(max(DataMatrix2D(irandom,:)))), '. time(ms) ' num2str(ToSave.Stim.DurationMS)]};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
saveas(gcf,[Foldername '\' Filename 'trace_roi1_Z' num2str(ToSave.Data.UZ(nz)) '.fig']);
disp([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
%% plot seal test to check the condition of cell
sealtest=zeros(size(ToSave.Data.XY));
for j=1:repeatNum
    for nz=1:Nz
        for i=1:NumofSeq
            if isempty(ToSave.Data.XY{i,j,nz})
                continue;
            else
                temp=ToSave.Data.XY{i,j,nz};
                sealtest(i,j,nz)=max(temp(1:2500));
            end
        end
    end
end
sealtest1=permute(sealtest,[1,3,2]);
figure();plot(sealtest1(:));
axis tight;grid on; 
ylabel('mV');
xlabel('Seal test of each sequence');
saveas(gcf,[Foldername '\' Filename 'sealtest.fig']);


%%
% if ProcessData==1
%     SXY2D=reshape(mean(SXY,2),[numel(UX) numel(UY)]);
% else
%     SXY2D=mean(SXY,3);
% end
%%
% [~,Ind]=max(mean(SXY,2));
% if numel(Ind)>1
%     [~,ind]=min(abs(Ind-length(SXY)/2));
%     Ind=Ind(ind);
% end
% 
% [I,J]=ind2sub([length(UX) length(UY)],Ind);
%%
%  figure();imagesc(log(Score2D'));
row=10;col=38;startpoint=3;
Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
q=sub2ind([NX,NY],row,col);
[v]=find(Indrandom==q);
A=DataMatrix3D(v,:,:);
A=squeeze(A);
if startpoint==1
    A=A';
end
t=0:ToSave.Stim.UT(2):ToSave.Stim.UT(2)*(size(A,1)-1);
[~,peak]=max(abs(mean(A(:,startpoint:end),2)));
a1=mean(A(peak:end,startpoint:end),2);
t1=t(peak:end)';
[fitresult, gof] = function_createMonoExpFit(t1, abs(a1));
temp=coeffvalues(fitresult);tau=-1000/temp(2);%exponential decay time
A=medfilt1(A,50);

figure();
for i=startpoint:repeatNum
    A(1:10,i)=A(11,i);
    A(1210:end,i)=A(1209,i);
    plot(t*1000,-(A(:,i)*1000-min(A(12:100,i)*1000)),'color',[1-i/repeatNum, 0, i/repeatNum]);hold on;
end
hold off
% set(gca,'position',[200 200,300,200]);
% dim = [0.7 0.6 0.3 0.3];
% str = {['\tau=' num2str(tau) 'ms']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
xlim([min(t*1000) max(t*1000)]);
xlabel('time (ms)');ylabel('I (pA)');
ylim([-47,1]);
% grid on;
set(gca,'FontSize',32);
 saveas(gcf,[Foldername '\' Filename 'one_trace_' num2str(row) '_' num2str(col) '_Z' num2str(ToSave.Data.UZ(nz)) 'V2.6.pdf']);
 %% plot decay time map
 DecayTimeMap=zeros(NX,NY);
 startpoint=2;
 
 for yy=1:NY
     for xx=1:NX
        row=xx;col=yy;
        Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
        q=sub2ind([NX,NY],row,col);
        [v]=find(Indrandom==q);
        A=DataMatrix3D(v,:,:);
        A=squeeze(A);
        if startpoint==1
            A=A';
        end
        [peakVal,peak]=max(abs(mean(A(:,startpoint:end),2)));
        baseline=A(1:10,startpoint:end);
        if peakVal<abs(mean(baseline(:)))+0.08
            tau=nan;
        else
            a1=mean(A(peak:end,startpoint:end),2);
            t=0:ToSave.Stim.UT(2):ToSave.Stim.UT(2)*(size(A,1)-1);
            t1=t(peak:end)';
            [fitresult, gof] = function_createMonoExpFit(t1, abs(a1));
            temp=coeffvalues(fitresult);tau=-1000/temp(2);%exponential decay time
        end
        DecayTimeMap(col,row)=tau;
     end
 end
 figure();
 imagesc(UX,UY,DecayTimeMap);
axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
colorbar;
set(gca,'FontSize',16);
title(['Decay time map (ms), Z=' num2str(ToSave.Data.UZ(nz))]);
saveas(gcf,[Foldername '/' Filename 'DecayTimePlot_Z' num2str(ToSave.Data.UZ(nz)) '.tif']);
saveas(gcf,[Foldername '/' Filename 'DecayTimePlot_Z' num2str(ToSave.Data.UZ(nz)) '.fig']);
