% plot 1D photocurrent data
clear all;close all;clc

Foldername='9-27-19BrainSlice-PCH';
Xratio=0.676;%from calibration data
Zratio=0.888;
Filename='Dummy_File_4505_2_';
cellNum='X';
load([Foldername '\' Filename '.mat']);
%%
ProcessData=0;
Setup.Scorepikes.Method=0;
UX=ToSave.Data.UX*Xratio;
UZ=ToSave.Data.UZ*Zratio;
if ProcessData==1
    for j=1:size(ToSave.Data.X,2)
        for i=1:size(ToSave.Data.X,1)            
            [ SX(i,j), ~] = function_score_voltageclamp( Setup,ToSave.Stim,-cell2mat(ToSave.Data.X(i,j)));
            [ SZ(i,j), ~] = function_score_voltageclamp( Setup,ToSave.Stim,-cell2mat(ToSave.Data.Z(i,j)));
        end
    end
else
    SX=cell2mat(ToSave.Data.SX);
    SZ=cell2mat(ToSave.Data.SZ);
end
[GaussianX, gofx] = createFit(UX', mean(SX,2)-min(mean(SX,2)));
[GaussianZ, gofz] = createFit(UZ', mean(SZ,2)-min(mean(SZ,2)));
FWHMx=FWHMofGaussian( GaussianX, UX );
FWHMz=FWHMofGaussian( GaussianZ, UZ );

figure();
set(gcf, 'Position',  [300, 300, 1000, 400])
subplot(1,2,1);plot(GaussianX, UX, mean(SX,2)-min(mean(SX,2)));title(['Cell ' cellNum ' : X PPSF']);
grid on;xlim([min(UX) max(UX)]);xlabel('X (\mum)');
dim = [0.14 0.6 0.3 0.3];
str = {['FWHMx=' num2str(FWHMx) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');

subplot(1,2,2);plot(GaussianZ, UZ, mean(SZ,2)-min(mean(SZ,2)));title(['Cell ' cellNum ' : Z PPSF']);
grid on;xlim([min(UZ) max(UZ)]);xlabel('Z (\mum)');
dim = [0.58 0.6 0.3 0.3];
str = {['FWHMz=' num2str(FWHMz) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
%%
saveas(gcf,[Foldername '\' Filename 'plot.tif']);
saveas(gcf,[Foldername '\' Filename 'plot.fig']);
save([Foldername '\Current1D_' Filename '_' cellNum '.mat'],'SX','SZ','UX','UZ','GaussianX','GaussianZ');
