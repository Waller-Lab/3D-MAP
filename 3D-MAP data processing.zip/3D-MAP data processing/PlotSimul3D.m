clear all;close all;clc

Foldername='11-20-19 BrainSlice_exc';
Xratio=0.676;%from calibration data
Yratio=0.676;%from calibration data
Zratio=1.2;
Filename='emx_cre_ChromeS273A_112019h_simul3D_2';
cellNum='H';
load([Foldername '\' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;
t=ToSave.Stim.UUT;
beginning=min(find(t>ToSave.Stim.DelayBorder));

repeatNum=size(ToSave.Data.MultiTargets,3);
groupNum=size(ToSave.Data.MultiTargets,2);
Datatemp=zeros(repeatNum,numel(ToSave.Stim.UUT));
%%
    for i=1:groupNum
        A=cell2mat(ToSave.Stim.IndComb(1,i));
        caseNum=size(A,1);
        for k=1:caseNum
            for j=2:repeatNum
                Datatemp(j-1,:)=cell2mat(ToSave.Data.MultiTargets(k,i,j-1));
            end
            Data=mean(Datatemp,1);Data=Data-max(Data);
            figure(i);subplot(caseNum,1,k);plot(ToSave.Stim.UUT,Data);
            title([num2str(A(k,:))]);
            set(gcf,'Position',[100,100,200,900]);
        end
    end
%% compare linear sum vs potential network effect
%single stimulate
groupNum=5;
A=cell2mat(ToSave.Stim.IndComb(1,groupNum));
% caseNum=size(A,1);
caseNum=1;
Datatemp=zeros(caseNum,repeatNum,5200);
k=1;
for n=1
    for j=1:repeatNum
        Datatemp(k,j,:)=cell2mat(ToSave.Data.MultiTargets(n,groupNum,j));
    end
    Data=squeeze(mean(Datatemp,2));
    k=k+1;
end

%% check repeatance
for k=1:caseNum
    figure(k);
    for j=1:repeatNum
        plot(squeeze(Datatemp(k,j,:))-max(Datatemp(k,j,:)));hold on;
    end
end
%%
Data=squeeze(mean(Datatemp(:,2:repeatNum,:),2));% remove the first trial
figure();set(gcf,'Position',[100,100,300,900]);
for k=1:caseNum
    subplot(5,1,k);
    Data(k,:)=Data(k,:)-max(Data(k,:));
    temp=medfilt1(Data(k,beginning:end),10);
    plot(temp(5:end-5));ylim([-0.150,0]);
%     
end
saveas(gcf,[Foldername '\' Filename '_1_2andNROI_combo3.pdf'],'pdf');
%%
figure();
% temp=sum(Data1(1:5,:));
% temp=temp-mean(temp(100:beginning-10));
% temp=medfilt1(temp,10);
% temp=temp-0.0047;

plot(t(1:end-4-beginning)*1000,temp(beginning:end-5)*1000);
hold on
% Data=Data-mean(Data(100:beginning-10));
% Data=medfilt1(Data,10);
plot(t(1:end-4-beginning)*1000,Data(beginning:end-5)*1000);

ylim([-150,10]);xlim([0,63.77]);
set(gca,'fontsize',24);
legend('linear sum','actual data');
saveas(gcf,[Foldername '\' Filename 'compare.pdf'],'pdf');

%%
IndComb{1,1}=[1;2;3;4;5];
IndComb{1,2}=[1,2;1,3;1,4;1,5;2,3;2,4;2,5;3,4;3,5;4,5];
IndComb{1,3}=[1,2,3;1,2,4;1,2,5;1,3,4;1,3,5;1,4,5;2,3,4;2,3,5;2,4,5;3,4,5];
IndComb{1,4}=[1,2,3,4;1,2,3,5;1,2,4,5;1,3,4,5;2,3,4,5];
IndComb{1,5}=[1,2,3,4,5];
%%
for i=5
    A=cell2mat(IndComb(1,i));
%     caseNum=size(A,1);
    k=1;
    for n=1
        for j=2:repeatNum
            Datatemp1(j-1,:)=cell2mat(ToSave.Data.MultiTargets(n,i,j));
            Datatemp1(j-1,:)=Datatemp1(j-1,:)-mean(Datatemp1(j-1,1:1800));
        end
        S(i,k)=trapz(mean(Datatemp1(:,2000:4000),1))/50000;
%         S(i,k)=sum(mean(Datatemp1,1)-mean(mean(Datatemp1(:,1:1800),1)));
        if i==1
            Data(k,:)=mean(Datatemp1,1)-mean(mean(Datatemp1(:,1:1800),1));
            Slinear(i,k)=S(i,k);
        else
            temp=Data(A(k,:),2000:4000)';
            Slinear(i,k)=sum(trapz(temp)/50000);
%             Slinear(i,k)=sum(sum(Data(A(k,:),:))-mean(sum(Data(A(k,:),1:1800))));
        end
%         figure(100);plot(mean(Datatemp1,1)-mean(mean(Datatemp1(:,1:1800),1)));
%         hold on;plot(sum(Data(A(k,:),:))-mean(sum(Data(A(k,:),1:1800))));
%         hold off;
%         drawnow;
        k=k+1;
    end
end
%%
% % S=S_ori;
% S=-S;
% Slinear_ori=Slinear;
% Slinear=-Slinear;
% S=S*1000;
% Slinear=Slinear*1000;
Smean=[mean(S(1,1:5)),mean(S(2,1:10)),mean(S(3,1:10)),mean(S(4,1:5)),mean(S(5,1))];
Sstd=[std(S(1,1:5)),std(S(2,1:10)),std(S(3,1:10)),std(S(4,1:5)),std(S(5,1))];
% figure();plot(-S,'bo','MarkerSize',6);hold on;plot(-Slinear,'r*','MarkerSize',6);
Slinearmean=[mean(Slinear(1,1:5)),mean(Slinear(2,1:10)),mean(Slinear(3,1:10)),mean(Slinear(4,1:5)),mean(Slinear(5,1))];
Slinearstd=[std(Slinear(1,1:5)),std(Slinear(2,1:10)),std(Slinear(3,1:10)),std(Slinear(4,1:5)),std(Slinear(5,1))];

figure();errorbar(Smean,Sstd,'o');hold on;
errorbar(Slinearmean,Slinearstd,'ro');
set(gca,'fontsize',24);
xlabel('Number of foci');
ylabel('pC');
legend('actual data','linear sum');
saveas(gcf,[Foldername '\' Filename '_simulvslinear_group1-5_pC.pdf'],'pdf');
saveas(gcf,[Foldername '\' Filename '_simulvslinear_group1-5_pC.fig'],'fig');

save([Foldername '\' Filename '_S_Slinear_group1-5_pC.mat'],'S','Slinear','Smean','Slinearmean','Sstd','Slinearstd','IndComb');
%% anova test
% S1=S';
% S1(S1==0)=[];
% Slinear1=Slinear';
% Slinear1(Slinear1==0)=[];

[P,table]=anova2([S1(17:end)',Slinear1(17:end)'],15,'on');
