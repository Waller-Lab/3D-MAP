clear all;close all;clc;
%%
Foldername='12-30-19 in vivo good';
Xratio=0.676;%from calibration data
Yratio=0.676;%from calibration data
Zratio=1;
Filename='IUE_ChroME-BFP;mDlx-ChroME;P51_123019b_18_good';
cellNum='B';
load([Foldername '/' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;

UX=ToSave.Data.UX*Xratio;
UY=ToSave.Data.UY*Yratio;
Nz=size(ToSave.Data.XY,3);
NX=numel(UX);
NY=numel(UY);
% PXX=reshape(ToSave.Data.PXX*Xratio,[NX NY Nz]);
% PYY=reshape(ToSave.Data.PYY*Yratio,[NX NY Nz]);

repeatNum=size(ToSave.Data.XY,2);
VoltageNum=size(ToSave.Score,2);

Ind_ori=ToSave.Ind;

seqL=ToSave.Stim.Npeaks;
Score3D=zeros(NX,NY,repeatNum);
NumofSeq=size(ToSave.Data.XY,1);

Score4D=zeros(NX,NY,Nz,VoltageNum);
% t=linspace(0,0.003/150*465,465);
%%
for v=1
    S=zeros(NX,NY,Nz);
    for nz=1
        switch ToSave.Stim.FreqHZ 
            case 40
            DataMatrix3D=zeros(NX*NY,1230,repeatNum);
            case 50
            DataMatrix3D=zeros(NX*NY,980,repeatNum);
            case 80
            DataMatrix3D=zeros(NX*NY,595,repeatNum);
            case 100
            DataMatrix3D=zeros(NX*NY,480,repeatNum);
        end
    for kk=0
        if kk==0
            ToSave.Ind=Ind_ori;
        else
            shiftN=kk;
            ToSave.Ind(1:shiftN,:)=Ind_ori(end-shiftN+1:end,:);
            ToSave.Ind(shiftN+1:end,:)=Ind_ori(1:end-shiftN,:);
        end

    if ProcessData==1
        if repeatNum==1
            startpoint=1;
        else
            startpoint=2;
        end

        for j=startpoint:repeatNum
            for i=1:NumofSeq
                    CurrentData=ToSave.Data.XY{i,j,nz,v};
                    CurrentData=medfilt1(CurrentData,5);
    %                 ToSave.Stim.baseline=mean(CurrentData(1:50));
                    CurrentData=CurrentData.*ToSave.Stim.CropMask';
                    CurrentData(CurrentData==0)=[];
                    DataMatrix=reshape(CurrentData,[numel(CurrentData)/seqL,seqL]);
                    DataMatrix=DataMatrix';
                    DataMatrix3D(1+(i-1)*seqL:i*seqL,:,j)=DataMatrix;
    %                 if i==1 && j==1
    %                     for p=11:seqL
    %                        [ Score3D(ToSave.Ind(p-10,1),ToSave.Ind(p-10,2),j), odata,spikeremoveflag] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(p,:),spikeremoveflag);            
    %                     end
    %                 else

                        for p=1:seqL
    %                     figure(1);subplot(11,11,p);plot(t,DataMatrix(:,p));
    %                     title(['repeat=' num2str(j) ' p=' num2str(p)]);
    %                     flatten=linspace(mean(DataMatrix(1:20,p,j)),mean(DataMatrix(end-19:end,p,j)),1985);
    %                     DataMatrix(:,p,j)=DataMatrix(:,p,j)./flatten';
                            cx=ToSave.Ind(p+(i-1)*seqL,1);
                            cy=ToSave.Ind(p+(i-1)*seqL,2);
                            if startpoint==1
                                [ Score3D(cx,cy,j), odata,~] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(p,:),spikeremoveflag);            
                            else
                                [ Score3D(cx,cy,j-1), odata,~] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(p,:),spikeremoveflag);            
                            end
                         end
    %                 end
            end
        end
    else
        Score3D=ToSave.Score;
    end
    DataMatrix2D=squeeze(mean(DataMatrix3D,3));
    Score2D=mean(Score3D,3);
    end
    S(:,:,nz)=Score2D;  
    end
    Score4D(:,:,:,v)=S;
end
%%
figure(100);
set(gcf,'Position',[50,50,Nz*200,(VoltageNum)*200]);
for v=1:VoltageNum
    for nz=1:Nz
        subplot = @(m,n,p) subtightplot (m, n, p);
        subplot(VoltageNum,Nz,(v-1)*Nz+nz);
        imagesc(UX,UY,Score4D(:,:,nz,v)');
%         colormap('hot');
%         title(['r=' num2str(ToSave.Stim.TargetRadius), ' Z=' num2str(ToSave.Data.UZ(nz),2),' V=' num2str(ToSave.Stim.Voltageramp(v),2)]);
        caxis([min(Score4D(:)) max(Score4D(:))]);
        axis image;
%         axis off
        xlabel('X (\mum)');ylabel('Y (\mum)');
    end
end
saveas(gcf,[Foldername '/' Filename 'plot_allvoltage_allZ_hotmap.pdf']);
saveas(gcf,[Foldername '/' Filename 'plot_allvoltage_allZ_hotmap.fig']);
% save([Foldername '/MappingXY_' Filename '_' cellNum '.mat'],'Score4D');
%% plot part of the region
Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
[indx_roi,indy_roi]=meshgrid(1:20,1:20);
Indaim=sub2ind([NX,NY],indx_roi(:),indy_roi(:));
[~,irandom,iroi] = intersect(Indrandom,Indaim,'sorted'); 
figure();set(gcf, 'Position',  [100, 100,size(indx_roi,2)*50, size(indx_roi,1)*50]);
for p=1:numel(Indaim)
    subplot = @(m,n,p) subtightplot (m, n, p);
subplot(size(indx_roi,1),size(indx_roi,2),p);
plot(DataMatrix2D(irandom(p),1:40:end));
% ylim([-0.8 -0.07]);
ylim([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
axis off
disp(p);
end
dim = [0.1 0.66 0.3 0.3];
str = {['ymin' num2str(min(min(DataMatrix2D(irandom,:)))), ' ymax ' num2str(max(max(DataMatrix2D(irandom,:)))), '. time(ms) ' num2str(ToSave.Stim.DurationMS)]};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
saveas(gcf,[Foldername '\' Filename 'trace_roi1_Z' num2str(ToSave.Data.UZ(nz)) '.fig']);
disp([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
%%
sealtest=zeros(size(ToSave.Data.XY));
for v=1:VoltageNum
    for j=1:repeatNum
        for nz=1:Nz
            for i=1:NumofSeq
                if isempty(ToSave.Data.XY{i,j,nz,v})
                    continue;
                else
                    temp=ToSave.Data.XY{i,j,nz,v};
                    sealtest(i,j,nz,v)=max(temp(1:2500))-mean(temp(2000:2400));
                end
            end
        end
    end
end
sealtest1=permute(sealtest,[1,3,2,4]);
figure();plot(sealtest1(:));
axis tight;grid on; 
ylabel('mV');
xlabel('Seal test of each sequence');
saveas(gcf,[Foldername '\' Filename 'sealtest.fig']);
%%
%  figure();imagesc(log(Score2D'));
row=8;col=9;startpoint=2;
Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
q=sub2ind([NX,NY],row,col);
[v1]=find(Indrandom==q);
A=DataMatrix3D(v1,:,:);
A=squeeze(A);
if startpoint==1
    A=A';
end
t=0:ToSave.Stim.UT(2):ToSave.Stim.UT(2)*(size(A,1)-1);
[~,peak]=max(abs(mean(A(:,startpoint:end),2)));
a1=mean(A(peak:end,startpoint:end),2);
t1=t(peak:end)';
[fitresult, gof] = function_createMonoExpFit(t1, abs(a1));
temp=coeffvalues(fitresult);tau=-1000/temp(2);%exponential decay time

figure();set(gcf,'position',[100,100,400,300]);
% for i=startpoint:repeatNum
%     plot(t,A(:,i),'color',[1-i/repeatNum, 0, i/repeatNum]);hold on;
% end
% hold off
plot(t*1000,(mean(A,2)-min(mean(A,2)))*1000,'linewidth',1);
% dim = [0.7 0.6 0.3 0.3];
% str = {['\tau=' num2str(tau) 'ms']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
xlim([min(1000*t) max(t*1000)]);
xlabel('time (ms)');ylabel('I (pA)');
ylim([0 80]);
% grid on;
set(gca,'FontSize',20);
saveas(gcf,[Foldername '\' Filename 'one_trace_ave' num2str(row) '_' num2str(col) '_Z' num2str(ToSave.Data.UZ(nz)) 'v' num2str(ToSave.Stim.Voltageramp(v)) '.pdf']);
saveas(gcf,[Foldername '\' Filename 'one_trace_ave' num2str(row) '_' num2str(col) '_Z' num2str(ToSave.Data.UZ(nz)) 'v' num2str(ToSave.Stim.Voltageramp(v)) '.fig']);
 %% plot decay time map
 DecayTimeMap=zeros(NX,NY);
 startpoint=2;
 
 for yy=1:NY
     for xx=1:NX
        row=xx;col=yy;
        Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
        q=sub2ind([NX,NY],row,col);
        [v]=find(Indrandom==q);
        A=DataMatrix3D(v,:,:);
        A=squeeze(A);
        if startpoint==1
            A=A';
        end
        [peakVal,peak]=max(abs(mean(A(:,startpoint:end),2)));
        baseline=A(1:10,startpoint:end);
        if peakVal<abs(mean(baseline(:)))+0.08
            tau=nan;
        else
            a1=mean(A(peak:end,startpoint:end),2);
            t=0:ToSave.Stim.UT(2):ToSave.Stim.UT(2)*(size(A,1)-1);
            t1=t(peak:end)';
            [fitresult, gof] = function_createMonoExpFit(t1, abs(a1));
            temp=coeffvalues(fitresult);tau=-1000/temp(2);%exponential decay time
        end
        DecayTimeMap(col,row)=tau;
     end
 end
 figure();
 imagesc(UX,UY,DecayTimeMap);
axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
colorbar;
set(gca,'FontSize',16);
title(['Decay time map (ms), Z=' num2str(ToSave.Data.UZ(nz))]);
saveas(gcf,[Foldername '/' Filename 'DecayTimePlot_Z' num2str(ToSave.Data.UZ(nz)) '.tif']);
saveas(gcf,[Foldername '/' Filename 'DecayTimePlot_Z' num2str(ToSave.Data.UZ(nz)) '.fig']);
