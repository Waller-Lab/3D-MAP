% temporal optimization plot
clear all;close all;clc
Foldername='1-23-20 CHO temporaloptimization';
Filename='CHO_Chrmine_012320b_12_';
cellNum='B';
load([Foldername '/' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;

t=ToSave.Stim.Timeramp;
repeatNum=size(ToSave.Data,2);
TimeNum=size(ToSave.Data,1);
Score=zeros(TimeNum,repeatNum);
%%
starttime=240000;
endtime=270000;
for j=1:2
    for i=1:TimeNum
        [Score(i,j),~,~]=function_score_voltageclamp( Setup,ToSave.Stim,cell2mat(ToSave.Data(i,j)),spikeremoveflag);
        if j==1
        temp=cell2mat(ToSave.Data(i,j))-max(cell2mat(ToSave.Data(i,j)));
        figure(100);plot(ToSave.Stim.UUT(starttime:endtime)-ToSave.Stim.UUT(starttime),medfilt1(temp(starttime:endtime),100),'color',[1-i/TimeNum,0,i/TimeNum]);hold on;
        end
    end
end
xlim([0.001 ToSave.Stim.UUT(endtime)-ToSave.Stim.UUT(starttime)]);
xlabel('time (s)');ylabel('Photocurrent (nA)');
set(gca,'FontSize',16);
hold off
saveas(gcf,[Foldername '\' Filename '_temporalOptimizationTest_data.fig']);
saveas(gcf,[Foldername '\' Filename '_temporalOptimizationTest_data.pdf']);

figure();
if repeatNum==1
    t=t(1:numel(Score));
    plot(t*1000,Score,'LineWidth',2);
else
    errorbar(t*1000,mean(Score,2),std(Score,[],2),'o-','MarkerSize',6,...
    'MarkerEdgeColor','blue','MarkerFaceColor','blue','LineWidth',1);
end
xlim([min(t*1000) max(t*1000)]);
xlabel('time(ms)');ylabel('|Photocurrent|(nA)');
title(['Stim.Power ' num2str(ToSave.Stim.Voltage), ' r=' num2str(ToSave.Stim.TargetRadius)]);
set(gca,'FontSize',16);
saveas(gcf,[Foldername '\' Filename '_temporalOptimizationTest.fig']);
saveas(gcf,[Foldername '\' Filename '_temporalOptimizationTest.pdf']);