% plot 3D PPSF from random measurement, need to import ind
clear all;close all;clc

Foldername='10-4-19 BrainSlice';
Xratio=0.676;%from calibration data
Yratio=0.676;
Zratio=1.22;
Filename='10-4-19-BrainSlice-A-3Drandom_5_good';
subfoldername='10-4-19-BrainSlice-A-3Drandom_5_good_new';
cellNum='A';
load([Foldername '\' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;

load('MaskCoordinates/Indnew.mat');
Ind=Indnew;
%%
% for i=1:121
% figure(1)
% plot(cell2mat(ToSave.Data.XYZ(i,1)));
% pause(1);
% end

%% 
UX=ToSave.Data.UX*Xratio;
UY=ToSave.Data.UY*Yratio;
UZ=ToSave.Data.UZ*Zratio;
Nx=numel(ToSave.Data.UX);
Ny=numel(ToSave.Data.UY);
Nz=numel(ToSave.Data.UZ);
seqL=21;% according to ind, 11x11x21
Score4D=zeros(Nx,Ny,Nz,size(ToSave.Data.XYZ,2));
%%
% CropMask=zeros(size(ToSave.Stim.CropMask'));
% for i=1:seqL
%     CropMask=CropMask+(ToSave.Stim.UUT'>=0.0098+(i-1)/ToSave.Stim.FreqHZ).*(ToSave.Stim.UUT'<=0.0098+i/ToSave.Stim.FreqHZ);
%     if nnz(CropMask)==1999
%         disp(i);
%     end
%         
% %     figure(1);plot(ToSave.Stim.UUT',CropMask);title([num2str(nnz(CropMask))]);drawnow;
% end

%%
CropMask=ToSave.Stim.CropMask';
    for j=1:size(ToSave.Data.XYZ,2)
        if find(cellfun(@isempty,ToSave.Data.XYZ(:,j)))
            break;
        else
            for i=1:size(ToSave.Data.XYZ,1)
                ToSave.Stim.baseline=mean((1-CropMask).*cell2mat(ToSave.Data.XYZ(i,j)));
                Data=-cell2mat(ToSave.Data.XYZ(i,j));
                Data=Data.*CropMask;
                Data(Data==0)=[];
                DataMatrix=reshape(Data,[numel(Data)/seqL,seqL]);
                for k=1:seqL
                    [ Score4D(Ind(k+(i-1)*seqL,1),Ind(k+(i-1)*seqL,2),Ind(k+(i-1)*seqL,3),j), odata,spikeremoveflag] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(:,k),spikeremoveflag);          
                end
            end
        end
    end

%%
S=mean(Score4D,4);
% imshow3D( S);

%%
for i=1:seqL
figure();
set(gcf, 'Position',  [300, 300,500, 400])
imagesc(UX,UY,S(:,:,i));
title(['Cell ' cellNum ' : XYZ PPSF, Z=' num2str(UZ(i))]);
axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
caxis([min(S(:)), max(S(:))]);
colorbar;
set(gca,'FontSize',16);pause(1);
% saveas(gcf,[Foldername '\' subfoldername '\' Filename 'plot_processData' num2str(i) '.tif']);
end
% %% get diagonal from the peak
% x=(I-J+1):size(SXZ2D,1);
% y=1:length(x);
% for k=1:length(x)
%     diagSXZ(k)=SXZ2D(x(k),y(k));
% end
% d=sqrt((UX(1)-UX(2))^2+(UZ(1)-UZ(2))^2);
% UXZ=-(J-1)*d:d:(length(x)-J)*d;
%     
% [GaussianXZ, gofxz] = createFit(UXZ(4:6), diagSXZ(4:6));
% FWHMxz=FWHMofGaussian( GaussianXZ, UXZ );
% %%
% figure();
% set(gcf, 'Position',  [300, 300,1000, 400])
% subplot(1,2,1);
% imagesc(UX,UZ,SXZ2D');
% title(['Cell ' cellNum ' : XZ PPSF']);
% axis image;xlabel('X (\mum)');ylabel('Z (\mum)');
% colorbar;
% set(gca,'FontSize',16);
% 
% subplot(1,2,2);plot(GaussianXZ, UXZ, diagSXZ);title(['Cell ' cellNum ' : diag XZ PPSF']);
% grid on;xlim([min(UZ) max(UZ)]);xlabel('XZ (\mum)');
% dim = [0.58 0.6 0.3 0.3];
% str = {['FWHMxz=' num2str(FWHMxz) '\mum']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% dim = [0.4 0.7 0.3 0.3];
% str = {['Repeat ' num2str(size(SXZ,2)) ', spikeremove=' num2str(spikeremoveflag)]};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
%%
% save([Foldername '\FullXYZscore_' Filename '_' cellNum '.mat'],'ToSave');
%% fitting to Gaussian
% S=ToSave.Score;
[~,Indmax]=max(S(:));
[indx,indy,indz]=ind2sub([Nx,Ny,Nz],Indmax);
SX=squeeze(S(:,indy,indz))-min(squeeze(S(:,indy,indz)));
SY=squeeze(S(indx,:,indz))-min(squeeze(S(indx,:,indz)));
SZ=squeeze(S(indx,indy,:))-min(squeeze(S(indx,indy,:)));
SX10=SX/max(SX);SY10=SY/max(SY);SZ10=SZ/max(SZ);
%%
[GaussianX, gofx] = createFit(UX', SX10);
[GaussianY, gofy] = createFit(UY', SY10*0.99);
[GaussianZ, gofz] = createFit(UZ', SZ10*0.96);
FWHMx=FWHMofGaussian( GaussianX, UX );
FWHMy=FWHMofGaussian( GaussianY, UY );
FWHMz=FWHMofGaussian( GaussianZ, UZ );
%% 
% k=0;
% save([Foldername '\U' num2str(k) '.mat'],'UX' ,'UY' ,'UZ' );
%%
figure();
set(gcf, 'Position',  [300, 300, 1200, 400])
subplot(1,3,1);plot(GaussianX, UX, SX10);
% title(['Cell ' cellNum ' : X PPSF']);
grid on;xlim([min(UX) max(UX)]);xlabel('X (\mum)');ylabel('Photocurrent (norm.)');
% dim = [0.14 0.6 0.3 0.3];
% str = {['FWHMx=' num2str(FWHMx) '\mum']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
legend off;
ylim([0,1]);set(gca,'FontSize',16);

subplot(1,3,2);plot(GaussianY, UY, SY10);
% title(['Cell ' cellNum ' : Y PPSF']);
grid on;xlim([min(UX) max(UX)]);xlabel('Y (\mum)');ylabel('Photocurrent (norm.)');
% dim = [0.42 0.6 0.3 0.3];
% str = {['FWHMy=' num2str(FWHMy) '\mum']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
legend off;
ylim([0,1]);set(gca,'FontSize',16);

subplot(1,3,3);plot(GaussianZ, UZ, SZ10);
% title(['Cell ' cellNum ' : Z PPSF']);
grid on;xlim([UZ(5) max(UZ)]);xlabel('Z (\mum)');ylabel('Photocurrent (norm.)');
% dim = [0.7 0.6 0.3 0.3];
% str = {['FWHMz=' num2str(FWHMz) '\mum']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
legend off;
ylim([0,1]);
set(gca,'FontSize',16);
%%
figure();
set(gcf, 'Position',  [300, 300, 1000, 400])
subplot(1,2,1);plot(GaussianX, UX, SX10);
% title(['Cell ' cellNum ' : X PPSF']);
grid on;xlim([min(UX) max(UX)]);xlabel('X (\mum)');ylabel('Photocurrent (norm.)');
% dim = [0.14 0.6 0.3 0.3];
% str = {['FWHMx=' num2str(FWHMx) '\mum']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
legend off;
ylim([0,1]);set(gca,'FontSize',24);

subplot(1,2,2);plot(GaussianZ, UZ, SZ10);
% title(['Cell ' cellNum ' : Z PPSF']);
grid on;xlim([UZ(6) max(UZ)]);xlabel('Z (\mum)');ylabel('Photocurrent (norm.)');
% dim = [0.7 0.6 0.3 0.3];
% str = {['FWHMz=' num2str(FWHMz) '\mum']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
legend off;
ylim([0,1]);
set(gca,'FontSize',24);
%%
saveas(gcf,[Foldername '\' Filename 'Cross-section_plot.pdf']);
saveas(gcf,[Foldername '\' Filename 'Cross-section_plot.fig']);
%%
% [X,Y,Z]=meshgrid(UX,UY,UZ);
% [Xq,Yq,Zq]=meshgrid(linspace(min(UX),max(UX),111),linspace(min(UY),max(UY),111),linspace(min(UZ),max(UZ),211));
% Sq = interp3(X,Y,Z,S,Xq,Yq,Zq);

S1=uint8(S/max(S(:))*255);
S1(S1<20)=0;
for i=1:21
    imwrite(S1(:,:,i),[Foldername '\' subfoldername '\' Filename '_' num2str(i) '.tif'],'tif');
end