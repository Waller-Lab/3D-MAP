% plot 1D photocurrent data
clear all;close all;clc

Foldername='10-16-19 Brain Slice Mapping Large';
Xratio=0.676;%from calibration data
Zratio=0.888;

Filename='101619d_exc_13_';
cellNum='D';
load([Foldername '\' Filename '.mat']);
%% plot raw data
for i=1:10
figure(1);
plot(ToSave.Stim.UUT,cell2mat(ToSave.Data(i,1)),'color',[1-i/10,0,i/10]);hold on;
end
xlim([0,0.025]);
set(gca,'FontSize',16);
xlabel('Time (s)');
ylabel('Photocurrent (nA)');
%%
ProcessData=1;
Setup.Scorepikes.Method=0;
% X=ToSave.VoltageRamp;
X=[0.001,0.022,0.0965,0.1275,0.132,0.229,0.302,0.3355,0.385,0.4795]*1000/4;%raw data from 20 pixel aperture
if ProcessData==1
   for i=1:numel(X)
       [ SX(i,1), ~] = function_score_voltageclamp( Setup,ToSave.Stim,-cell2mat(ToSave.Data(i,1)));
   end
else
    SX=cell2mat(ToSave.Score);
end

figure();
% V=linspace(0.001,0.191,10);%actual power for 10-pixel aperture
set(gcf, 'Position',  [300, 300,500, 400])
plot(X,mean(SX,2),'LineWidth',2);
% title(['Cell ' cellNum ' : Power test, blue light']);
grid on;xlim([min(X) max(X)]);xlabel('Stimulation power (mW)');
set(gca,'FontSize',16);
ylabel('Photocurrent (nA)');
%%
saveas(gcf,[Foldername '\' Filename '_powertest2_plot.pdf']);
saveas(gcf,[Foldername '\' Filename '_powertest2_plot.fig']);

