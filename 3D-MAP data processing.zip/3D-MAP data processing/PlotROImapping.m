clear all;close all;clc

Foldername='11-20-19 BrainSlice_exc';
Xratio=0.676;%from calibration data
Yratio=0.676;%from calibration data
Zratio=1.2;
Filename='emx_cre_ChromeS273A_112019h_9_';
cellNum='H';
load([Foldername '\' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;
%%
UX=ToSave.Xq(1,:)*Xratio;
UY=ToSave.Yq(:,1)*Yratio;
Nz=size(ToSave.Score{1},3);
NX=size(ToSave.Score{1},1);
NY=size(ToSave.Score{1},2);
PXX=ToSave.Xq*Xratio;
PYY=ToSave.Yq*Xratio;

repeatNum=size(ToSave.Score,1);
VoltageNum=size(ToSave.Score,2);

Ind_ori=ToSave.Ind;

seqL=ToSave.Stim.Npeaks;
NumofSeq=size(ToSave.Data.XY,1);

S=zeros(NX,NY,Nz,VoltageNum);

% t=linspace(0,0.003/150*465,465);
%%
for v=5
    for nz=Nz
        Score3D=zeros(NX,NY,repeatNum);
        switch ToSave.Stim.FreqHZ 
            case 40
            DataMatrix3D=zeros(NX*NY,1230,repeatNum);
            case 50
            DataMatrix3D=zeros(NX*NY,980,repeatNum);
            case 80
            DataMatrix3D=zeros(NX*NY,605,repeatNum);
            case 100
            DataMatrix3D=zeros(NX*NY,480,repeatNum);
        end
    
if ProcessData==1
    startpoint=1;
    for j=startpoint:repeatNum
        for i=1:NumofSeq
        Data_temp=ToSave.Data.XY{i,j,nz,v};
        Data_temp=medfilt1(Data_temp,10);
        Data_temp=Data_temp.*ToSave.Stim.CropMask';
        Data_temp(Data_temp==0)=[];
        DataMatrix=reshape(Data_temp,numel(Data_temp)/seqL,seqL);
        DataMatrix=abs(DataMatrix');
        DataMatrix3D(1+(i-1)*seqL:i*seqL,:,j)=DataMatrix;
            for k=1:seqL
                
                [ Score3D(Ind_ori(k+(i-1)*seqL,1),Ind_ori(k+(i-1)*seqL,2),j), ~] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(k,:),spikeremoveflag);           
            end
        end
    end
    S(:,:,nz,v)=mean(Score3D,3);
else
    Score_temp=ToSave.Score;
end
    end
end

%%

for v=1:VoltageNum
        Temp=zeros(NX,NY,Nz,repeatNum);
        for j=1:repeatNum
            Temp(:,:,:,j)=cell2mat(Score_temp(j,v));
        end
        Score3D=mean(Temp,4);
         figure(100);set(gcf,'position',[50,50,1200,800]);
        for nz=1:Nz
            subplot = @(m,n,p) subtightplot (m, n, p);
            subplot(VoltageNum,Nz,nz+(v-1)*Nz);
            imagesc(UX,UY,Score3D(:,:,nz)');colormap('hot');
%             title(['Cell ' cellNum ' [log]', ' r=' num2str(ToSave.Stim.TargetRadius), ' Z=' num2str(ToSave.Data.UZ(nz),2) , ' V=' num2str(ToSave.Stim.Voltageramp(v),2)]);
            axis image;
            axis off;
%             xlabel('X (\mum)');ylabel('Y (\mum)');
%             caxis([min(log(Score3D(:))) max(log(Score3D(:)))]);
            
            caxis([0 0.1]);
%             colorbar;
%             set(gca,'FontSize',16);
            
        end
        
end
saveas(gcf,[Foldername '\' Filename 'plot_full_processData' num2str(ProcessData) '.pdf']);

DataMatrix2D=squeeze(mean(DataMatrix3D,3));
Score2D=mean(Score3D,3);
figure();imagesc(log(Score2D'));

S(:,:,nz)=Score2D;

% title(num2str(kk));drawnow;

% figure();set(gcf, 'Position',  [0, 0,1300, 900]);
% for p=1:NX*NY
%     subplot = @(m,n,p) subtightplot (m, n, p);
%     q=sub2ind([NX,NY],ToSave.Ind(p,1),ToSave.Ind(p,2));
%     subplot(NX,NY,q);plot(DataMatrix2D(p,1:20:end));
%     ylim([min(DataMatrix2D(:)) max(DataMatrix2D(:))]);
%     axis off
%     disp(p);
% end
% dim = [0.1 0.66 0.3 0.3];
% str = {['ymin' num2str(min(DataMatrix2D(:))), ' ymax ' num2str(max(DataMatrix2D(:))), '. time(ms) ' num2str(ToSave.Stim.DurationMS)]};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% saveas(gcf,[Foldername '\' Filename 'trace' num2str(ProcessData) 'Z' num2str(ToSave.Data.UZ(nz)) '.tif']);

%% hot plot
% figure();
% set(gcf,'position',[100, 100, 880, 400]);
% for nz=1:Nz
% subplot(1,Nz,nz);
% imagesc(S(:,:,nz)');
% title(['Z = ' num2str(ToSave.Data.UZ(nz),2) '\mum']);
% axis image;axis off;
% caxis([min((S(:))) max((S(:)))]);colormap('hot');
% end
% saveas(gcf,[Foldername '\' Filename 'hotmap.pdf']);
% %%
% for nz=1:Nz
% figure();
% imagesc(UX,UY,log(S(:,:,nz))');
% title(['Cell ' cellNum ' : XY Mapping [log]', ' r=' num2str(ToSave.Stim.TargetRadius), ' Z=' num2str(ToSave.Data.UZ(nz))]);
% axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
% caxis([min(log(S(:))) max(log(S(:)))]);
% colorbar;
% set(gca,'FontSize',16);
% saveas(gcf,[Foldername '\' Filename 'plot_processData' num2str(ProcessData)  'Z' num2str(ToSave.Data.UZ(nz)) '.tif']);
% end
% save([Foldername '\MappingXY_' Filename '_' cellNum '.mat'],'S');
% %% plot part of the region
% Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
% [indx_roi,indy_roi]=meshgrid(9:30,7:38);
% Indaim=sub2ind([NX,NY],indx_roi(:),indy_roi(:));
% [~,irandom,iroi] = intersect(Indrandom,Indaim,'sorted'); 
% figure();set(gcf, 'Position',  [0, 0,1300, 800]);
% for p=1:numel(Indaim)
%     subplot = @(m,n,p) subtightplot (m, n, p);
% subplot(size(indx_roi,1),size(indx_roi,2),p);
% plot(DataMatrix2D(irandom(p),1:10:end));
% % ylim([-0.12 -0.08]);
% ylim([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
% axis off
% disp(p);
% end
% dim = [0.1 0.66 0.3 0.3];
% str = {['ymin' num2str(min(min(DataMatrix2D(irandom,:)))), ' ymax ' num2str(max(max(DataMatrix2D(irandom,:)))), '. time(ms) ' num2str(ToSave.Stim.DurationMS)]};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% saveas(gcf,[Foldername '\' Filename 'trace_roi4' num2str(ProcessData) '.tif']);
% disp([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
% %%
% % if ProcessData==1
% %     SXY2D=reshape(mean(SXY,2),[numel(UX) numel(UY)]);
% % else
% %     SXY2D=mean(SXY,3);
% % end
% %%
% % [~,Ind]=max(mean(SXY,2));
% % if numel(Ind)>1
% %     [~,ind]=min(abs(Ind-length(SXY)/2));
% %     Ind=Ind(ind);
% % end
% % 
% % [I,J]=ind2sub([length(UX) length(UY)],Ind);
%%
%  figure();imagesc(log(Score2D'));
row=24;col=21;startpoint=1;
Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
q=sub2ind([NX,NY],row,col);
[vv]=find(Indrandom==q);
A=DataMatrix3D(vv,:,:);
A=squeeze(A);
% if startpoint==1
%     A=A';
% end
t=0:ToSave.Stim.UT(2):ToSave.Stim.UT(2)*(size(A,1)-1);
[~,peak]=max(abs(mean(A(:,startpoint:end),2)));
a1=mean(A(peak:end,startpoint:end),2);
t1=t(peak:end);
[fitresult, gof] = function_createMonoExpFit(t1, abs(a1));
temp=coeffvalues(fitresult);tau=-1000/temp(2);%exponential decay time

figure();
for i=startpoint:repeatNum
    traceA(:,i,v)=-(A(:,i)-min(A(:,i)));
    plot(t,traceA(:,i,v),'color',[1-i/repeatNum, 0, i/repeatNum]);hold on;
end
hold off
dim = [0.7 0.6 0.3 0.3];
str = {['\tau=' num2str(tau) 'ms']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
xlim([min(t) max(t)]);
xlabel('time (s)');ylabel('photocurrent (nA)');
grid on;

% saveas(gcf,[Foldername '\' Filename 'one_trace_' num2str(row) '_' num2str(col) '_Z' num2str(ToSave.Data.UZ(nz)) '.tif']);
%% plot trace of different voltage
% traceA=zeros(1230,5,5);

temp=squeeze(mean(traceA(:,2:5,:),2));
figure();
for i=1:VoltageNum
    figure();
    plot(t*1000,temp(:,i)*1000,'color',[1-i/VoltageNum, 0, i/VoltageNum]);


xlim([min(t*1000) max(t*1000)]);
xlabel('time (ms)');ylabel('I (pA)');
set(gca,'FontSize',32);
ylim([-81,0]);
saveas(gcf,[Foldername '\' Filename 'one_trace_' num2str(row) '_' num2str(col) '_Z' num2str(ToSave.Data.UZ(nz)) '_power' num2str(i) '.pdf']);
end
%% plot raw data
% figure();plot(ToSave.Stim.UUT,ToSave.Data.XY{2,1});
% xlabel('time(s)');ylabel('raw data (nA)');
% hold on;plot(ToSave.Stim.UUT,-ToSave.Stim.Array/4-0.4);
% axis tight
% % %% remove outlier
% % DataMatrix3D_filtered=DataMatrix3D;
% % for j=1:repeatNum
% %     for i=1:numel(Indrandom)
% %         temp=DataMatrix3D_filtered(i,:,j);
% %         [fitresult, gof] = createFit_poly3(t, temp);
% %         if gof.rsquare<0.7 || fitresult.p1>0
% %             DataMatrix3D_filtered(i,:,j)=0;
% %             continue;
% %         else
% %             [~,ind]=min(abs(6*fitresult.p1*t+2*fitresult.p2));
% %             if ind<50 || ind>400
% %                 DataMatrix3D_filtered(i,:,j)=0;
% %             end
% %         end
% %         disp(i);
% %     end
% %     disp(j);
% % end
% % 
% % S=max(max(DataMatrix3D_filtered,[],3),[],2);
% % S0=reshape(S(Indrandom),NX,NY);
% %             
% % figure();imagesc(UX,UY,log(S0));
% % title(['Cell ' cellNum ' : XY Mapping [log]', ' r=' num2str(ToSave.Stim.TargetRadius)]);
% % axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
% % colorbar;
% % set(gca,'FontSize',16);
% % saveas(gcf,[Foldername '\' Filename 'plot_medianNum', '.tif']);