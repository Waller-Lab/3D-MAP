clear all;close all;clc;
%%
Foldername='12-30-19';
Xratio=0.676;%from calibration data
Yratio=0.676;%from calibration data
Zratio=1.2;
Filename='IUE_ChroME-BFP;mDlx-ChroME;P51_123019b_18_good';
cellNum='B';
load([Foldername '/' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;

UX=ToSave.Data.UX*Xratio;
UY=ToSave.Data.UY*Yratio;
Nz=size(ToSave.Data.XY,3);
NX=numel(UX);
NY=numel(UY);
% PXX=reshape(ToSave.Data.PXX*Xratio,[NX NY Nz]);
% PYY=reshape(ToSave.Data.PYY*Yratio,[NX NY Nz]);

repeatNum=size(ToSave.Data.XY,2);
VoltageNum=size(ToSave.Score,2);

Ind_ori=ToSave.Ind;

seqL=ToSave.Stim.Npeaks;
NumofSeq=size(ToSave.Data.XY,1);
TimeMap=cell(VoltageNum, repeatNum);

Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
% t=linspace(0,0.003/150*465,465);
%%
for v=1:VoltageNum
    for j=1:repeatNum
        Score3D=zeros(NX,NY,Nz);
        TM=zeros(NX,NY,Nz);
        switch ToSave.Stim.FreqHZ 
            case 40
            DataMatrix3D=zeros(NX*NY,1230,Nz);
            case 50
            DataMatrix3D=zeros(NX*NY,980,Nz);
            case 80
            DataMatrix3D=zeros(NX*NY,595,Nz);
            case 100
            DataMatrix3D=zeros(NX*NY,480,Nz);
        end
    for nz=1:Nz
            for i=1:NumofSeq
                    CurrentData=ToSave.Data.XY{i,j,nz,v};
                    CurrentData=medfilt1(CurrentData,5);
    %                 ToSave.Stim.baseline=mean(CurrentData(1:50));
                    CurrentData=CurrentData.*ToSave.Stim.CropMask';
                    CurrentData(CurrentData==0)=[];
                    DataMatrix=reshape(CurrentData,[numel(CurrentData)/seqL,seqL]);
                    DataMatrix=DataMatrix';
                    DataMatrix3D(1+(i-1)*seqL:i*seqL,:,nz)=DataMatrix;
                    for p=1:seqL
                        cx=ToSave.Ind(p+(i-1)*seqL,1);
                        cy=ToSave.Ind(p+(i-1)*seqL,2);
                        [ Score3D(cx,cy,nz), odata,~] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(p,:),spikeremoveflag);            
                    end
            end
    end
    %identify signals from background noise
    T = otsuthresh(imhist(Score3D));
    BWscore=imbinarize(Score3D,T*1.5);
    %exact the traces of signals
    [col,row,layer]=ind2sub(size(BWscore),find(BWscore));
    DataMatrixSignal=zeros(numel(col),size(DataMatrix3D,2));
    for ii=1:numel(col)
        q=sub2ind([NX,NY],row(ii),col(ii));
%         data=DataMatrix3D(find(Indrandom==q),:,layer(ii));
%         k=(mean(data(end-4:end))-mean(data(2:5)))/(numel(data)-1);
%         baseline=k*((1:numel(data))-1)+mean(data(2:5));
%         DataMatrixSignal(ii,:)=data-baseline;
        DataMatrixSignal(ii,:)=DataMatrix3D(find(Indrandom==q),:,layer(ii));
    end
    data=medfilt1(DataMatrixSignal,30,[],2);
    datadiff=diff(data(:,5:end),[],2);
    [~,inddiff]=max(datadiff,[],2);
    [inddiff_sort,inddiff_order]=sort(inddiff);
    figure(200);
    for i=1:numel(inddiff_order)
        plot(DataMatrixSignal(inddiff_order(i),:),'color',[1-i/numel(inddiff),0,i/numel(inddiff)]);
        hold on;
    end
    hold off
    
%     [MX,VX]=function_MutualXcorr(DataMatrixSignal,0);
%     temp1=zeros(size(MX,1),1);
%     for i=1:numel(col)
%         temp1(i)=mean(abs(MX(i,(i+1):end)));
%     end
%     [~,ind]=find(temp1<0.3);
%     MX(ind,:)=[];
%     MX(:,ind)=[];
    
%     sortorder=zeros(size(MX,1),1);
%     for i=1:size(MX,1)
%         [tempcol,temprow,templayer]=ind2sub(size(MX),find(MX>0));
%         sortorder(i)=min(setdiff(1:size(MX,1),[tempcol;sortorder]));
%         MX(sortorder(i),:)=0;
%         MX(:,sortorder(i))=0;
%     end
%     
% %     DataMatrixSignal(ind,:)=[];
%     figure(200+v+nz);
%     for i=1:size(DataMatrixSignal,1)
%     plot(DataMatrixSignal(sortorder(i),:),'color',[1-i/size(DataMatrixSignal,1),0,i/size(DataMatrixSignal,1)]);hold on;
%     end
%     hold off
    
%     TimeMap{v,j}=TM; 
    end     
end
%% 
TimeMapAve=zeros(NX,NY,Nz,VoltageNum);
for i=1:VoltageNum
TimeMapAve(:,:,:,i)=(TimeMap{i,1}+TimeMap{i,2}+TimeMap{i,3}+TimeMap{i,4})/4;
end


%%
figure(100);
set(gcf,'Position',[50,50,Nz*200,(VoltageNum)*200]);
for v=1:VoltageNum
    for nz=1:Nz
        subplot(VoltageNum,Nz,(v-1)*Nz+nz);
        imagesc(UX,UY,TimeMapAve(:,:,nz,v)');
        title(['r=' num2str(ToSave.Stim.TargetRadius), ' Z=' num2str(ToSave.Data.UZ(nz),2),' V=' num2str(ToSave.Stim.Voltageramp(v),2)]);
        caxis([min(TimeMapAve(:)) max(TimeMapAve(:))]);
        axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
    end
end
saveas(gcf,[Foldername '/' Filename 'AverageStartTime_plot_allvoltage_allZ.tif']);
saveas(gcf,[Foldername '/' Filename 'AverageStartTime_plot_allvoltage_allZ.fig']);
save([Foldername '/StartSpikeTimeMappingXY_' Filename '_' cellNum '.mat'],'TimeMap');
%% plot part of the region
Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
[indx_roi,indy_roi]=meshgrid(1:20,1:20);
Indaim=sub2ind([NX,NY],indx_roi(:),indy_roi(:));
[~,irandom,iroi] = intersect(Indrandom,Indaim,'sorted'); 
figure();set(gcf, 'Position',  [100, 100,size(indx_roi,2)*50, size(indx_roi,1)*50]);
for p=1:numel(Indaim)
    subplot = @(m,n,p) subtightplot (m, n, p);
subplot(size(indx_roi,1),size(indx_roi,2),p);
plot(DataMatrix2D(irandom(p),1:40:end));
% ylim([-0.8 -0.07]);
ylim([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
axis off
disp(p);
end
dim = [0.1 0.66 0.3 0.3];
str = {['ymin' num2str(min(min(DataMatrix2D(irandom,:)))), ' ymax ' num2str(max(max(DataMatrix2D(irandom,:)))), '. time(ms) ' num2str(ToSave.Stim.DurationMS)]};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
saveas(gcf,[Foldername '\' Filename 'trace_roi1_Z' num2str(ToSave.Data.UZ(nz)) '.fig']);
disp([min(min(DataMatrix2D(irandom,:))) max(max(DataMatrix2D(irandom,:)))]);
%%
sealtest=zeros(size(ToSave.Data.XY));
for v=1:VoltageNum
    for j=1:repeatNum
        for nz=1:Nz
            for i=1:NumofSeq
                if isempty(ToSave.Data.XY{i,j,nz,v})
                    continue;
                else
                    temp=ToSave.Data.XY{i,j,nz,v};
                    sealtest(i,j,nz,v)=max(temp(1:2500))-mean(temp(2000:2400));
                end
            end
        end
    end
end
sealtest1=permute(sealtest,[1,3,2,4]);
figure();plot(sealtest1(:));
axis tight;grid on; 
ylabel('mV');
xlabel('Seal test of each sequence');
saveas(gcf,[Foldername '\' Filename 'sealtest.fig']);
%%
%  figure();imagesc(log(Score2D'));
row=23;col=3;startpoint=2;
Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
q=sub2ind([NX,NY],row,col);
[v]=find(Indrandom==q);
A=DataMatrix3D(v,:,:);
A=squeeze(A);
if startpoint==1
    A=A';
end
t=0:ToSave.Stim.UT(2):ToSave.Stim.UT(2)*(size(A,1)-1);
[~,peak]=max(abs(mean(A(:,startpoint:end),2)));
a1=mean(A(peak:end,startpoint:end),2);
t1=t(peak:end)';
[fitresult, gof] = function_createMonoExpFit(t1, abs(a1));
temp=coeffvalues(fitresult);tau=-1000/temp(2);%exponential decay time

figure();
for i=startpoint:repeatNum
    plot(t,A(:,i),'color',[1-i/repeatNum, 0, i/repeatNum]);hold on;
end
hold off
dim = [0.7 0.6 0.3 0.3];
str = {['\tau=' num2str(tau) 'ms']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
xlim([min(t) max(t)]);
xlabel('time (s)');ylabel('photocurrent (nA)');
grid on;
set(gca,'FontSize',16);
saveas(gcf,[Foldername '\' Filename 'one_trace_' num2str(row) '_' num2str(col) '_Z' num2str(ToSave.Data.UZ(nz)) 'V2.6.tif']);
 %% plot decay time map
 DecayTimeMap=zeros(NX,NY);
 startpoint=2;
 
 for yy=1:NY
     for xx=1:NX
        row=xx;col=yy;
        Indrandom=sub2ind([NX,NY],ToSave.Ind(:,1),ToSave.Ind(:,2));
        q=sub2ind([NX,NY],row,col);
        [v]=find(Indrandom==q);
        A=DataMatrix3D(v,:,:);
        A=squeeze(A);
        if startpoint==1
            A=A';
        end
        [peakVal,peak]=max(abs(mean(A(:,startpoint:end),2)));
        baseline=A(1:10,startpoint:end);
        if peakVal<abs(mean(baseline(:)))+0.08
            tau=nan;
        else
            a1=mean(A(peak:end,startpoint:end),2);
            t=0:ToSave.Stim.UT(2):ToSave.Stim.UT(2)*(size(A,1)-1);
            t1=t(peak:end)';
            [fitresult, gof] = function_createMonoExpFit(t1, abs(a1));
            temp=coeffvalues(fitresult);tau=-1000/temp(2);%exponential decay time
        end
        DecayTimeMap(col,row)=tau;
     end
 end
 figure();
 imagesc(UX,UY,DecayTimeMap);
axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
colorbar;
set(gca,'FontSize',16);
title(['Decay time map (ms), Z=' num2str(ToSave.Data.UZ(nz))]);
saveas(gcf,[Foldername '/' Filename 'DecayTimePlot_Z' num2str(ToSave.Data.UZ(nz)) '.tif']);
saveas(gcf,[Foldername '/' Filename 'DecayTimePlot_Z' num2str(ToSave.Data.UZ(nz)) '.fig']);
