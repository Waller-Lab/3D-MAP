%% simultaneous targeting
load('C:\Users\xueyi\Dropbox (MIT)\research\4D sculpturelight\V1.5\11-20-19 BrainSlice_exc\emx_cre_ChromeS273A_112019h_simul3D_3.mat');
Foldername='11-20-19 BrainSlice_exc';
Filename='emx_cre_ChromeS273A_112019h_simul3D_3';
data=ToSave.Data.MultiTargets;
t=ToSave.Stim.UUT;
startpoint=min(find(t>ToSave.Stim.DelayBorder));
repeatNum=size(data,3);
combo1=zeros(6,numel(t));
for i=1:6
    for j=1:repeatNum
        combo1(i,:)=data{i,1,j}'+combo1(i,:);
    end
end
combo1=combo1/repeatNum;
figure();set(gcf,'position',[50,50,200,600]);
for i=1:6
    subplot(6,1,i);
    plot(t(startpoint:end),medfilt1(combo1(i,startpoint:end)-max(combo1(i,startpoint:end)),10));
    xlim([t(startpoint) t(end)]);
    ylim([-0.06, 0]);
    set(gca,'fontsize',12);
end
saveas(gcf,[Foldername '\' Filename 'combo1.fig']);
saveas(gcf,[Foldername '\' Filename 'combo1.pdf']);
%%
combo5=zeros(6,numel(t));
for i=1:6
    for j=1:repeatNum
        combo5(i,:)=data{i,5,j}'+combo5(i,:);
    end
end
combo5=combo5/repeatNum;
figure();set(gcf,'position',[50,50,200,600]);
for i=1:6
    subplot(6,1,i);
    plot(t(startpoint:end),medfilt1(combo5(i,startpoint:end)-max(combo5(i,startpoint:end)),10));
    xlim([t(startpoint) t(end)]);
    ylim([-0.1, 0]);
    set(gca,'fontsize',12);
end
saveas(gcf,[Foldername '\' Filename 'combo5.fig']);
saveas(gcf,[Foldername '\' Filename 'combo5.pdf']);
%%
N=size(ToSave.Stim.IndComb{2},1);
combo2=zeros(N,numel(t));
for i=1:N
    for j=1:repeatNum
        combo2(i,:)=data{i,2,j}'+combo2(i,:);
    end
end
combo2=combo2/repeatNum;
figure();set(gcf,'position',[50,50,600,600]);
for i=1:N
    subplot(5,3,i);
    plot(t(startpoint:end),medfilt1(combo2(i,startpoint:end)-max(combo2(i,startpoint:end)),10));
    xlim([t(startpoint) t(end)]);
    ylim([-0.08, 0]);
    set(gca,'fontsize',12);
end
saveas(gcf,[Foldername '\' Filename 'combo2.fig']);
saveas(gcf,[Foldername '\' Filename 'combo2.pdf']);
%%
N=size(ToSave.Stim.IndComb{3},1);
combo3=zeros(N,numel(t));
for i=1:N
    for j=1:repeatNum
        combo3(i,:)=data{i,3,j}'+combo3(i,:);
    end
end
combo3=combo3/repeatNum;
figure();set(gcf,'position',[50,50,800,600]);
for i=1:N
    subplot(5,4,i);
    plot(t(startpoint:end),medfilt1(combo3(i,startpoint:end)-max(combo3(i,startpoint:end)),10));
    xlim([t(startpoint) t(end)]);
    ylim([-0.1, 0]);
    set(gca,'fontsize',12);
end
saveas(gcf,[Foldername '\' Filename 'combo3.fig']);
saveas(gcf,[Foldername '\' Filename 'combo3.pdf']);
%%
N=size(ToSave.Stim.IndComb{4},1);
combo4=zeros(N,numel(t));
for i=1:N
    for j=1:repeatNum
        combo4(i,:)=data{i,4,j}'+combo4(i,:);
    end
end
combo4=combo4/repeatNum;
figure();set(gcf,'position',[50,50,600,600]);
for i=1:N
    subplot(5,3,i);
    plot(t(startpoint:end),medfilt1(combo4(i,startpoint:end)-max(combo4(i,startpoint:end)),10));
    xlim([t(startpoint) t(end)]);
    ylim([-0.13, 0]);
    set(gca,'fontsize',12);
end
saveas(gcf,[Foldername '\' Filename 'combo4.fig']);
saveas(gcf,[Foldername '\' Filename 'combo4.pdf']);
%%
combo6=zeros(1,numel(t));

for j=1:repeatNum
    combo6=data{1,6,j}'+combo6;
end

combo6=combo6/repeatNum;

figure();set(gcf,'position',[50,50,200,100]);

    plot(t(startpoint:end),medfilt1(combo6(startpoint:end)-max(combo6(startpoint:end)),10));
    xlim([t(startpoint) t(end)]);
    set(gca,'fontsize',12);

saveas(gcf,[Foldername '\' Filename 'combo6.fig']);
saveas(gcf,[Foldername '\' Filename 'combo6.pdf']);
%% compare the influence from different roi to 1
figure();
plot(t(startpoint:end),medfilt1(combo1(1,startpoint:end)-max(combo1(1,startpoint:end)),20),'r');
hold on;
plot(t(startpoint:end),medfilt1(combo2(1,startpoint:end)-max(combo2(1,startpoint:end)),20),'color',[0.5,0.5,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo2(2,startpoint:end)-max(combo2(2,startpoint:end)),20),'color',[0.5,0,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo2(3,startpoint:end)-max(combo2(3,startpoint:end)),20),'color',[0,1,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo2(4,startpoint:end)-max(combo2(4,startpoint:end)),20),'color',[0,0.5,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo2(5,startpoint:end)-max(combo2(5,startpoint:end)),20),'color',[0,0,1]);
xlim([t(startpoint) t(end)]);
set(gca,'fontsize',12);
legend('1','1,2','1,3','1,4','1,5','1,6','Location','southeast');
saveas(gcf,[Foldername '\' Filename 'comparecombo1and2.fig']);
saveas(gcf,[Foldername '\' Filename 'comparecombo1and2.pdf']);
%%
figure();
plot(t(startpoint:end),medfilt1(combo1(1,startpoint:end)-max(combo1(1,startpoint:end)),20),'r');
hold on;
plot(t(startpoint:end),medfilt1(combo2(1,startpoint:end)-max(combo2(1,startpoint:end)),20),'color',[0.5,0.5,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo3(1,startpoint:end)-max(combo3(1,startpoint:end)),20),'color',[0.5,0,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo3(2,startpoint:end)-max(combo3(2,startpoint:end)),20),'color',[0,1,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo3(3,startpoint:end)-max(combo3(3,startpoint:end)),20),'color',[0,0.5,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo3(4,startpoint:end)-max(combo3(4,startpoint:end)),20),'color',[0,0,1]);
xlim([t(startpoint) t(end)]);
set(gca,'fontsize',12);
legend('1','1,2','1,2,3','1,2,4','1,2,5','1,2,6','Location','southeast');
saveas(gcf,[Foldername '\' Filename 'comparecombo1_2_3.fig']);
saveas(gcf,[Foldername '\' Filename 'comparecombo1_2_3.pdf']);
%%
figure();
plot(t(startpoint:end),medfilt1(combo1(1,startpoint:end)-max(combo1(1,startpoint:end)),20),'r');
hold on;
plot(t(startpoint:end),medfilt1(combo2(1,startpoint:end)-max(combo2(1,startpoint:end)),20),'color',[0.5,0.5,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo3(2,startpoint:end)-max(combo3(2,startpoint:end)),20),'color',[0.5,0,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo4(1,startpoint:end)-max(combo4(1,startpoint:end)),20),'color',[0,1,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo4(4,startpoint:end)-max(combo4(4,startpoint:end)),20),'color',[0,0.5,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo4(5,startpoint:end)-max(combo4(5,startpoint:end)),20),'color',[0,0,1]);
xlim([t(startpoint) t(end)]);
set(gca,'fontsize',12);
legend('1','1,2','1,2,4','1,2,3,4','1,2,4,5','1,2,4,6','Location','southeast');
saveas(gcf,[Foldername '\' Filename 'comparecombo1_2_3_4.fig']);
saveas(gcf,[Foldername '\' Filename 'comparecombo1_2_3_4.pdf']);
%%
figure();
plot(t(startpoint:end),medfilt1(combo1(1,startpoint:end)-max(combo1(1,startpoint:end)),20),'r');
hold on;
plot(t(startpoint:end),medfilt1(combo2(1,startpoint:end)-max(combo2(1,startpoint:end)),20),'color',[0.5,0.5,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo3(2,startpoint:end)-max(combo3(2,startpoint:end)),20),'color',[0.5,0,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo4(4,startpoint:end)-max(combo4(4,startpoint:end)),20),'color',[0,0.5,0.5]);
hold on;
plot(t(startpoint:end),medfilt1(combo5(1,startpoint:end)-max(combo5(1,startpoint:end)),20),'color',[0,0,1]);
hold on;
plot(t(startpoint:end),medfilt1(combo5(4,startpoint:end)-max(combo5(4,startpoint:end)),20),'color',[0,1,0]);
hold on;
plot(t(startpoint:end),medfilt1(combo6(startpoint:end)-max(combo6(startpoint:end)),20),'color',[0,1,1]);

xlim([t(startpoint) t(end)]);
set(gca,'fontsize',12);
legend('1','1,2','1,2,4','1,2,4,5','1,2,3,4,5','1,2,4,5,6','1,2,3,4,5,6','Location','southeast');
saveas(gcf,[Foldername '\' Filename 'comparecombo1_2_3_4_5_6.fig']);
saveas(gcf,[Foldername '\' Filename 'comparecombo1_2_3_4_5_6.pdf']);