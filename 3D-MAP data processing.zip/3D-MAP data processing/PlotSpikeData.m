clear all;close all;clc

Foldername='9-27-19BrainSlice-PCH';
Filename='9-27-19-brainSlice-F-spike-1D_7_';
cellNum='F';
load([Foldername '\' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=1;
plotallData=0;
Xratio=0.676;%from calibration data
Zratio=0.888;
%% 
% check interrupt
UX=ToSave.Data.UX*Xratio;
UZ=ToSave.Data.UZ*Zratio;
if ProcessData==1
    for j=1:size(ToSave.Data.X,2)
        if isempty(cell2mat(ToSave.Data.X(:,j)))
            break;
        else
            for i=1:size(ToSave.Data.X,1)
                [ SX(i,j), odata] = function_scorespikes( Setup,ToSave.Stim,cell2mat(ToSave.Data.X(i,j)));
                [ SZ(i,j), odata] = function_scorespikes( Setup,ToSave.Stim,cell2mat(ToSave.Data.Z(i,j)));
            end
        end
    end
else
    SX=cell2mat(ToSave.Data.SX);
    SZ=cell2mat(ToSave.Data.SZ);
end
% if plotallData==0
    [GaussianX, gofx] = createFit(UX', mean(SX,2));
    [GaussianZ, gofz] = createFit(UZ', mean(SZ,2));
% else
%     [GaussianX, gofx] = createFit(kron(UX',ones(size(ToSave.Data.X,2),1)), SX(:));
%     [GaussianZ, gofz] = createFit(kron(UZ',ones(size(ToSave.Data.Z,2),1)), SZ(:));
% end
FWHMx=FWHMofGaussian( GaussianX, UX );
FWHMz=FWHMofGaussian( GaussianZ, UZ );
%%
figure();
set(gcf, 'Position',  [300, 300, 1000, 400])
subplot(1,2,1);
if plotallData==1
    plot(GaussianX, UX, SX);
    b = gca; legend(b,'off');
else
    plot(GaussianX, UX, mean(SX,2));
end
title(['Cell ' cellNum ' : X spike PPSF, StimVoltage: ' num2str(ToSave.Stim.Voltage)]);
grid on;xlim([min(UX) max(UX)]);xlabel('X (\mum)');ylabel('Num of Spike');
dim = [0.14 0.6 0.3 0.3];
str = {['FWHMx=' num2str(FWHMx) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');

subplot(1,2,2);

if plotallData==1
    plot(GaussianZ, UZ, SZ);
    b = gca; legend(b,'off');
else
    plot(GaussianZ, UZ, mean(SZ,2));
end

title(['Cell ' cellNum ' : Z spike PPSF, StimVoltage: ' num2str(ToSave.Stim.Voltage)]);
grid on;xlim([min(UZ) max(UZ)]);xlabel('Z (\mum)');ylabel('Num of Spike');
dim = [0.58 0.6 0.3 0.3];
str = {['FWHMz=' num2str(FWHMz) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
figure(1);
dim = [0.47 0.68 0.3 0.3];
str = {['Repeat ' num2str(size(ToSave.Data.X,2))]};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
%%
saveas(gcf,[Foldername '\' Filename 'spikeplot_plotallData' num2str(plotallData) '.tif']);
save([Foldername '\SpikeExp_' Filename '_' cellNum '.mat'],'SX','SZ','UX','UZ','GaussianX','GaussianZ');
%% plot raw data
i=6;
timebegin=15000;
timerange=[timebegin timebegin+1000];
raw=cell2mat(ToSave.Data.Z(i,1));
figure();
subplot(1,2,1);
plot(ToSave.Stim.UUT*10^3,raw);xlabel('ms');ylabel('voltage');
title('raw data example');
subplot(1,2,2);
plot(ToSave.Stim.UUT(timerange(1):timerange(2))*10^3,raw(timerange(1):timerange(2)));
xlabel('ms');ylabel('voltage');
title('Zoom-in Spike');xlim([ToSave.Stim.UUT(timerange(1)) ToSave.Stim.UUT(timerange(2))]*1000);
set(gcf,'Position',[100 100 1000 500]);
%%
saveas(gcf,[Foldername '\' Filename 'rawplot.tif']);
