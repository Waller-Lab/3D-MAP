% widefield image overlap
addpath('C:\Research Data\3D-MAP manuscript');
SaveImage=0;
BG=imread('C:\Research Data\3D-MAP manuscript\4-21-21 RCaMP1a CoChR mouse 4 all-optical in vivo\Prime95_BG.tif');
BG=BG(501:700,501:700);
%% load data
filename='5-17-21 RCaMP_CoChR_mouse2_invivo_PPSFz_b__gooddata_26_';
load(['C:\Research Data\3D-MAP manuscript\All optical PPSF\' filename '.mat']);

%% check raw data
j=3;
Iraw=ToSave.DataSave.X{j};
figure(101);imshow3D(Iraw);

%% check image
Npoint=length(ToSave.DataSave.UX);
Npeaks=ToSave.Stim.repeatNum;
Nframes=size(ToSave.DataSave.X{1},3);
dF=zeros(Npoint, Nframes);
CaTrace=zeros(size(dF));
for j=1:Npoint
Iraw=ToSave.DataSave.X{j};
I1=double(Iraw(:,:,:)); %kick out bad images
background=repmat(mean(mean(I1(1:50,1:50,:))),[size(I1,1), size(I1,2),1]);
I1=I1-background;
% figure();imshow3D(I1);
% generate Mask
Imean=uint16(mean(I1,3));

mask1=imbinarize(Imean,'global');
mask2=imbinarize(Imean,'adaptive', 'Sensitivity', 0.58);
Mask=medfilt2(mask1.*mask2,[15, 15]);
Mask(1:85,:)=0;
Mask(120:end,:)=0;
Mask(:,1:85)=0;
Mask(:,110:end)=0;

figure(256);imagesc(Imean);axis image;colormap('gray');caxis([min(Imean(:)) max(Imean(:))]);colorbar;
green = cat(3, zeros(size(Imean)),ones(size(Imean)),zeros(size(Imean)));
hold on
h=imshow(green);
hold off
set(h,'AlphaData',Mask*0.1);
drawnow;

% Intensity trace
Itemp=I1.*Mask;
CaTrace(j,:)=squeeze(sum(sum(Itemp)))/nnz(Mask);
T_ds=0:ToSave.Stim.Exposure/1000:(size(CaTrace,2)-1)*ToSave.Stim.Exposure/1000;

% dF/F trace
w=round((1000/ToSave.Stim.Exposure)/ToSave.Stim.cutoffFreq*0.75);
for ii=1:size(CaTrace,2)
    if ii<=w
        F0=min(min(CaTrace(j, 1:ii+w)));
    elseif ii>size(CaTrace,2)-w
        F0=min(min(CaTrace(j,ii-w:end)));
    else
        F0=min(min(CaTrace(j,ii-w:ii+w)));
    end
    dF(j, ii)=(CaTrace(j,ii)-F0)/F0;
end
end

figure();set(gcf,'position',[100,100,500,100]);
imagesc(T_ds, ToSave.DataSave.UX, dF);xlabel('time (s)');ylabel('\mum');

% %% deconv with OASIS
% s=zeros(size(dF));
% for j=1:Npoint
%     [c, s(j,:), options] = deconvolveCa(dF(j,:), 'foopsi', 'ar1', 'smin', -3, 'optimize_pars', true, 'optimize_b', true);
% end
% figure();imagesc(s);
%% OASIS
% dF1D=dF';
% dF1D=dF1D(:);
% [c, s, options]=deconvolveCa(dF1D, 'foopsi', 'ar1', 'smin', -4, 'optimize_pars', true, 'optimize_b', true);
% s1=reshape(s,[size(dF,2), size(dF,1)]);
% s1=s1';
% 
% for n=1:11
% figure(n);subplot(2,1,1);plot(CaTrace(n,:));
% subplot(2, 1,2);plot(dF(n,:));
% % subplot(2,1,3);plot(s1(n,:));
% end
%% filter out spontaneous event
timefilter=rem(1:Nframes,Nframes/Npeaks)<15;
ind=find(timefilter);
dF_crop=dF(:,ind);
%% average dF/F
x=ToSave.DataSave.UX;
x=x(2:end-1);
s2=mean(dF_crop(2:end-1,:),2);
% s2=(s2-min(s2))/max(s2-min(s2));
figure();set(gcf,'position',[100,280,500,300]);
errorbar(x,s2,std(dF_crop(2:end-1,:),0,2)/sqrt(size(dF_crop,2)));
xlabel('\mum');ylabel('average dF/F');
%%
save([filename 'PPSF_z.mat'],'s2','x','dF','dF_crop');
%% Gaussian fit
a1=1.052;
b1=4.864;
c1=32.47;
% sstd=std(s_100um,0,2)/sqrt(2);
figure();plot(x, s2, 'o');
X=interp(x,10);
hold on;plot(X,1/1.051*a1*exp(-((X-b1)/c1).^2));
xlim([min(x), max(x)]);Zxc
xlabel('x (\mum)');
ylabel('average dF/F');
%% save final image
% S=zeros(10,3);
% S(:,2)=s2;
Sstd=std(S,0,2)/sqrt(3);
Smean=mean(S,2);

figure();
set(gcf,'position',[400,400,300,250]);
errorbar(x,Smean,Sstd,'o');xlabel('x (\mum)');
a1=0.9881;
b1=-3.555;
c1=26.57;
X=interp(x,10);
hold on;plot(X,1/0.9878*a1*exp(-((X-b1)/c1).^2));
xlim([min(x), max(x)]);
ylim([0, 1]);
ylabel('norm. average dF/F');
title('All-optical PPSF X, FWHM=44\mum');

saveas(gcf,'SavedData/all_optical_invivo_PPSF_x_3cell','tif');
saveas(gcf,'SavedData/all_optical_invivo_PPSF_x_3cell','fig');
saveas(gcf,'SavedData/all_optical_invivo_PPSF_x_3cell','pdf');
save('SavedData/all_optical_invivo_PPSF_x_3cell.mat','S','x','a1','b1','c1','Smean','Sstd');
%% fit with function and compute FWHM
addpath('C:\Research Data\3D-MAP manuscript');
X=interp(x,50);
for i=1:10
[fitresult, gof] = function_createGaussianFit(x', S(:,i));
Y=exp(-((X-fitresult.b1)/fitresult.c1).^2);
[~,Ind1] = min(abs(Y(1:round(numel(Y)/2))-0.5));
[~,Ind2] = min(abs(Y(round(numel(Y)/2)+1:end)-0.5));
FWHM(i)=X(Ind2+round(numel(Y)/2))-X(Ind1);
end
%%
save('all_optical_invivo_PPSF_x_8cells_finalselection.mat','Snew','x');