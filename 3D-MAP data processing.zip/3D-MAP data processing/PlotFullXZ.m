clear all;close all;clc

Foldername='9-27-19BrainSlice-PCH';
Xratio=0.676;%from calibration data
Zratio=0.888;
Filename='9-27-19-BrainSliceChromson-B-2DXZ';
cellNum='B';
load([Foldername '\' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;
%% 
UX=ToSave.Data.UX*Xratio;
UZ=ToSave.Data.UZ*Zratio;
PXX=reshape(ToSave.Data.PXX*Xratio,[length(UX) length(UZ)]);
PZZ=reshape(ToSave.Data.PZZ*Zratio,[length(UX) length(UZ)]);
if ProcessData==1
    for j=1:size(ToSave.Data.XZ,2)
        if find(cellfun(@isempty,ToSave.Data.XZ(:,j)))
            break;
        else
            for i=1:size(ToSave.Data.XZ,1)
                [ SXZ(i,j), odata,spikeremoveflag] = function_score_voltageclamp( Setup,ToSave.Stim,-cell2mat(ToSave.Data.XZ(i,j)),spikeremoveflag);            
            end
        end
    end
else
    SXZ=cell2mat(ToSave.Data.SXZ);
end
SXZ2D=reshape(mean(SXZ,2),[length(UX) length(UZ)]);

[~,Ind]=max(mean(SXZ,2));
if numel(Ind)>1
    [~,ind]=min(abs(Ind-length(SXZ)/2));
    Ind=Ind(ind);
end

[I,J]=ind2sub([length(UX) length(UZ)],Ind);
%% get diagonal from the peak
x=(I-J+1):size(SXZ2D,1);
y=1:length(x);
for k=1:length(x)
    diagSXZ(k)=SXZ2D(x(k),y(k));
end
d=sqrt((UX(1)-UX(2))^2+(UZ(1)-UZ(2))^2);
UXZ=-(J-1)*d:d:(length(x)-J)*d;
    
[GaussianXZ, gofxz] = createFit(UXZ, diagSXZ);
FWHMxz=FWHMofGaussian( GaussianXZ, UXZ );
%%
figure();
set(gcf, 'Position',  [300, 300,1000, 400])
subplot(1,2,1);
imagesc(UX,UZ,SXZ2D');
title(['Cell ' cellNum ' : XZ PPSF']);
axis image;xlabel('X (\mum)');ylabel('Z (\mum)');
colorbar;
set(gca,'FontSize',16);

subplot(1,2,2);plot(GaussianXZ, UXZ, diagSXZ);title(['Cell ' cellNum ' : diag XZ PPSF']);
grid on;xlim([min(UZ) max(UZ)]);xlabel('XZ (\mum)');
dim = [0.58 0.6 0.3 0.3];
str = {['FWHMxz=' num2str(FWHMxz) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');

dim = [0.4 0.7 0.3 0.3];
str = {['Repeat ' num2str(size(SXZ,2)) ', spikeremove=' num2str(spikeremoveflag)]};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
%%
saveas(gcf,[Foldername '\' Filename 'plot_processData' num2str(ProcessData) '.tif']);
save([Foldername '\FullXZ_' Filename '_' cellNum '.mat'],'SXZ2D','diagSXZ','UXZ','UX','UZ','GaussianXZ');