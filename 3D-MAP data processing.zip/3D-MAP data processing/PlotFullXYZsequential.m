% plot 3D PPSF from sequential measurement
clear all;close all;clc

Foldername='10-4-19 BrainSlice mapping';
Xratio=0.676;%from calibration data
Yratio=0.676;
Zratio=0.888;
Filename='10-4-19-BrainSlice-G-exc-map_7_3Dseq';
cellNum='J';
load([Foldername '\' Filename '.mat']);
ProcessData=1;
Setup.Scorepikes.Method=0;
spikeremoveflag=0;
%% 
UX=ToSave.Data.UX*Xratio;
UY=ToSave.Data.UY*Yratio;
UZ=ToSave.Data.UZ*Zratio;
Nx=numel(ToSave.Data.UX);
Ny=numel(ToSave.Data.UY);
Nz=numel(ToSave.Data.UZ);
Score2D=zeros(Nx*Ny,Nz);
    for j=1:size(ToSave.Data.XYZ,2)
        if find(cellfun(@isempty,ToSave.Data.XYZ(:,j)))
            break;
        else
            for i=1:size(ToSave.Data.XYZ,1)
                ToSave.Stim.baseline=mean((1-ToSave.Stim.CropMask').*cell2mat(ToSave.Data.XYZ(i,j)));
                Data=-cell2mat(ToSave.Data.XYZ(i,j));%voltage clamp
                Data=Data.*ToSave.Stim.CropMask';
                Data(Data==0)=[];
                DataMatrix=reshape(Data,[numel(Data)/Nz,Nz]);
                for p=1:Nz
                    [ Score2D(i,p), odata,spikeremoveflag] = function_score_voltageclamp( Setup,ToSave.Stim,DataMatrix(:,p),spikeremoveflag);          
                end
            end
        end
    end
Score=reshape(Score2D',[Nx,Ny,Nz]);
%%
imshow3D( Score );
%%
for i=1:Nz
figure(i+100);
set(gcf, 'Position',  [300, 300,500, 400])
imagesc(UX,UY,Score(:,:,i));
title(['Cell ' cellNum ' : XYZ PPSF, Z=' num2str(UZ(i))]);
axis image;xlabel('X (\mum)');ylabel('Y (\mum)');
caxis([min(Score(:)), max(Score(:))]);
colorbar;
set(gca,'FontSize',16);
saveas(gcf,[Foldername '\G-3D-map\' Filename 'plot_processData' num2str(i) '.tif']);
end
% %% get diagonal from the peak
% x=(I-J+1):size(SXZ2D,1);
% y=1:length(x);
% for k=1:length(x)
%     diagSXZ(k)=SXZ2D(x(k),y(k));
% end
% d=sqrt((UX(1)-UX(2))^2+(UZ(1)-UZ(2))^2);
% UXZ=-(J-1)*d:d:(length(x)-J)*d;
%     
% [GaussianXZ, gofxz] = createFit(UXZ(4:6), diagSXZ(4:6));
% FWHMxz=FWHMofGaussian( GaussianXZ, UXZ );
% %%
% figure();
% set(gcf, 'Position',  [300, 300,1000, 400])
% subplot(1,2,1);
% imagesc(UX,UZ,SXZ2D');
% title(['Cell ' cellNum ' : XZ PPSF']);
% axis image;xlabel('X (\mum)');ylabel('Z (\mum)');
% colorbar;
% set(gca,'FontSize',16);
% 
% subplot(1,2,2);plot(GaussianXZ, UXZ, diagSXZ);title(['Cell ' cellNum ' : diag XZ PPSF']);
% grid on;xlim([min(UZ) max(UZ)]);xlabel('XZ (\mum)');
% dim = [0.58 0.6 0.3 0.3];
% str = {['FWHMxz=' num2str(FWHMxz) '\mum']};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
% 
% dim = [0.4 0.7 0.3 0.3];
% str = {['Repeat ' num2str(size(SXZ,2)) ', spikeremove=' num2str(spikeremoveflag)]};
% annotation('textbox',dim,'String',str,'FitBoxToText','on');
%%
save([Foldername '\FullXYZscore_' Filename '_' cellNum '.mat'],'Score');