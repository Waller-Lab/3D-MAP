function [ score, odata] = function_scorespikes( Setup,Stim,data)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here
Fs = 1/(Stim.UT(2)-Stim.UT(1));
Setup.Scorepikes.SpikeSTDDetectionthreshold=10;
Setup.RCCutoffFrequencyHz=500;
Setup.Scorepikes.MinPeakDistance=0.003;
Setup.Scorepikes.baselineduration=0.04;
Setup.Scorepikes.Photocurrentwindowduration=0.01;
% Case where we count the number of spikes... returns High pass filtered
% data and number of spikes that are away from data std.
if Setup.Scorepikes.Method == 1
    [ HPData, ~ ] = function_RC_filter( data, 1/(Stim.UT(2)-Stim.UT(1)),Setup.RCCutoffFrequencyHz );
%     figure(1);subplot(2,1,1);plot(data);drawnow;
    data = HPData-mean(HPData);
    odata = data;
    data = abs(data);
    threshold = Setup.Scorepikes.SpikeSTDDetectionthreshold *std(data(end-50:end));
    
    if (~isempty(find(data(200:end)>threshold, 1)))
          score=1;
%         [~,spiketimes]=findpeaks(data, 'minpeakheight',threshold,'minpeakdistance',Fs*Setup.Scorepikes.MinPeakDistance);
%         spiketimes = spiketimes';
%         spiketimes = spiketimes/Fs;
    else
%         spiketimes = [];
          score=0;
    end
%     spikes1=find(spiketimes>0);
%     score=length(spikes1);
%     figure(1);subplot(2,1,2);plot(HPData);title(num2str(score));drawnow;
%     pause(0.5);
    %Case where we measure the magnitude of the biggest peak.
elseif Setup.Scorepikes.Method == 0
    odata = data;
    baseline =mean(data(1:floor(Fs*Setup.Scorepikes.baselineduration)));
%    
    data = data-baseline;
    baselinepeak = max(abs(medfilt1(data(1:floor(Fs*Setup.Scorepikes.baselineduration)))));
   
    nonzerovalues = find(Stim.Output(:,1));
if numel(nonzerovalues)==0
    score = 0;
else
    score = max(abs(medfilt1(data))-baselinepeak);
end

else
    %Case where we are being stupid
    disp('Not a valid spike evaluation method')
end
end

