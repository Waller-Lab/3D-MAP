function [  ] = function_StopCam( cam )
%UNTITLED2 Summary of this function goes here
%   Detailed explanation goes here

cam.Exit;

end

