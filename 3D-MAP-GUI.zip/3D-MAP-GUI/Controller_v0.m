function varargout = Controller_v0(varargin)
% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Controller_v0_OpeningFcn, ...
    'gui_OutputFcn',  @Controller_v0_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end
if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
end

% --- Executes just before Controller_v0 is made visible.
function Controller_v0_OpeningFcn(hObject, eventdata, handles, varargin)
clc;
disp('Welcome to Partially Coherenet Holography GUI v0');disp('Nidaq Starting');
handles.Setup = Function_Load_Parameters('EphyS ON');
disp('Started')
global DAQstate;
global status; status = 1; % 1 if ok to continue
global SaveID; SaveID=0;
global ToSave;
global Stage;
global Cloud;
global StageStatus; StageStatus=0;
DAQstate=[0 0 0 0 0 0 0];
handles.stageposition = [0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0); %Reset slider
set(handles.slider2,'Value',0); % Reset slider
set(handles.edit3,'string',0); %Initial stim laser Voltage
set(handles.edit4,'string',0); %Initial Imaging laser voltageset(handles.edit6,'string',int2str(10)); %Number of pulses
set(handles.edit6,'string',int2str(1)); % Number of pulses
set(handles.edit7,'string',int2str(80)); % Frequency in Hertz
set(handles.edit8,'string',int2str(4)); % Pulse duration in ms
set(handles.edit9,'string',int2str(1)); % Number of repetitions
set(handles.edit10,'string',int2str(0)); % Delay between repeitions in seconds
set(handles.edit11,'string',num2str(4)); %Stim laser voltage,center (default)
set(handles.edit50,'string',num2str(5)); %Stim laser voltage,edge
set(handles.edit29,'string',num2str(0.09)); %Pre stimulation delay in seconds
set(handles.edit30,'string',num2str(0.8)); %Pulsed lase Duty cycle between 0 and 1
set(handles.edit12,'string',num2str(1.5)); %Voltage sweep start voltage
set(handles.edit13,'string',num2str(5.5));%Voltage sweep End voltage
set(handles.edit14,'string',num2str(10));%Voltage sweep number of steps
set(handles.edit16,'string',num2str(0)); %Targets positions pixels X
set(handles.edit17,'string',num2str(0)); %Targets positions pixels Y
set(handles.edit18,'string',num2str(0)); %Targets positions pixels Z
set(handles.edit19,'string',num2str(10)); %Target radius
set(handles.edit20,'string',num2str(-600)); % PPSFRange of measurements on X axis in pixels,start
set(handles.edit21,'string',num2str(-600));% PPSF Range of measurements on Y axis in pixels,start
set(handles.edit22,'string',num2str(-60));% PPSFRange of measurements on Z axis in pixels,start
set(handles.edit47,'string',num2str(600)); % PPSFRange of measurements on X axis in pixels,end
set(handles.edit48,'string',num2str(600));% PPSF Range of measurements on Y axis in pixels,end
set(handles.edit49,'string',num2str(-60));% PPSFRange of measurements on Z axis in pixels,end
set(handles.edit23,'string',num2str(20));% PPSF number of points on X axis
set(handles.edit24,'string',num2str(20));% PPSF number of points on Y axis
set(handles.edit25,'string',num2str(1));% PPSF number of points on Z axis
set(handles.edit26,'string','OFF');%Stage X
set(handles.edit27,'string','OFF');%Stage Y
set(handles.edit28,'string','OFF');%Stage Z
set(handles.edit39,'string',num2str(0.05));%Timesweep Min stim duration [ms]
set(handles.edit40,'string',num2str(3));%Timesweep Max stim duration [ms]
set(handles.edit41,'string',num2str(15));%Timesweep number of steps
set(handles.edit55,'string',num2str(2.5));% Sampling grid
set(handles.edit56,'string',num2str(20));%number of simultaneous foci
Cloud.divider = handles.Setup.PointCloud.divider;% number of legs
Cloud.AngleMagnitude = handles.Setup.PointCloud.AngleMagnitude;% galvo voltage
Cloud.AngleMagnitudeBackup = Cloud.AngleMagnitude;
Cloud.AnlgeMagnitudeOffset = handles.Setup.PointCloud.GalvoOffsetVoltage;
Cloud.CycleLength = handles.Setup.PointCloud.CycleLength;
set(handles.edit42,'string',int2str(handles.Setup.PointCloud.divider));% number of legs
set(handles.edit43,'string',num2str(handles.Setup.PointCloud.AngleMagnitude));% galvo voltage
set(handles.edit44,'string',num2str(handles.Setup.PointCloud.CycleLength*1000));%cycle length ms
set(handles.edit31,'string',['Dummy_File_' int2str(floor(rand(1,1)*10000))]);%Stage Z
Stim.BlankFrame = ones(handles.Setup.DMD.LX,handles.Setup.DMD.LY);
set(handles.checkbox1,'Value', 1);
set(handles.checkbox2,'Value', 0);
set(handles.checkbox8,'Value', 0);
set(handles.checkbox11,'Value', 0);
function_directfeed_DMD( handles.Setup,Stim.BlankFrame);
handles.output = hObject;
guidata(hObject, handles);
end


% --- Executes Temporal Optimization
function pushbutton21_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);set(handles.edit4,'string',0);
Stim.Npeaks = str2num(get(handles.edit6,'string')); % Number of blue light pulses in test
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
if get(handles.checkbox3,'Value') == 1
    Stim.Timeramp = exp(linspace(log(str2num(get(handles.edit39,'string'))/1000),log(str2num(get(handles.edit40,'string'))/1000),floor(str2num(get(handles.edit41,'string')))));
else
    Stim.Timeramp = linspace(str2num(get(handles.edit39,'string'))/1000,str2num(get(handles.edit40,'string'))/1000,floor(str2num(get(handles.edit41,'string')))); %Voltage ramp to test how much light is needed to stim...
end
Stim.DutyCycle = str2num(get(handles.edit29,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup,Cloud );
Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
% while Stim.Output(find(Stim.UUT>Stim.DelayBorder,1,'first'),1)~=0
%     Stim.DelayBorder=Stim.DelayBorder+0.0001;
% end 
Stim.Baseline = Stim.Output(:,1);

axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
Stim.Output(end,:)=0;
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2302
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'master');
end
Result.DMDFrames =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
function_feed_DMD(handles.Setup, uint8(gather(Result.DMDFrames))*255);

for i = 1:floor(str2num(get(handles.edit9,'string'))) % Do many repetitions
    for j = 1:numel(Stim.Timeramp)
        if status == 0; disp('Procedure interrupted');  break; end;
        Stim.Output(1:end-1,1)=Stim.Voltage;
        Stim.nonzerovalues = find(Stim.Output(:,1));
        Stim.Output(1:end-1,6)=1;
        Stim.Output(:,2:5)=0;
        Stim.Output(:,7)=0;
        for n = 1:Stim.Npeaks
            Stim.Output(:,7) = Stim.Output(:,7)+double(Stim.UUT>Stim.DelayBorder+(n-1)/Stim.FreqHZ)'.*double(Stim.UUT<Stim.DelayBorder+Stim.Timeramp(j)+(n-1)/Stim.FreqHZ)';
        end
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);
        [ HPData, LPData ] = function_RC_filter( Data, 1/(Stim.UT(2)-Stim.UT(1)),handles.Setup.RCCutoffFrequencyHz );
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
        Stim.baseline=mean(Data(1:100));
        [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
        Cell.Timescore{j,i} = score;
        DataSave{j,i} = Data;
        axes(handles.axes2); 
        scatter(Stim.Timeramp(j),Cell.Timescore{j,i},'filled','red'); hold on;xlabel('Pulse duration'); ylabel('Ephys score [AU]');title(['Calibration pass ' int2str(i) 'of' int2str(floor(str2num(get(handles.edit9,'string'))))])
        axes(handles.axes3);
        plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage'); title([ 'Score = ' num2str(floor(Cell.Timescore{j,i}*100)/100)]);
        axes(handles.axes4);
        plot(Stim.UUT,Stim.Output(:,7));xlabel('Time [s]'); ylabel('Stim laser [V]');title(['Sequence ' int2str(i) ' of ' int2str(floor(str2num(get(handles.edit9,'string'))))]);

    end
end
handles.Setup=function_StopProj_DMD(handles.Setup);
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
try
    ToSave.type = 'Temporal Optimization';
    ToSave.Stim = Stim;
    ToSave.status = status;
    ToSave.Data = DataSave;
    ToSave.VoltageScores = Cell.Timescore;
    ToSave.VoltageRamp = Stim.Voltageramp;
catch;
end;
    if get(handles.checkbox1,'Value') == 1
        filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
        save(filename,'ToSave');
        disp('Data Saved')
    end  

end

% --- Executes ForceGalvoStop
function checkbox4_Callback(hObject, eventdata, handles)
global Cloud;
if get(handles.checkbox4,'Value')==1
    Cloud.AngleMagnitude=0;
    set(handles.edit43,'string',num2str(Cloud.AngleMagnitude));% galvo voltage
    if get(handles.checkbox2,'Value') == 0
        handles.Setup.PointCloud.GalvoOffsetVoltage=[0, 0];
        Cloud.AnlgeMagnitudeOffset=[0,0];
    else
        handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2, 2.7];
        Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
    end
else
    Cloud.AngleMagnitude=Cloud.AngleMagnitudeBackup;
    set(handles.edit43,'string',num2str(Cloud.AngleMagnitude));% galvo voltage
end
end

% --- Executes RUN STIM
function pushbutton2_Callback(hObject, eventdata, handles)
global DAQstate;
global status;
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
status = 1;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);
Stim.Npeaks = str2num(get(handles.edit6,'string')); % Number of blue light pulses in test
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup,Cloud );
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
if get(handles.checkbox2,'Value') == 0
    Stim.Output(:,5)=0;
%     select = Stim.UT<2*handles.Setup.Scorepikes.sealtestduration.* Stim.UT>handles.Setup.Scorepikes.sealtestduration;
%     Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
    select = Stim.UT<handles.Setup.Scorepikes.sealtestduration;    
    tempOutput=Stim.Output;
    tempOutput(1:end,:)=0;
    tempOutput(select,5)=1;
    queueOutputData(handles.Setup.Daq,tempOutput);
    startForeground(handles.Setup.Daq);
    pause(0.5);
else
    Stim.Output(:,5) =0;
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
% while Stim.Output(find(Stim.UUT>Stim.DelayBorder,1,'first'),1)~=0
%     Stim.DelayBorder=Stim.DelayBorder+0.0001;
% end 
Stim.Array = zeros(size(Stim.UUT));
Stim.Array1=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);%remove last rising edge
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
% Stim.Output(:,6)=Stim.Array1';
axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
Stim.Output(end,:)=0;
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end
for i = 1:floor(str2num(get(handles.edit9,'string')));
    if status == 0; disp('Procedure interrupted');  break; end;
    Result.DMDFrames =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
    function_feed_DMD(handles.Setup, uint8(gather(Result.DMDFrames))*255);
    queueOutputData(handles.Setup.Daq,Stim.Output);
    Data=startForeground(handles.Setup.Daq);
    [ HPData, LPData ] = function_RC_filter( Data, 1/(Stim.UT(2)-Stim.UT(1)),handles.Setup.RCCutoffFrequencyHz );
    if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
    Stim.baseline=mean(Data(1:100));
    [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
    %f = figure(1);
    axes(handles.axes2);
    plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage'); hold off;title([ 'Ephys Data , Score = ' num2str(floor(score*100)/100)]);
    axes(handles.axes3);
    plot(Stim.UUT,HPData);xlabel('Time s'); ylabel('Voltage'); title([ 'High Passed, Score = ' num2str(floor(score*100)/100)]);
    axes(handles.axes4);
    if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
        plot(Stim.UUT,Stim.Output(:,2));xlabel('Time [s]'); ylabel('Stim laser [V]');title(['Sequence ' int2str(i) ' of ' int2str(floor(str2num(get(handles.edit9,'string'))))]);
    else
        plot(Stim.UUT,Stim.Output(:,1));xlabel('Time [s]'); ylabel('Stim laser [V]');title(['Sequence ' int2str(i) ' of ' int2str(floor(str2num(get(handles.edit9,'string'))))]);
    end  
        
    axes(handles.axes5);
    scatter(i,score,'filled','red'), xlabel('Trial #'); ylabel('score [AU]'); hold on;
    pause(str2num(get(handles.edit10,'string')));
    DataSave{i} = Data;
    disp(['Repetition #' num2str(i) '/' get(handles.edit9,'string') ' finished!']);
end
handles.Setup=function_StopProj_DMD(handles.Setup);
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
ToSave.status = status;
ToSave.type = 'Undefined Stimulation cycle, rawdata';
ToSave.Stim = Stim;
ToSave.Data = DataSave;
if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end
end

% --- Executes Optimize voltage
% function pushbutton3_Callback(hObject, eventdata, handles)
% global DAQstate; global status;status = 1;
% global ToSave;
% global Cloud;
% global SaveID; SaveID=SaveID+1;
% DAQstate = [0 0 0 0 0 0];
% outputSingleScan(handles.Setup.Daq,DAQstate);
% set(handles.slider3,'Value',0)
% set(handles.slider2,'Value',0)
% set(handles.edit3,'string',0);
% set(handles.edit4,'string',0);
% Stim.Npeaks = str2num(get(handles.edit6,'string')); ; % Number of blue light pulses in test
% Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
% Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
% Stim.Voltage = str2num(get(handles.edit11,'string'));
% Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
% Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
% Stim.DutyCycle = str2num(get(handles.edit29,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
% Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
% Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
% [Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
% handles.Setup.PointCloud.GalvoOffsetVoltage=[0, 0];
% Cloud.AnlgeMagnitudeOffset=[0,0];
% [ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup,Cloud );
% Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
% if get(handles.checkbox2,'Value') == 0
%     Stim.Output(:,5)=0;
% %     select = Stim.UT<2*handles.Setup.Scorepikes.sealtestduration.* Stim.UT>handles.Setup.Scorepikes.sealtestduration;
% %     Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
%     select = Stim.UT<handles.Setup.Scorepikes.sealtestduration;    
%     tempOutput=Stim.Output;
%     tempOutput(1:end,:)=0;
%     tempOutput(select,5)=1;
%     queueOutputData(handles.Setup.Daq,tempOutput);
%     startForeground(handles.Setup.Daq);
%     pause(0.5);
% else
%     Stim.Output(:,5) =0;
% end
% Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
% Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
% [Stim.LN,Stim.LX] = size(Stim.Output);
% Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
% Stim.Array = Stim.UUT-Stim.UUT;
% Stim.Array1=Stim.Array;
% for i = 1:Stim.Npeaks
%     Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
%     Stim.Array1=Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ-0.0003);
% end
% Stim.Baseline = Stim.Output(:,1);
% if get(handles.checkbox8,'Value') == 1
%     Stim.Output(:,1)=0;
%     Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
% else   
%     Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
%     Stim.Output(:,2)=0;
% end
% Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
% %g = figure(2);
% DAQstate = [DAQstate(1) DAQstate(2) handles.Setup.PointCloud.GalvoOffsetVoltage(1) handles.Setup.PointCloud.GalvoOffsetVoltage(2) 0 0];
% Result.DMDFrames =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
% [handles.Setup,Cloud.targetid] = function_feed_DMD( handles.Setup,squeeze(uint8(gather(Result.DMDFrames(:,:,1)))*255),0);
% axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
% DataSave = {};
% for i = 1:floor(str2num(get(handles.edit9,'string'))) % Do many repetitions
%     for j = 1:numel(Stim.Voltageramp)
%         if status == 0; disp('Procedure interrupted');  break; end;
%         if get(handles.checkbox8,'Value') == 1
%             Stim.Output(:,2) = Stim.Voltageramp(j)*Stim.Baseline.*Stim.Array';
%         else
%             Stim.Output(:,1) = Stim.Voltageramp(j)*Stim.Baseline.*Stim.Array';
%         end
%         queueOutputData(handles.Setup.Daq,Stim.Output);
%         Data=startForeground(handles.Setup.Daq);
%         if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
%         [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
%         Cell.Powerscore{j,i} = score;
%         DataSave{j,i} = Data;
%         axes(handles.axes2); 
%         scatter(Stim.Voltageramp(j),Cell.Powerscore{j,i},'filled','red'); hold on;xlabel('Voltage on laser'); ylabel('Ephys score [AU]');title(['Calibration pass ' int2str(i) 'of' int2str(floor(str2num(get(handles.edit9,'string'))))])
%         axes(handles.axes3);
%         plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage'); title([ 'Score = ' num2str(floor(Cell.Powerscore{j,i}*100)/100)]);
%         axes(handles.axes4);
%         plot(Stim.UUT,Stim.Output(:,1));xlabel('Time [s]'); ylabel('Stim laser [V]');title(['Sequence ' int2str(i) ' of ' int2str(floor(str2num(get(handles.edit9,'string'))))]);
% 
%     end
% end
% if status == 0
% else;
%     Cell.BestLaserVoltage = ginput(1); %close(g);
%     scatter(Cell.BestLaserVoltage(1),Cell.BestLaserVoltage(2),'filled','blue'); title('Optimized voltage selected');
%     Cell.BestLaserVoltage = Cell.BestLaserVoltage(1);
%     set(handles.edit11,'string',num2str(Cell.BestLaserVoltage));
%     ToSave.type = 'Voltage Optimization';
%     ToSave.Stim = Stim;
%     ToSave.Data = DataSave;
%     ToSave.status = status;
%     ToSave.VoltageScores = Cell.Powerscore;
%     ToSave.VoltageRamp = Stim.Voltageramp;
%     if get(handles.checkbox1,'Value') == 1
%         filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
%         save(filename,'ToSave');
%         disp('Data Saved')
%     end  
% end
% end

function pushbutton3_Callback(hObject, eventdata, handles)
global DAQstate;
global status;
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
status = 1;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);
Stim.Npeaks = str2num(get(handles.edit6,'string')); % Number of blue light pulses in test
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup,Cloud );
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
Stim.Output(:,5) =0;
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);%remove last rising edge
end
Stim.Baseline = repmat(double(Stim.Subclock<0.8),[1 Stim.NumberCycles])';
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
% Stim.Output(:,6)=Stim.Array1';    
axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
Stim.Output(end,:)=0;
DataSave = {};
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end
for i = 1:floor(str2num(get(handles.edit9,'string'))) % Do many repetitions
    for j = 1:numel(Stim.Voltageramp)
        if status == 0; disp('Procedure interrupted');  break; end;
        if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1 
            Stim.Output(:,2) = Stim.Voltageramp(j)*Stim.Baseline.*Stim.Array';
%             Stim.Output(:,2) = Stim.Voltageramp(j).*Stim.Array';
            Stim.Output(:,1)=0;
            Stim.nonzerovalues = find(Stim.Output(:,2));
        else
            Stim.Output(:,1) = Stim.Voltageramp(j)*Stim.Baseline.*Stim.Array';
%             Stim.Output(:,1) = Stim.Voltageramp(j).*Stim.Array';
            Stim.Output(:,2)=0;
            Stim.nonzerovalues = find(Stim.Output(:,1));
        end
        Result.DMDFrames =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
        [handles.Setup,~]=function_feed_DMD(handles.Setup, uint8(gather(Result.DMDFrames))*255);
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);
        [ HPData, LPData ] = function_RC_filter( Data, 1/(Stim.UT(2)-Stim.UT(1)),handles.Setup.RCCutoffFrequencyHz );
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
        Stim.baseline=mean(Data(1:100));
        [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
       
        Cell.Powerscore{j,i} = score;
        DataSave{j,i} = Data;
        axes(handles.axes2); 
        scatter(Stim.Voltageramp(j),Cell.Powerscore{j,i},'filled','red'); hold on;xlabel('Voltage on laser'); ylabel('Ephys score [AU]');title(['Calibration pass ' int2str(i) 'of' int2str(floor(str2num(get(handles.edit9,'string'))))])
        axes(handles.axes3);
        plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage'); title([ 'Score = ' num2str(floor(Cell.Powerscore{j,i}*100)/100)]);
        axes(handles.axes4);
        if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
        plot(Stim.UUT,Stim.Output(:,2));xlabel('Time [s]'); ylabel('Stim laser [V]');title(['Sequence ' int2str(i) ' of ' int2str(floor(str2num(get(handles.edit9,'string'))))]);
        else
          plot(Stim.UUT,Stim.Output(:,1));xlabel('Time [s]'); ylabel('Stim laser [V]');title(['Sequence ' int2str(i) ' of ' int2str(floor(str2num(get(handles.edit9,'string'))))]);
        end  
    end
end
if status == 0
else;
    Cell.BestLaserVoltage = ginput(1); %close(g);
    scatter(Cell.BestLaserVoltage(1),Cell.BestLaserVoltage(2),'filled','blue'); title('Optimized voltage selected');
    Cell.BestLaserVoltage = Cell.BestLaserVoltage(1);
    set(handles.edit13,'string',num2str(Cell.BestLaserVoltage));
    set(handles.edit11,'string',num2str(Cell.BestLaserVoltage));
    ToSave.type = 'Voltage Optimization';
    ToSave.Stim = Stim;
    ToSave.Data = DataSave;
    ToSave.status = status;
    ToSave.VoltageScores = Cell.Powerscore;
    ToSave.VoltageRamp = Stim.Voltageramp;
    if get(handles.checkbox1,'Value') == 1
        filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
        save(filename,'ToSave');
        disp('Data Saved')
    end  
end
end


% --- Executes DARK DMD
function pushbutton5_Callback(hObject, eventdata, handles)
global ToSave;
ToSave.DMDSTATE = 'DMD Dark';
Stim.BlankFrame = zeros(handles.Setup.DMD.LX,handles.Setup.DMD.LY);
ProjMode = function_CheckProjMode_DMD(Setup);
if ProjMode==2302
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(Setup,'master');
end
function_directfeed_DMD( handles.Setup,Stim.BlankFrame );
global DAQstate;
outputSingleScan(handles.Setup.Daq,DAQstate);
end

% --- Executes Display target
function pushbutton6_Callback(hObject, eventdata, handles)
global ToSave;
global Cloud;
global DAQstate;
ToSave.DMDSTATE = 'DMD Showing one target';
handles.Setup.PointCloud.AngleMagnitude = Cloud.AngleMagnitude;
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
DAQstate = [DAQstate(1) DAQstate(2) handles.Setup.PointCloud.GalvoOffsetVoltage(1) handles.Setup.PointCloud.GalvoOffsetVoltage(2) 0 0 0];
Result.DMDFrames =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2302
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'master');
end
[handles.Setup,Cloud.targetid] = function_feed_DMD( handles.Setup,squeeze(uint8(gather(Result.DMDFrames(:,:,1)))*255));
for i=1:4
    DAQstate(7)=1;
    DAQstate(6)=rem(i,2);
    outputSingleScan(handles.Setup.Daq,DAQstate);
end
end

% --- Executes BRIGHT DMD
function pushbutton7_Callback(hObject, eventdata, handles)
global ToSave;
global Cloud;
ToSave.DMDSTATE = 'DMD Bright';
Stim.BrightFrame = ones(handles.Setup.DMD.LX,handles.Setup.DMD.LY);
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2302
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'master');
end
[handles.Setup,Cloud.brightfieldid] = function_feed_DMD( handles.Setup,Stim.BrightFrame);
global DAQstate;
DAQstate(7)=1;
outputSingleScan(handles.Setup.Daq,DAQstate);
end


% --- Executes PPSF Mechanical
% function pushbutton17_Callback(hObject, eventdata, handles)
% global DAQstate; global status;status = 1;
% global StageStatus;
% global Stage;
% global Cloud;
% if StageStatus==0
%     Stage  = function_Start_stage( handles.Setup.SutterStage );
%     StageStatus = 1;
% end
% function_Zero_stage( Stage );
% DAQstate = [0 0 0 0 0 0];
% global ToSave;
% global SaveID; SaveID=SaveID+1;
% ToSave.DMDSTATE = 'DMD Digital PPSF Sequence';
% outputSingleScan(handles.Setup.Daq,DAQstate);
% set(handles.slider3,'Value',0);
% set(handles.slider2,'Value',0);
% set(handles.edit3,'string',0);
% set(handles.edit4,'string',0);
% Stim.Npeaks = floor(str2num(get(handles.edit6,'string'))); % Number of blue light pulses in test
% Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
% Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
% Stim.Voltage = str2num(get(handles.edit11,'string'));
% Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
% Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
% Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
% Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
% Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
% [Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
% if get(handles.checkbox8,'Value') == 0
%     handles.Setup.PointCloud.GalvoOffsetVoltage=[0, 0];
%     Cloud.AnlgeMagnitudeOffset=[0,0];
% else
%     handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
%     Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
% end
% [ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup,Cloud );
% Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
% if get(handles.checkbox2,'Value') == 0
%     Stim.Output(:,5)=0;
% %     select = Stim.UT<2*handles.Setup.Scorepikes.sealtestduration.* Stim.UT>handles.Setup.Scorepikes.sealtestduration;
% %     Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
%     select = Stim.UT<handles.Setup.Scorepikes.sealtestduration;    
%     tempOutput=Stim.Output;
%     tempOutput(1:end,:)=0;
%     tempOutput(select,5)=1;
%     queueOutputData(handles.Setup.Daq,tempOutput);
%     startForeground(handles.Setup.Daq);
%     pause(0.5);
% else
%     Stim.Output(:,5) =0;
% end
% Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
% Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
% [Stim.LN,Stim.LX] = size(Stim.Output);
% Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
% Stim.Array = Stim.UUT-Stim.UUT;
% for i = 1:Stim.Npeaks
%     Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
% end
% Stim.Baseline = Stim.Output(:,1);
% if get(handles.checkbox8,'Value') == 1
%     Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
%     Stim.nonzerovalues = find(Stim.Output(:,2));
%     Stim.Output(:,1)=0;
% else   
%     Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
%     Stim.Output(:,2)=0;
%     Stim.nonzerovalues = find(Stim.Output(:,1));
% end
% 
% if get(handles.checkbox3,'Value') == 1
% UX = function_logvec( -str2num(get(handles.edit20,'string')),floor(str2num(get(handles.edit23,'string'))));
% UY = function_logvec( -str2num(get(handles.edit21,'string')),floor(str2num(get(handles.edit24,'string'))));
% UZ = function_logvec( -str2num(get(handles.edit22,'string')),floor(str2num(get(handles.edit25,'string'))));
% else
% UX = linspace(str2num(get(handles.edit20,'string')),str2num(get(handles.edit47,'string')),floor(str2num(get(handles.edit23,'string'))));
% UY = linspace(str2num(get(handles.edit21,'string')),str2num(get(handles.edit48,'string')),floor(str2num(get(handles.edit24,'string'))));
% UZ = linspace(str2num(get(handles.edit22,'string')),str2num(get(handles.edit49,'string')),floor(str2num(get(handles.edit25,'string'))));
% end
% DataSave.UX = UX;
% DataSave.UY = UY;
% DataSave.UZ = UZ;
% DataSave.X = {};  DataSave.Y = {}; DataSave.Z = {}; DataSave.SX = {}; DataSave.SY = {}; DataSave.SZ = {};
% Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
% Cloud.divider = floor(str2num(get(handles.edit42,'string')));
% Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
% Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
% Cloud.divider = floor(str2num(get(handles.edit42,'string')));
% Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
% handles.Setup.PointCloud.AngleMagnitude = Cloud.AngleMagnitude;
% Result.DMDFrames =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
% function_feed_DMD(uint8(gather(Result.DMDFrames))*255);
% axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
% Stim.Output(end,:)=0;
% for j = 1:floor(str2num(get(handles.edit9,'string'))); %do as many repetitions as needed
%     if status == 0; disp('Procedure interrupted'); break; end;
%     for i = 1:floor(str2num(get(handles.edit23,'string')));
%         if status == 0; disp('Procedure interrupted'); break; end;
%         Position = [UX(i) 0 0];
%         function_Goto_stage( Stage,Position );
%         set(handles.edit26,'string',num2str(Position(1)));%Stage X
%         set(handles.edit27,'string',num2str(Position(2)));%Stage Y
%         set(handles.edit28,'string',num2str(Position(3)));pause(1);%Stage Z
%         queueOutputData(handles.Setup.Daq,Stim.Output);
%         Data=startForeground(handles.Setup.Daq);
%         [ HPData, LPData ] = function_RC_filter( Data, 1/(Stim.UT(2)-Stim.UT(1)),handles.Setup.RCCutoffFrequencyHz );
%         if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
%         [score, odata] = function_scorespikes(handles.Setup,Stim, Data );
%         axes(handles.axes5);plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage'); title([ 'Ephys data , Score = ' num2str(score)]);
%         axes(handles.axes2);scatter(UX(i), score,'red','filled'); hold on; xlabel('X pixels'); ylabel('Score'); title('X PPSF');
%         pause(str2num(get(handles.edit10,'string')));
%         DataSave.X{i,j} = Data;
%         DataSave.SX{i,j} = score;
%     end
%     for i = 1:floor(str2num(get(handles.edit24,'string')));
%         if status == 0; disp('Procedure interrupted'); break; end;
%         Position = [0 UY(i) 0];
%         function_Goto_stage( Stage,Position );
%         set(handles.edit26,'string',num2str(Position(1)));%Stage X
%         set(handles.edit27,'string',num2str(Position(2)));%Stage Y
%         set(handles.edit28,'string',num2str(Position(3)));pause(1);%Stage Z
%         queueOutputData(handles.Setup.Daq,Stim.Output);
%         Data=startForeground(handles.Setup.Daq);
%         [ HPData, LPData ] = function_RC_filter( Data, 1/(Stim.UT(2)-Stim.UT(1)),handles.Setup.RCCutoffFrequencyHz );
%         if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
%         [score, odata] = function_scorespikes(handles.Setup,Stim, Data );
%         axes(handles.axes5);plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage'); title([ 'Ephys data , Score = ' num2str(score)]);
%         axes(handles.axes3);scatter(UY(i), score,'red','filled'); hold on;xlabel('Y pixels'); ylabel('Score'); title('Y PPSF');
%         pause(str2num(get(handles.edit10,'string')));
%         DataSave.Y{i,j} = Data;
%         DataSave.SY{i,j} = score;
%     end
%     for i = 1:floor(str2num(get(handles.edit25,'string')));
%         if status == 0;disp('Procedure interrupted');break; end;
%         Position = [ 0 0 UZ(i)];
%         function_Goto_stage( Stage,Position );
%         set(handles.edit26,'string',num2str(Position(1)));%Stage X
%         set(handles.edit27,'string',num2str(Position(2)));%Stage Y
%         set(handles.edit28,'string',num2str(Position(3)));pause(1);%Stage Z
%         queueOutputData(handles.Setup.Daq,Stim.Output);
%         Data=startForeground(handles.Setup.Daq);
%         [ HPData, LPData ] = function_RC_filter( Data, 1/(Stim.UT(2)-Stim.UT(1)),handles.Setup.RCCutoffFrequencyHz );
%         if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
%         [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
%         axes(handles.axes5);plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage'); title([ 'Ephys Data , Score = ' num2str(score)]);
%         axes(handles.axes4); scatter(UZ(i), score,'red','filled'); hold on;xlabel('Z pixels'); ylabel('Score'); title('Z PPSF');
%         pause(str2num(get(handles.edit10,'string')));
%         DataSave.Z{i,j} = Data;
%         DataSave.SZ{i,j} = score;
%     end
% end
% Position = [0 0 0];
% function_Goto_stage( Stage,Position );
% set(handles.edit26,'string',num2str(Position(1)));%Stage X
% set(handles.edit27,'string',num2str(Position(2)));%Stage Y
% set(handles.edit28,'string',num2str(Position(3)));pause(1);%Stage Z
% ToSave.type = 'Mechanical PPSF';
% ToSave.Stim = Stim;
% ToSave.status = status;
% ToSave.Data = DataSave;
% if get(handles.checkbox1,'Value') == 1
%     filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
%     save(filename,'ToSave');
%     disp('Data Saved')
% end
% end


% --- Executes Digital PPSF with just full XZ plane
function pushbutton22_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'DMD Digital PPSF Sequence';
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);
Stim.Npeaks = floor(str2num(get(handles.edit6,'string'))); % Number of blue light pulses in test
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
if get(handles.checkbox2,'Value') == 0
    Stim.Output(:,5)=0;
%     select = Stim.UT<2*handles.Setup.Scorepikes.sealtestduration.* Stim.UT>handles.Setup.Scorepikes.sealtestduration;
%     Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
    select = Stim.UT<handles.Setup.Scorepikes.sealtestduration;    
    tempOutput=Stim.Output;
    tempOutput(1:end,:)=0;
    tempOutput(select,5)=1;
    queueOutputData(handles.Setup.Daq,tempOutput);
    startForeground(handles.Setup.Daq);
    pause(0.1);
else
    Stim.Output(:,5) =0;
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
if get(handles.checkbox3,'Value') == 1
UX = function_logvec( -str2num(get(handles.edit20,'string')),floor(str2num(get(handles.edit23,'string'))));
UZ = function_logvec( -str2num(get(handles.edit22,'string')),floor(str2num(get(handles.edit25,'string'))));
else
UX = linspace(str2num(get(handles.edit20,'string')),str2num(get(handles.edit47,'string')),floor(str2num(get(handles.edit23,'string'))));
UZ = linspace(str2num(get(handles.edit22,'string')),str2num(get(handles.edit49,'string')),floor(str2num(get(handles.edit25,'string'))));
end
DataSave.UX = UX;
DataSave.UZ = UZ;
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end
[PXX,PZZ] = ndgrid(UX,UZ);
DataSave.PXX = PXX(:);
DataSave.PZZ = PZZ(:);

DataSave.XZ = {};  DataSave.SXZ = {};
axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed
    if j==1
        for i=1:numel(PXX(:))
            if status == 0; disp('Procedure interrupted'); break; end;
            [DMDFrames] =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string'))+DataSave.PXX(i),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string'))+DataSave.PZZ(i),str2num(get(handles.edit19,'string')));
            [handles.Setup,Cloud.sequenceid2D(i)] = function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames))*255);
        end
    end
    handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
    for i=1:numel(PXX(:))
        if status == 0; disp('Procedure interrupted'); break; end;
        Currentsequenceid=Cloud.sequenceid2D(i);
        handles.Setup = function_StartProj_DMD(handles.Setup, Currentsequenceid);
%         StimPower=Stim.Voltage+sqrt(PXX(i)^2+PZZ(i)^2)/sqrt(max(UX)^2+max(UZ)^2)*(5-Stim.Voltage);%increase power with distance to center
%         if get(handles.checkbox8,'Value') == 1
%             Stim.Output(:,2)=StimPower*Stim.Baseline.*Stim.Array';
%         else
%             Stim.Output(:,1)=StimPower*Stim.Baseline.*Stim.Array';
%         end
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        Stim.baseline=mean(Data(1:100));
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else handles.Setup.Scorepikes.Method=0; end;
        [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
        axes(handles.axes2);  scatter(DataSave.PXX(i),DataSave.PZZ(i), 25,score,'filled'); colorbar; hold on; xlabel('X pixels'); ylabel('Z pixels'); title('XZ PPSF score'); 
        axes(handles.axes5);  plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage');
        DataSave.XZ{i,j} = Data;
        DataSave.SXZ{i,j} = score;
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
    end
    disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
end
try
ToSave.type = 'Digital PPSF Full XZ plane';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
catch; end;
if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end
end


function edit42_Callback(hObject, eventdata, handles)
global Cloud;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
end

function edit43_Callback(hObject, eventdata, handles)
global Cloud;
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
if Cloud.AngleMagnitude>0
Cloud.AngleMagnitudeBackup = Cloud.AngleMagnitude;
end
end

function edit44_Callback(hObject, eventdata, handles)
global Cloud;
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
handles.Setup.PointCloud.CycleLength=Cloud.CycleLength;
end


% --- Executes Make PPSF digitally
function pushbutton8_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'DMD Digital PPSF Sequence';
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);
Stim.Npeaks = floor(str2num(get(handles.edit6,'string'))); % Number of blue light pulses in test
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup,Cloud );
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
if get(handles.checkbox2,'Value') == 0
    Stim.Output(:,5)=0;
%     select = Stim.UT<2*handles.Setup.Scorepikes.sealtestduration.* Stim.UT>handles.Setup.Scorepikes.sealtestduration;
%     Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
    select = Stim.UT<handles.Setup.Scorepikes.sealtestduration;    
    tempOutput=Stim.Output;
    tempOutput(1:end,:)=0;
    tempOutput(select,5)=1;
    queueOutputData(handles.Setup.Daq,tempOutput);
    startForeground(handles.Setup.Daq);
    pause(0.5);
else
    Stim.Output(:,5) =0;
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
if get(handles.checkbox3,'Value') == 1
UX = function_logvec( -str2num(get(handles.edit20,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = function_logvec( -str2num(get(handles.edit21,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = function_logvec( -str2num(get(handles.edit22,'string')),floor(str2num(get(handles.edit25,'string'))));
else
UX = linspace(str2num(get(handles.edit20,'string')),str2num(get(handles.edit47,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = linspace(str2num(get(handles.edit21,'string')),str2num(get(handles.edit48,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = linspace(str2num(get(handles.edit22,'string')),str2num(get(handles.edit49,'string')),floor(str2num(get(handles.edit25,'string'))));
end
DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
DataSave.X = {};  DataSave.Y = {}; DataSave.Z = {}; DataSave.SX = {}; DataSave.SY = {}; DataSave.SZ = {};
axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
Stim.Output(end,:)=0;
Nx=floor(str2num(get(handles.edit23,'string')));
Ny=floor(str2num(get(handles.edit24,'string')));
Nz=floor(str2num(get(handles.edit25,'string')));
Cloud.sequenceid1D.x=zeros(Nx,1);
Cloud.sequenceid1D.y=zeros(Ny,1);
Cloud.sequenceid1D.z=zeros(Nz,1);
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end

handles.Setup.DMD.SequenceControl.RepeatModeValue=Stim.Npeaks;
for j = 1:floor(str2num(get(handles.edit9,'string'))); %do as many repetitions as needed
    if status == 0; disp('Procedure interrupted'); break; end;
% Generate Patterns
    %generate patterns for x direction 
    if j==1 % only need to generate pattern once
        for i=1:Nx
            if status == 0; disp('Procedure interrupted'); break; end;
            [DMDFrames] =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string'))+UX(i),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
            [handles.Setup,Cloud.sequenceid1D.x(i)] = function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames))*255);
        end
        for i=1:Ny
            if status == 0; disp('Procedure interrupted'); break; end;
            [DMDFrames] =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string'))+UY(i),str2num(get(handles.edit18,'string')),str2num(get(handles.edit19,'string')));
            [handles.Setup,Cloud.sequenceid1D.y(i)] = function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames))*255);
        end
         for i=1:Nz
            if status == 0; disp('Procedure interrupted'); break; end;
            [DMDFrames] =  function_makespots(handles.Setup,str2num(get(handles.edit16,'string')),str2num(get(handles.edit17,'string')),str2num(get(handles.edit18,'string'))+UZ(i),str2num(get(handles.edit19,'string')));
            [handles.Setup,Cloud.sequenceid1D.z(i)] = function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames))*255);
         end
    end
        
    for i=1:Nx
        if status == 0; disp('Procedure interrupted'); break; end;
        handles.Setup = function_StartProj_DMD(handles.Setup, Cloud.sequenceid1D.x(i));
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else handles.Setup.Scorepikes.Method=0; end;
        Stim.baseline=mean(Data(end-100:end));
        [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
        axes(handles.axes2); scatter(UX(i), score,'red','filled'); hold on; xlabel('X pixels'); ylabel('Score'); title('X PPSF');
        axes(handles.axes5);plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage');
        DataSave.X{i,j} = Data;
        DataSave.SX{i,j} = score;
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
    end
    pause(str2num(get(handles.edit10,'string')));
    
    for i=1:Ny
        if status == 0; disp('Procedure interrupted'); break; end;
        handles.Setup = function_StartProj_DMD(handles.Setup, Cloud.sequenceid1D.y(i));
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else handles.Setup.Scorepikes.Method=0; end;
        Stim.baseline=mean(Data(1:100));
        [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
        axes(handles.axes2); scatter(UY(i), score,'red','filled'); hold on; xlabel('Y pixels'); ylabel('Score'); title('Y PPSF');
        axes(handles.axes5);plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage');
        DataSave.Y{i,j} = Data;
        DataSave.SY{i,j} = score;
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
    end
        pause(str2num(get(handles.edit10,'string')));
        
    for i=1:Nz
        if status == 0; disp('Procedure interrupted'); break; end;
        handles.Setup = function_StartProj_DMD(handles.Setup, Cloud.sequenceid1D.z(i));
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else handles.Setup.Scorepikes.Method=0; end;
        Stim.baseline=mean(Data(1:100));
        [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
        axes(handles.axes3); scatter(UZ(i), score,'red','filled'); hold on; xlabel('Z pixels'); ylabel('Score'); title('Z PPSF');
        axes(handles.axes5);plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage');
        DataSave.Z{i,j} = Data;        DataSave.SZ{i,j} = score;
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
%         outputSingleScan(handles.Setup.Daq,[0 0 0 0 0 0]);
    end
    pause(str2num(get(handles.edit10,'string')));
    
    axes(handles.axes2);cla;errorbar(UX, mean(cell2mat(DataSave.SX),2),std(cell2mat(DataSave.SX),[],2));
    axes(handles.axes3);cla;errorbar(UY, mean(cell2mat(DataSave.SY),2),std(cell2mat(DataSave.SY),[],2));
    axes(handles.axes4);cla;errorbar(UZ, mean(cell2mat(DataSave.SZ),2),std(cell2mat(DataSave.SZ),[],2));
    disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
end
try
ToSave.type = 'Digital PPSF';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
catch;end;
if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end
end

% ---  Executes  Stage on
function pushbutton9_Callback(hObject, eventdata, handles)
global Stage;
global StageStatus;
try
    Stage  = function_Start_stage( handles.Setup.MechStageComport );
    function_Zero_stage( Stage );
    StageStatus = 1;
    set(handles.edit26,'string',num2str(0));%Stage X
    set(handles.edit27,'string',num2str(0));%Stage Y
    set(handles.edit28,'string',num2str(0));%Stage Z
catch
    set(handles.edit26,'string','ERR');%Stage X
    set(handles.edit27,'string','ERR');%Stage Y
    set(handles.edit28,'string','ERR');%Stage Z
end
end

% --- Executes Stage Off
function pushbutton10_Callback(hObject, eventdata, handles)
global Stage;
global StageStatus;
try
    StageStatus=0;
    function_Stop_stage( Stage );
    set(handles.edit26,'string','OFF');%Stage X
    set(handles.edit27,'string','OFF');%Stage Y
    set(handles.edit28,'string','OFF');%Stage Z
catch
    set(handles.edit26,'string','ERR');%Stage X
    set(handles.edit27,'string','ERR');%Stage Y
    set(handles.edit28,'string','ERR');%Stage Z
end

end

% --- Executes Define stage zero
function pushbutton11_Callback(hObject, eventdata, handles)
global Stage;
global StageStatus;
try
    function_Zero_stage( Stage );
    handles.stageposition = [0 0 0];
    set(handles.edit26,'string',num2str(0));%Stage X
    set(handles.edit27,'string',num2str(0));%Stage Y
    set(handles.edit28,'string',num2str(0));%Stage Z
catch
    set(handles.edit26,'string','ERR');%Stage X
    set(handles.edit27,'string','ERR');%Stage Y
    set(handles.edit28,'string','ERR');%Stage Z
end
end

% --- Executes read stage position
function pushbutton12_Callback(hObject, eventdata, handles)
try
    global Stage;
    [ positionmicron ] = function_Get_stage(Stage );
    handles.stageposition = positionmicron;
    set(handles.edit26,'string',num2str(positionmicron(1)));%Stage X
    set(handles.edit27,'string',num2str(positionmicron(2)));%Stage Y
    set(handles.edit28,'string',num2str(positionmicron(3)));%Stage Z
catch
    set(handles.edit26,'string','ERR');%Stage X
    set(handles.edit27,'string','ERR');%Stage Y
    set(handles.edit28,'string','ERR');%Stage Z
end
end

% --- Executes go home as defined by zero
function pushbutton13_Callback(hObject, eventdata, handles)
try
    global Stage;
    position = [0 0 0]; function_Goto_stage( Stage,position ); pause(0.5);
catch
    set(handles.edit26,'string','ERR');%Stage X
    set(handles.edit27,'string','ERR');%Stage Y
    set(handles.edit28,'string','ERR');%Stage Z
end
end

% --- Executes Go to position
function pushbutton14_Callback(hObject, eventdata, handles)
try
    global Stage;
    stageposition = [0 0 0];
    stageposition(1) = str2num(get(handles.edit26,'string'));
    stageposition(2) = str2num(get(handles.edit27,'string'));
    stageposition(3) = str2num(get(handles.edit28,'string'));
    function_Goto_stage( Stage,stageposition ); pause(0.5);
catch
    set(handles.edit26,'string','ERR');%Stage X
    set(handles.edit27,'string','ERR');%Stage Y
    set(handles.edit28,'string','ERR');%Stage Z
end
end

% --- Executes  Properly QUIT GUI
function pushbutton15_Callback(hObject, eventdata, handles)
try
    global Stage;
    function_Stop_stage( Stage );
catch
end
close;
end

% --- Executes Interrupts execution
function Interrupt_Callback(hObject, eventdata, handles)
global status;
status = 0; % 1 if ok to continue
end

% --- Executes Adjust voltage for laser 1
function slider2_Callback(hObject, eventdata, handles)
h = get(hObject,'Value');
set(handles.edit3,'string',round(10*h)/10);
global DAQstate;
DAQstate(1) = h;
outputSingleScan(handles.Setup.Daq,DAQstate);
end

% --- Executes  Adjust voltage for Laser 2
function slider3_Callback(hObject, eventdata, handles)
h = get(hObject,'Value');
set(handles.edit4,'string',round(10*h)/10);
global DAQstate;
DAQstate(2) = h;
outputSingleScan(handles.Setup.Daq,DAQstate);
end

% --- Executes All lasers off
function pushbutton1_Callback(hObject, eventdata, handles)
global DAQstate;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0)
set(handles.slider2,'Value',0)
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);
end

%%%%%%%%% UNUSED COMMANDS BELOW
function edit6_Callback(hObject, eventdata, handles)
end

function edit6_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit7_Callback(hObject, eventdata, handles)
end

function edit7_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit8_Callback(hObject, eventdata, handles)
end
function edit8_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit9_Callback(hObject, eventdata, handles)
end

function edit9_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit10_Callback(hObject, eventdata, handles)
end

function edit10_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit11_Callback(hObject, eventdata, handles)
end

function edit11_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit12_Callback(hObject, eventdata, handles)
end

function edit12_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit13_Callback(hObject, eventdata, handles)
end

function edit13_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit14_Callback(hObject, eventdata, handles)
end

function edit14_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit16_Callback(hObject, eventdata, handles)
end

function edit16_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit17_Callback(hObject, eventdata, handles)
end

function edit17_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function varargout = Controller_v0_OutputFcn(hObject, eventdata, handles)
varargout{1} = handles.output;
end

function slider2_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
end

function slider3_CreateFcn(hObject, eventdata, handles)
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end
end

function edit3_Callback(hObject, eventdata, handles)
end

function edit3_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit4_Callback(hObject, eventdata, handles)
end

function edit4_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit18_Callback(hObject, eventdata, handles)
end

function edit18_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit19_Callback(hObject, eventdata, handles)
end

function edit19_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit20_Callback(hObject, eventdata, handles)
end

function edit20_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit21_Callback(hObject, eventdata, handles)
end

function edit21_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit22_Callback(hObject, eventdata, handles)
end

function edit22_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit23_Callback(hObject, eventdata, handles)
end

function edit23_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit24_Callback(hObject, eventdata, handles)
end

function edit24_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit25_Callback(hObject, eventdata, handles)
end

function edit25_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit26_Callback(hObject, eventdata, handles)
end

function edit26_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit27_Callback(hObject, eventdata, handles)
end

function edit27_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit28_Callback(hObject, eventdata, handles)
end

function edit28_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit29_Callback(hObject, eventdata, handles)
end

function edit29_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit30_Callback(hObject, eventdata, handles)
end

function edit30_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function checkbox1_Callback(hObject, eventdata, handles)
end

function edit31_Callback(hObject, eventdata, handles)
end

function edit31_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function checkbox2_Callback(hObject, eventdata, handles)
end

function checkbox3_Callback(hObject, eventdata, handles)
end


% --- Executes on button press in pushbutton19.
function pushbutton19_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton19 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
end


function edit32_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function edit32_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


function edit33_Callback(hObject, eventdata, handles)
end

function edit33_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


function edit34_Callback(hObject, eventdata, handles)
end

function edit34_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


function edit35_Callback(hObject, eventdata, handles)
end
    function edit35_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
    end

function uipanel4_CreateFcn(hObject, eventdata, handles)
end


% --- Executes on button press in pushbutton21.
function pushbutton20_Callback(hObject, eventdata, handles)
end

function edit39_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function edit39_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


function edit40_Callback(hObject, eventdata, handles)
end


function edit40_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


function edit41_Callback(hObject, eventdata, handles)
end
    
function edit41_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit36_Callback(hObject, eventdata, handles)
end

function edit36_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit37_Callback(hObject, eventdata, handles)
end

function edit37_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit38_Callback(hObject, eventdata, handles)
end
    function edit38_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
    end
function edit42_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end
function edit43_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit44_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Executes on button press in DigitalPPSFXZ.
function DigitalPPSFXZ_Callback(hObject, eventdata, handles)
% hObject    handle to DigitalPPSFXZ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global SaveID; SaveID=SaveID+1;
Xratio=handles.Setup.DataAnalysis.Xratio;
Zratio=handles.Setup.DataAnalysis.Zratio;
UX=ToSave.Data.UX*Xratio;
UZ=ToSave.Data.UZ*Zratio;
for j=1:size(ToSave.Data.X,2)
    for i=1:size(ToSave.Data.X,1)
        [ SX(i,j), ~] = function_scorespikes_averageAllpulses( handles.Setup,ToSave.Stim,cell2mat(ToSave.Data.X(i,j)));
        [ SZ(i,j), ~] = function_scorespikes_averageAllpulses( handles.Setup,ToSave.Stim,cell2mat(ToSave.Data.Z(i,j)));
    end
end
[GaussianX, ~] = createFit(UX', mean(SX,2));
[GaussianZ, ~] = createFit(UZ', mean(SZ,2));
FWHMx=function_FWHMofGaussian( GaussianX, UX );
FWHMz=function_FWHMofGaussian( GaussianZ, UZ );
DataSave.FWHMx_XZ=FWHMx;
DataSave.FWHMz_XZ=FWHMz;
DataSave.GaussianX_XZ=GaussianX;
DataSave.GaussianZ_XZ=GaussianZ;
ToSave.DataAnalysis = DataSave;
xzppsf=figure;
figure(xzppsf);
set(xzppsf, 'Position',  [300, 300, 1000, 400])
subplot(1,2,1);plot(GaussianX, UX, mean(SX,2));title(['X PPSF']);
grid on;xlim([min(UX) max(UX)]);xlabel('X (\mum)');
dim = [0.14 0.6 0.3 0.3];
str = {['FWHMx=' num2str(FWHMx) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
subplot(1,2,2);plot(GaussianZ, UZ, mean(SZ,2));title(['Z PPSF']);
grid on;xlim([min(UZ) max(UZ)]);xlabel('Z (\mum)');
dim = [0.58 0.6 0.3 0.3];
str = {['FWHMz=' num2str(FWHMz) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
    if get(handles.checkbox1,'Value') == 1
        filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
        save(filename,'ToSave');
        saveas(xzppsf,[filename '_XZPPSF_plot.tif']);
        disp('Data & Plot Saved');
    end
end

% --- Executes on button press in DigitalPPSFFullXZ.
function DigitalPPSFFullXZ_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global SaveID; SaveID=SaveID+1;
spikeremoveflag=0;
Xratio=handles.Setup.DataAnalysis.Xratio;
Zratio=handles.Setup.DataAnalysis.Zratio;
UX=ToSave.Data.UX*Xratio;
UZ=ToSave.Data.UZ*Zratio;
    for j=1:size(ToSave.Data.XZ,2)
        if find(cellfun(@isempty,ToSave.Data.XZ(:,j)))
            break;
        else
            for i=1:size(ToSave.Data.XZ,1)
                [ SXZ(i,j), odata, spikeremoveflag] = function_score_removeSpike( handles.Setup,ToSave.Stim,cell2mat(ToSave.Data.XZ(i,j)),spikeremoveflag);            
            end
        end
    end
SXZ2D=reshape(mean(SXZ,2),[length(UX) length(UZ)]);
[~,Ind]=max(mean(SXZ,2));
if numel(Ind)>1
    [~,ind]=min(abs(Ind-length(SXZ)/2));
    Ind=Ind(ind);
end
[I,J]=ind2sub([length(UX) length(UZ)],Ind);
x=(I-J+1):size(SXZ2D,1);
x(x<1)=[];%delete non-positive index
y=1:length(x);
for k=1:length(x)
    diagSXZ(k)=SXZ2D(x(k),y(k));
end
d=sqrt((UX(1)-UX(2))^2+(UZ(1)-UZ(2))^2);
UXZ=-(J-1)*d:d:(length(x)-J)*d;    
[GaussianXZ, ~] = createFit(UXZ, diagSXZ);
FWHMxz=function_FWHMofGaussian( GaussianXZ, UXZ );
DataSave.FWHMxzDiagonal=FWHMxz;
DataSave.GaussianXZ_XZdiagonal=GaussianXZ;
ToSave.DataAnalysis = DataSave;
xzdiag=figure;
figure(xzdiag);
set(xzdiag, 'Position',  [300, 300,1000, 400])
subplot(1,2,1);
imagesc(UX,UZ,SXZ2D');
title('XZ PPSF');
axis image;xlabel('X (\mum)');ylabel('Z (\mum)');
colorbar;
subplot(1,2,2);plot(GaussianXZ, UXZ, diagSXZ);title('diag XZ PPSF');
grid on;xlim([min(UZ) max(UZ)]);xlabel('XZ (\mum)');
dim = [0.58 0.6 0.3 0.3];
str = {['FWHMxz=' num2str(FWHMxz) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
dim = [0.4 0.7 0.3 0.3];
str = {['Repeat ' num2str(size(SXZ,2)) ', spikeremove=' num2str(spikeremoveflag)]};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
if get(handles.checkbox1,'Value') == 1
   filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
   save(filename,'ToSave');
   saveas(xzdiag,[filename '_XZdiagonalPPSF_plot.tif']);
   disp('Data & Plot Saved');
end
end

% --- Executes on button press in SpikeCountingPPSF.
function SpikeCountingPPSF_Callback(hObject, eventdata, handles)
% hObject    handle to SpikeCountingPPSF (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global SaveID; SaveID=SaveID+1;
Xratio=handles.Setup.DataAnalysis.Xratio;
Zratio=handles.Setup.DataAnalysis.Zratio;
UX=ToSave.Data.UX*Xratio;
UZ=ToSave.Data.UZ*Zratio;
for j=1:size(ToSave.Data.X,2)
        if isempty(cell2mat(ToSave.Data.X(:,j)))
            break;
        else
            for i=1:size(ToSave.Data.X,1)
                [ SX(i,j), ~] = function_scorespikes( handles.Setup,ToSave.Stim,cell2mat(ToSave.Data.X(i,j)));
                [ SZ(i,j), ~] = function_scorespikes( handles.Setup,ToSave.Stim,cell2mat(ToSave.Data.Z(i,j)));
            end
        end
end
[GaussianX, ~] = createFit(UX', mean(SX,2));
[GaussianZ, ~] = createFit(UZ', mean(SZ,2));
FWHMx=function_FWHMofGaussian( GaussianX, UX );
FWHMz=function_FWHMofGaussian( GaussianZ, UZ );
DataSave.FWHMx_Spike=FWHMx;
DataSave.FWHMz_Spike=FWHMz;
DataSave.GaussianX_Spike=GaussianX;
DataSave.GaussianZ_Spike=GaussianZ;
ToSave.DataAnalysis = DataSave;
spikeCount=figure;
figure(spikeCount);
set(spikeCount, 'Position',  [300, 300, 1000, 400])
subplot(1,2,1);
plot(GaussianX, UX, mean(SX,2));
title('X spike PPSF');
grid on;xlim([min(UX) max(UX)]);xlabel('X (\mum)');ylabel('Num of Spike');
dim = [0.14 0.6 0.3 0.3];
str = {['FWHMx=' num2str(FWHMx) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
subplot(1,2,2);
plot(GaussianZ, UZ, mean(SZ,2));
title('Z spike PPSF');
grid on;xlim([min(UZ) max(UZ)]);xlabel('Z (\mum)');ylabel('Num of Spike');
dim = [0.58 0.6 0.3 0.3];
str = {['FWHMz=' num2str(FWHMz) '\mum']};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
figure(spikeCount);
dim = [0.47 0.68 0.3 0.3];
str = {['Repeat ' num2str(size(ToSave.Data.X,2))]};
annotation('textbox',dim,'String',str,'FitBoxToText','on');
if get(handles.checkbox1,'Value') == 1
   filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
   save(filename,'ToSave');
   saveas(spikeCount,[filename '_SpikeCountPPSF_plot.tif']);
   disp('Data & Plot Saved');
end
end


% --- red stimuation laser.
function checkbox8_Callback(hObject, eventdata, handles)
% Hint: get(hObject,'Value') returns toggle state of checkbox8
global Cloud;
handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
Cloud.AnlgeMagnitudeOffset = handles.Setup.PointCloud.GalvoOffsetVoltage;
end

% % --- 3D PPSF XYZ with preload mask of 15um aperture
% function pushbutton32_Callback(hObject, eventdata, handles)
% global DAQstate; global status;status = 1;
% DAQstate = [0 0 0 0 0 0];
% global ToSave;
% global Cloud;
% global SaveID; SaveID=SaveID+1;
% ToSave.DMDSTATE = 'DMD Digital PPSF Sequence';
% outputSingleScan(handles.Setup.Daq,DAQstate);
% set(handles.slider3,'Value',0);
% set(handles.slider2,'Value',0);
% set(handles.edit3,'string',0);
% set(handles.edit4,'string',0);
% 
% UX = linspace(-100,100,11);%range should be changed
% UY = linspace(-100,100,11);
% UZ = linspace(-100,100,21);
% 
% DataSave.UX = UX;
% DataSave.UY = UY;
% DataSave.UZ = UZ;
% Nx=11;
% Ny=11;
% Nz=21;
% 
% Stim.Npeaks = 1; %force speak to be 1
% Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
% Stim.FreqHZ= 1000/(Stim.DurationMS*Nz);
% Stim.Voltage = str2num(get(handles.edit11,'string'));
% Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
% Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
% Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
% Stim.TargetRadius = 15;
% Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
% [Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
%  if get(handles.checkbox8,'Value')==1
%         handles.Setup.PointCloud.GalvoOffsetVoltage=[0,-1];
%         Cloud.AnlgeMagnitudeOffset = handles.Setup.PointCloud.GalvoOffsetVoltage;   
%  else
%         handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
%         Cloud.AnlgeMagnitudeOffset = handles.Setup.PointCloud.GalvoOffsetVoltage;   
%  end
% [ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
% Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
% if get(handles.checkbox2,'Value') == 0
%     Stim.Output(:,5)=0;
% %     select = Stim.UT<2*handles.Setup.Scorepikes.sealtestduration.* Stim.UT>handles.Setup.Scorepikes.sealtestduration;
% %     Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
%     select = Stim.UT<handles.Setup.Scorepikes.sealtestduration;    
%     tempOutput=Stim.Output;
%     tempOutput(1:end,:)=0;
%     tempOutput(select,5)=1;
%     queueOutputData(handles.Setup.Daq,tempOutput);
%     startForeground(handles.Setup.Daq);
%     pause(0.1);
% else
%     Stim.Output(:,5) =0;
% end
% Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
% Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
% [Stim.LN,Stim.LX] = size(Stim.Output);
% Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
% Stim.Array = Stim.UUT-Stim.UUT;
% for i = 1:Stim.Npeaks
%     Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+i/Stim.FreqHZ);
% end
% Stim.Baseline = Stim.Output(:,1);
% if get(handles.checkbox8,'Value') == 1
%     Stim.Output(:,1)=0;
%     Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
%     temp=Stim.Output(:,2);
%     temp(temp~=0)=1;
%     Stim.Output(:,6)=temp;
% else   
%     Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
%     Stim.Output(:,2)=0;
%     temp=Stim.Output(:,1);
%     temp(temp~=0)=1;
%     Stim.Output(:,6)=temp;
% end
% Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
% Cloud.divider = floor(str2num(get(handles.edit42,'string')));
% Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
% [PXX,PYY,PZZ] = ndgrid(UX,UY,UZ);
% DataSave.PXX = PXX(:);
% DataSave.PYY = PYY(:);
% DataSave.PZZ = PZZ(:);
% 
% axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
% if ~isempty(handles.Setup.DMD.sequenceid)
%     handles.Setup=function_StopDMDSequence(handles.Setup);
% end
% for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed
%     if j==1
%         for i=1:Nx*Ny
%             tic
%             if status == 0; disp('Procedure interrupted'); break; end;
%             load(['Masks11x11x21_15pixelAP\sequence' num2str(i) '.mat']);
%             handles.Setup= function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames_final))*255);
%             toc;
%         end
%     end
%     
%     handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
%     for i=1:Nx*Ny
%         if status == 0; disp('Procedure interrupted'); break; end;
%         Currentsequenceid=handles.Setup.DMD.sequenceid(i);
%         handles.Setup = function_StartProj_DMD(handles.Setup, Currentsequenceid,0);
%         queueOutputData(handles.Setup.Daq,Stim.Output);
%         Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pinout
%         if get(handles.checkbox1,'Value') == 1
%             filename = cell2mat([handles.Setup.SavingPath, handles.Setup.DataFolder, 'XYZ15AP_Seq', num2str(i), '_Rep', num2str(j), '_task', get(handles.edit46,'string'), '.mat']);
%             save(filename,'Data');
%             disp(['Data point ' num2str(i) ', ' num2str(j) ' Saved']);
%         end
%         handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
%     end
%     disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
% end
% try
% ToSave.type = 'Digital PPSF Full XZ plane';
% ToSave.Stim = Stim;
% ToSave.status = status;
% ToSave.Data = DataSave;
% catch; 
% end;
% if get(handles.checkbox1,'Value') == 1
%     filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
%     save(filename,'ToSave');
%     disp('Data Saved')
% end
% disp('Plot Result...');
% load('MaskCoordinates/Ind.mat');
% seqL=21;%each sequence contains masks for seqL points
% Score4D=zeros(Nx,Ny,Nz,str2num(get(handles.edit9,'string')));
% for j=1:str2num(get(handles.edit9,'string'))
%     if status == 0; disp('Procedure interrupted'); break; end;
%     for i=1:Nx*Ny
%         if status == 0; disp('Procedure interrupted'); break; end;
%         SavedData=load(cell2mat([handles.Setup.SavingPath, handles.Setup.DataFolder, 'XYZ15AP_Seq', num2str(i), '_Rep',num2str(j), '_task',  get(handles.edit46,'string'), '.mat']));%file name: Data
%         Data_temp=SavedData.Data.*Stim.Array';
%         Stim.baseline=mean(SavedData.Data(1:50));
%         Data_temp(Data_temp==0)=[];
%         DataMatrix=reshape(Data_temp,seqL,numel(Data_temp)/seqL);
%         for k=1:seqL
%         if status == 0; disp('Procedure interrupted'); break; end;
%         [ Score4D(Ind(k+(i-1)*seqL,1),Ind(k+(i-1)*seqL,2),Ind(k+(i-1)*seqL,3),j), ~] = function_scorespikes( handles.Setup,Stim,DataMatrix(k,:));
%         end
%     end
%     axes(handles.axes2); imagesc(UY, UX, mean(squeeze(Score4D(:,:,(Nz+1)/2,1:j)),3)); xlabel('X pixels'); ylabel('Y pixels'); title(['XY PPSF mean 1:' num2str(j)]);
%     axes(handles.axes5); imagesc(UZ, UX, mean(squeeze(Score4D(:,(Ny+1)/2,:,1:j)),3)); xlabel('X pixels'); ylabel('Z pixels'); title(['XZ PPSF mean 1:' num2str(j)]);
% end
% if get(handles.checkbox1,'Value') == 1
%     filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_Score4D_', int2str(SaveID), '_.mat'];
%     disp('Score4D Saved')
% end
% 
% end


% --- 3D digital PPSF load patterns
function pushbutton35_Callback(hObject, eventdata, handles)
global DAQstate;
global status;
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
status = 1;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

% ProjMode = function_CheckProjMode_DMD(handles.Setup);
% if ProjMode==2301
%     [handles.Setup]=function_StopProj_DMD(handles.Setup);
%     [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
% end

Preload.X=load(['MaskCoordinates\UX.mat']);
Preload.Y=load(['MaskCoordinates\UY.mat']);
Preload.Z=load(['MaskCoordinates\UZ.mat']);
seqL=21;
if rem(numel(Preload.X.UX),seqL)~=0
    seqL=1;
end
NumofSeq=numel(Preload.X.UX)/seqL;

Cloud.Preload.sequenceid=zeros(NumofSeq,1);
for k=1:NumofSeq
    if status == 0
        disp('Procedure interrupted'); break; 
    elseif status ==2
        f = figure;set(f,'Position',[800, 800, 400,200]);
        h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                      'Callback','uiresume(gcbf)');
        uiwait(gcf); 
        status = 1;
        close(f);
    end
    DMDFrames_final = gpuArray(false(handles.Setup.DMD.LX,handles.Setup.DMD.LY,...
    handles.Setup.PointCloud.divider*seqL));
        for i=1:seqL
            if status == 0
                disp('Procedure interrupted'); break; 
            elseif status ==2
                f = figure;set(f,'Position',[800, 800, 400,200]);
                h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                              'Callback','uiresume(gcbf)');
                uiwait(gcf); 
                status = 1;
                close(f);
            end
                DMDFrames = function_makespots(handles.Setup,Preload.X.UX(i+(k-1)*seqL),Preload.Y.UY(i+(k-1)*seqL),Preload.Z.UZ(i+(k-1)*seqL),str2num(get(handles.edit19,'string')));   
                DMDFrames_final(:,:,((i-1)*handles.Setup.PointCloud.divider+1):(i*handles.Setup.PointCloud.divider))=DMDFrames;
        end
            [handles.Setup,Cloud.Preload.sequenceid(k)]= function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames_final))*255);
end
    disp('Random patterns are loaded!');
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
end


% --- Executes when user attempts to close figure1.
function figure1_CloseRequestFcn(hObject, eventdata, handles)
fclose(handles.Setup.SutterStage);
function_StopDMDSequence(handles.Setup);
function_Stop_DMD(handles.Setup);
delete(hObject);
end


% --- Executes random 3D PPSF.
function pushbutton36_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'DMD Digital PPSF Random';
outputSingleScan(handles.Setup.Daq,DAQstate);
% set(handles.slider3,'Value',0);
% set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end

Preload.X=load(['MaskCoordinates\UX.mat']);
Preload.Y=load(['MaskCoordinates\UY.mat']);
Preload.Z=load(['MaskCoordinates\UZ.mat']);

UX = unique(Preload.X.UX);
UY = unique(Preload.Y.UY);
UZ = unique(Preload.Z.UZ);
% UX = linspace(-50,50,11);
% UY = linspace(-50,50,11);
% UZ = linspace(-100,100,21);

DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;
Nx=numel(UX);Ny=numel(UY);Nz=numel(UZ);

seqL=21;
% if rem(numel(Preload.X.UX),seqL)~=0
%     seqL=1;
% end
NumofSeq=numel(Preload.X.UX)/seqL;

Stim.Npeaks = seqL;% instead of repeat one holograph, change holograph equals to the sequence length
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
Stim.CropMask=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.CropMask = Stim.CropMask+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+i/Stim.FreqHZ);
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,5)=0;
select = Stim.UUT<handles.Setup.Scorepikes.sealtestduration;
Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
[PXX,PYY,PZZ] = ndgrid(UX,UY,UZ);
DataSave.PXX = PXX(:);
DataSave.PYY = PYY(:);
DataSave.PZZ = PZZ(:);

DataSave.XYZ = {}; 
load('MaskCoordinates/Ind.mat');
Score4D=zeros(Nx,Ny,Nz,str2num(get(handles.edit9,'string')));
handles.Setup.DMD.SequenceControl.RepeatModeValue=1;

axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed   
    handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        Currentsequenceid=Cloud.Preload.sequenceid(i);
        handles.Setup = function_StartProj_DMD(handles.Setup, Currentsequenceid);
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        DataSave.XYZ{i,j}=Data;
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
        axes(handles.axes5);plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage');title([num2str(seqL) ' spot measurements']);
        disp(['Finish #' num2str(i) '/' num2str(NumofSeq) ' of repeat #' num2str(j)]);
    end
    disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
end
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        Data_temp=DataSave.XYZ{i,j}.*Stim.CropMask';
        Stim.baseline=mean(DataSave.XYZ{i,j}(1:50));
        Data_temp(Data_temp==0)=[];
        if rem(numel(Data_temp),seqL)~=0
           Data_temp=cat(1,Data_temp,0);
        end
        DataMatrix=reshape(Data_temp,numel(Data_temp)/seqL,seqL);
        DataMatrix=DataMatrix';
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
        for k=1:seqL
        [ Score4D(Ind(k+(i-1)*seqL,1),Ind(k+(i-1)*seqL,2),Ind(k+(i-1)*seqL,3),j), ~] = function_scorespikes( handles.Setup,Stim,DataMatrix(k,:));
        end
    end
    axes(handles.axes2); imagesc(UY, UX, mean(squeeze(Score4D(:,:,(Nz+1)/2,1:j)),3)); xlabel('X pixels'); ylabel('Y pixels'); title(['XY PPSF mean 1:' num2str(j)]);
    axes(handles.axes3); imagesc(UZ, UX, mean(squeeze(Score4D(:,(Ny+1)/2,:,1:j)),3)); xlabel('Z pixels'); ylabel('X pixels'); title(['XZ PPSF mean 1:' num2str(j)]);

try
ToSave.type = 'Digital PPSF Full XYZ Volume random';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
ToSave.Score = Score4D;
figure(100);set(gcf, 'Position',  [100, 100, 500, 400]);imshow3D( mean(Score4D,4) );
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
catch; 
end;

% ToSave.Score = Score4D;
% figure(200);imshow3D(mean(Score4D,4));
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);

if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end

end


% --- Digital 3D PPSF XYZ sequential.
function pushbutton37_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'DMD Digital 3D PPSF Sequence';
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

if get(handles.checkbox3,'Value') == 1
UX = function_logvec( -str2num(get(handles.edit20,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = function_logvec( -str2num(get(handles.edit21,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = function_logvec( -str2num(get(handles.edit22,'string')),floor(str2num(get(handles.edit25,'string'))));
else
UX = linspace(str2num(get(handles.edit20,'string')),str2num(get(handles.edit47,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = linspace(str2num(get(handles.edit21,'string')),str2num(get(handles.edit48,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = linspace(str2num(get(handles.edit22,'string')),str2num(get(handles.edit49,'string')),floor(str2num(get(handles.edit25,'string'))));
end
DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;
Nx=floor(str2num(get(handles.edit23,'string')));
Ny=floor(str2num(get(handles.edit24,'string')));
Nz=floor(str2num(get(handles.edit25,'string')));

Stim.Npeaks = Nz; %force speak to be 1
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end

[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
Stim.CropMask=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.CropMask = Stim.CropMask+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+i/Stim.FreqHZ-Stim.DurationMS/10000);
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,5)=0;
select = Stim.UUT<handles.Setup.Scorepikes.sealtestduration;
Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
[PXX,PYY,PZZ] = ndgrid(UX,UY,UZ);
DataSave.PXX = PXX(:);
DataSave.PYY = PYY(:);
DataSave.PZZ = PZZ(:);
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end

DataSave.XYZ = {};
[xind,yind,zind]=ind2sub([Nx,Ny,Nz],(1:Nx*Ny*Nz)');
Ind=[xind,yind,zind];
Score4D=zeros(Nx,Ny,Nz,str2num(get(handles.edit9,'string')));

axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed
    if j==1
        Cloud.sequenceid3D=zeros(Nx*Ny*Nz,1);
            for xx=1:Nx
                if status == 0
                    disp('Procedure interrupted'); break; 
                elseif status ==2
                    f = figure;set(f,'Position',[800, 800, 400,200]);
                    h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                                  'Callback','uiresume(gcbf)');
                    uiwait(gcf); 
                    status = 1;
                    close(f);
                end
                for yy=1:Ny
                    if status == 0
                        disp('Procedure interrupted'); break; 
                    elseif status ==2
                        f = figure;set(f,'Position',[800, 800, 400,200]);
                        h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                                      'Callback','uiresume(gcbf)');
                        uiwait(gcf); 
                        status = 1;
                        close(f);
                    end
                        DMDFrames_final = gpuArray(false(handles.Setup.DMD.LX,handles.Setup.DMD.LY,...
                        handles.Setup.PointCloud.divider*Nz));
                    for i=1:Nz
                        if status == 0
                            disp('Procedure interrupted'); break; 
                        elseif status ==2
                            f = figure;set(f,'Position',[800, 800, 400,200]);
                            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                                          'Callback','uiresume(gcbf)');
                            uiwait(gcf); 
                            status = 1;
                            close(f);
                        end
                        DMDFrames = function_makespots(handles.Setup,str2num(get(handles.edit16,'string'))+UX(xx),str2num(get(handles.edit17,'string'))+UY(yy),str2num(get(handles.edit18,'string'))+UZ(i),str2num(get(handles.edit19,'string')));   
                        DMDFrames_final(:,:,((i-1)*handles.Setup.PointCloud.divider+1):(i*handles.Setup.PointCloud.divider))=DMDFrames;
                    end
                    [handles.Setup,handles.sequenceid3D((xx-1)*Nx+yy)] = function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames_final))*255);
                end
            end
    end
    for i=1:Nx*Ny
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        handles.Setup = function_StartProj_DMD(handles.Setup, handles.sequenceid3D(i));
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
%         Data1=Data.*Stim.Array';
%         Data1(Data1==0)=[];
%         DataMatrix=reshape(Data1,Nz,numel(Data1)/Nz);
%         axes(handles.axes5);imagesc(DataMatrix);xlabel('Time [pixel]'); ylabel('Z pixels');
        DataSave.XYZ{i,j}=Data;
        axes(handles.axes5);plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage');title([num2str(i) ' coordinate']);
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
    end
    
    for i=1:Nx*Ny
        Data_temp=DataSave.XYZ{i,j}.*Stim.CropMask';
        Stim.baseline=mean(DataSave.XYZ{i,j}(1:100));
        Data_temp(Data_temp==0)=[];
        if rem(numel(Data_temp),Nz)~=0
           Data_temp=cat(1,Data_temp,0);
        end
        DataMatrix=reshape(Data_temp,numel(Data_temp)/Nz,Nz);
        DataMatrix=DataMatrix';
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
        for k=1:Nz
            [ Score4D(Ind(k+(i-1)*Nz,1),Ind(k+(i-1)*Nz,2),Ind(k+(i-1)*Nz,3),j), ~] = function_scorespikes( handles.Setup,Stim,DataMatrix(k,:));
        end
    end
    axes(handles.axes2); imagesc(UY, UX, mean(squeeze(Score4D(:,:,(Nz+1)/2,1:j)),3)); xlabel('X pixels'); ylabel('Y pixels'); title(['XY PPSF mean 1:' num2str(j)]);
    axes(handles.axes3); imagesc(UZ, UX, mean(squeeze(Score4D(:,(Ny+1)/2,:,1:j)),3)); xlabel('Z pixels'); ylabel('X pixels'); title(['XZ PPSF mean 1:' num2str(j)]);
    disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
end
try
ToSave.type = 'Digital PPSF Full XYZ Volume sequential';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
ToSave.Score = Score4D;
figure(300);set(gcf, 'Position',  [100, 100, 500, 400]);imshow3D( mean(Score4D,4) );
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
catch; 
end;
if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end
end



function edit47_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function edit47_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end



function edit48_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function edit48_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

function edit49_Callback(hObject, eventdata, handles)
end

function edit49_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Full XY 2D mapping.
function pushbutton42_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'DMD Digital 2D XY PPSF Sequence';
ToSave.Score=[];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

if get(handles.checkbox3,'Value') == 1
UX = function_logvec( -str2num(get(handles.edit20,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = function_logvec( -str2num(get(handles.edit21,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = function_logvec( -str2num(get(handles.edit22,'string')),floor(str2num(get(handles.edit25,'string'))));
else
UX = linspace(str2num(get(handles.edit20,'string')),str2num(get(handles.edit47,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = linspace(str2num(get(handles.edit21,'string')),str2num(get(handles.edit48,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = linspace(str2num(get(handles.edit22,'string')),str2num(get(handles.edit49,'string')),floor(str2num(get(handles.edit25,'string'))));
end
DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;
Nx=floor(str2num(get(handles.edit23,'string')));
Ny=floor(str2num(get(handles.edit24,'string')));
Nz=floor(str2num(get(handles.edit25,'string')));
[PXX,PYY,PZZ] = ndgrid(UX,UY,UZ);
DataSave.PXX = PXX(:);
DataSave.PYY = PYY(:);
DataSave.PZZ = PZZ(:);
DataSave.XY={};
% [xind,yind]=ind2sub([Nx,Ny],(1:Nx*Ny)');%sequential
% [xind,yind]=ind2sub([Nx,Ny],(randperm(Nx*Ny))');%random order
% Ind=[xind,yind];
if Nx>20
Ind = function_RandomIndexPoisson(Nx,Ny);
xind=Ind(:,1);yind=Ind(:,2);
else
    [xind,yind]=ind2sub([Nx,Ny],(randperm(Nx*Ny))');%random order
    Ind=[xind,yind];
end

Score3D=zeros(Nx,Ny,Nz);

if Nx*Ny>450 % limit of matlab ram
    temp1=1:ceil(Nx*Ny/2);
    temp2=temp1(rem(Nx*Ny,temp1)==0);
    temp3=400-temp2;
    temp3(temp3<0)=[];
    seqL=400-min(temp3);
    NumofSeq=Nx*Ny/seqL;
    Stim.Npeaks=seqL;
else
    NumofSeq=1;
    seqL=Nx*Ny;
    Stim.Npeaks = Nx*Ny;
end
        
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end

[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
Stim.CropMask=Stim.Array;
% PowerMatrix=sqrt(PXX.^2+PYY.^2)/sqrt(max(UX)^2+max(UY)^2)*(str2num(get(handles.edit50,'string'))-Stim.Voltage)+Stim.Voltage;
Stim.PowerMask=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.CropMask = Stim.CropMask+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+i/Stim.FreqHZ-Stim.DurationMS/10000);
%     Stim.PowerMask=Stim.PowerMask+PowerMatrix(i)*double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
end
Stim.Baseline = Stim.Output(:,1);
% if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
%     Stim.Output(:,1)=0;
%     Stim.Output(:,2) = Stim.PowerMask'.*Stim.Array';
%     Stim.nonzerovalues = find(Stim.Output(:,2));
% else   
%     Stim.Output(:,1) = Stim.PowerMask'.*Stim.Array';
%     Stim.Output(:,2)=0;
%     Stim.nonzerovalues = find(Stim.Output(:,1));
% end
Stim.Output(:,5)=0;
select = Stim.UUT<handles.Setup.Scorepikes.sealtestduration;
Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
Stim.Output(:,6)=Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
Cloud.XYZmap=zeros(Nx,Ny,Nz,str2num(get(handles.edit9,'string')));

ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end

Stim.CurrentXYZ = getPosition(handles.Setup.SutterStage);
disp(['Current stage Z position:' num2str(Stim.CurrentXYZ(3))]);
axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes5); hold off; cla;
axes(handles.axes4); hold off; cla;
for v=1:numel(Stim.Voltageramp)
    if status == 0; disp('Procedure interrupted'); break; end;
    if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
       Stim.Output(:,1)=0;
       Stim.Output(:,2) = Stim.Voltageramp(v).*Stim.Array';
       Stim.nonzerovalues = find(Stim.Output(:,2));
    else   
       Stim.Output(:,1) = Stim.Voltageramp(v).*Stim.Array';
       Stim.Output(:,2)=0;
       Stim.nonzerovalues = find(Stim.Output(:,1));
    end
for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed
    if status == 0; disp('Procedure interrupted'); break; end;
    for nz = 1:Nz
        if status == 0; disp('Procedure interrupted'); break; end;
        moveTime = moveTo(handles.Setup.SutterStage,[Stim.CurrentXYZ(1);Stim.CurrentXYZ(2);Stim.CurrentXYZ(3)+UZ(nz)]);
        pause(0.1);
    if j==1 && nz==1 && v==1
        for k=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        DMDFrames_final = gpuArray(false(handles.Setup.DMD.LX,handles.Setup.DMD.LY,seqL));
            for i=1:seqL
                if status == 0
                    disp('Procedure interrupted'); break; 
                elseif status ==2
                    f = figure;set(f,'Position',[800, 800, 400,200]);
                    h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                                  'Callback','uiresume(gcbf)');
                    uiwait(gcf); 
                    status = 1;
                    close(f);
                end
                   DMDFrames = function_makespots(handles.Setup,str2num(get(handles.edit16,'string'))+UX(xind(i+(k-1)*seqL)),str2num(get(handles.edit17,'string'))+UY(yind(i+(k-1)*seqL)),0,str2num(get(handles.edit19,'string')));   
                   DMDFrames_final(:,:,i)=DMDFrames(:,:,1);
            end
            [handles.Setup,handles.sequenceid2DXY(k)] = function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames_final))*255);
            disp(['--loading mask: ' num2str(k) '/' num2str(NumofSeq) ' finished']);
        end
    end
    
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        handles.Setup = function_StartProj_DMD(handles.Setup, handles.sequenceid2DXY(i));
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        DataSave.XY{i,j,nz,v}=Data;
        axes(handles.axes5);plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage');title([num2str(seqL) ' coordinate']);
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
        disp(['sequence #' num2str(i) '/' num2str(NumofSeq) ' finished!']);pause(1);
    end
    
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue','Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        Data_temp=DataSave.XY{i,j,nz,v};
        Data_temp=medfilt1(Data_temp,10);
        Data_temp=Data_temp.*Stim.CropMask';
        Data_temp(Data_temp==0)=[];
        DataMatrix=reshape(Data_temp,numel(Data_temp)/seqL,seqL);
        DataMatrix=DataMatrix';
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
        for k=1:seqL
            [ Score3D(Ind(k+(i-1)*seqL,1),Ind(k+(i-1)*seqL,2),nz), ~] = function_scorespikes( handles.Setup,Stim,DataMatrix(k,:));
        end
    end
    figure(100);set(gcf, 'Position',  [100, 100, 100*Nz, numel(Stim.Voltageramp)*100]);
    subplot(numel(Stim.Voltageramp),Nz,(nz+Nz*(v-1)));
    imagesc(UX, UY, log(Score3D(:,:,nz)'));colorbar;axis image;
    xlabel('X pixels'); ylabel('Y pixels'); title(['Z' num2str(UZ(nz),2) '\mum, #' num2str(j), ' V=' num2str(Stim.Voltageramp(v),2)]);
    Score2D=max(Score3D,[],3);
    axes(handles.axes2); imagesc(UX, UY, log(Score2D')); xlabel('X pixels'); ylabel('Y pixels'); title(['Maximum Z Projection:' num2str(j)]);colorbar;
end
ToSave.Score{j,v}=Score3D;
Cloud.XYZmap(:,:,:,j,v)=Score3D;
disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
end
S=max(mean(Cloud.XYZmap(:,:,:,:,v),4),[],3);
axes(handles.axes3); imagesc(UX, UY, log(S')); xlabel('X pixels'); ylabel('Y pixels'); title(['Average MZP at power' num2str(Stim.Voltageramp(v))]);colorbar;
disp(['---Voltage #' num2str(v) '/' num2str(numel(Stim.Voltageramp)) ' finished!']);
end
moveTime = moveTo(handles.Setup.SutterStage,[Stim.CurrentXYZ(1);Stim.CurrentXYZ(2);Stim.CurrentXYZ(3)]);
try
ToSave.Ind=Ind;
ToSave.type = 'Digital PPSF Full XY 2D sequential';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
catch; 
end;
if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end
end



function edit50_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function edit50_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end

% --- high resolution scan sub-regions after full xy 2D scanning
function pushbutton43_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'Fine ROI mapping';
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

if get(handles.checkbox3,'Value') == 1
UX = function_logvec( -str2num(get(handles.edit20,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = function_logvec( -str2num(get(handles.edit21,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = function_logvec( -str2num(get(handles.edit22,'string')),floor(str2num(get(handles.edit25,'string'))));
else
UX = linspace(str2num(get(handles.edit20,'string')),str2num(get(handles.edit47,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = linspace(str2num(get(handles.edit21,'string')),str2num(get(handles.edit48,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = linspace(str2num(get(handles.edit22,'string')),str2num(get(handles.edit49,'string')),floor(str2num(get(handles.edit25,'string'))));
end
Nx=floor(str2num(get(handles.edit23,'string')));
Ny=floor(str2num(get(handles.edit24,'string')));
Nz=floor(str2num(get(handles.edit25,'string')));
UZ=round(UZ/handles.Setup.DataAnalysis.Zratio);
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;

MAP=max(mean(Cloud.XYZmap,4),[],3);
[counts, bin]=hist(MAP(:),round(numel(MAP)*0.02));
Threshold=min(bin(counts<round(numel(MAP)*0.05)));%sparse signal: signal pixels should be less than 5% of total pixels.
[xind,yind]=ind2sub([Nx,Ny],find(MAP>Threshold));%use func "find", the result is sorted
CenterX=UX(xind);CenterY=UY(yind);
Cloud.CenterX=CenterX;Cloud.CenterY=CenterY;
CenterX=cat(2,CenterX,[min(CenterX)-2*Stim.TargetRadius,max(CenterX)+2*Stim.TargetRadius]);
CenterY=cat(2,CenterY,[min(CenterY)-2*Stim.TargetRadius,max(CenterY)+2*Stim.TargetRadius]);


    Num=round(sqrt(numel(CenterX))*(str2num(get(handles.edit55,'string')))^2);
    [Xq,Yq]=meshgrid(linspace(min(CenterX),max(CenterX),Num),linspace(min(CenterY),max(CenterY),Num));
    Zq=griddata(CenterX,CenterY,ones(size(CenterX)),Xq,Yq);
    Stim.Data.IND=find(~isnan(Zq));
    Stim.N=numel(Stim.Data.IND);
    if rem(Stim.N,2)==1
        Stim.Data.IND(1)=[];
        Stim.N=numel(Stim.Data.IND);
    end
    Stim.Data.IND=Stim.Data.IND(randperm(Stim.N));
    Stim.Data.CX=Xq(Stim.Data.IND);
    Stim.Data.CY=Yq(Stim.Data.IND);
    [Xq1,Yq1]=meshgrid(1:Num,1:Num);
    Ind=[Xq1(Stim.Data.IND),Yq1(Stim.Data.IND)];
    axes(handles.axes4);scatter(Stim.Data.CX,Stim.Data.CY,'r.');
    hold on;scatter(CenterX,CenterY,'bo');axis tight;
    title(['ROI, # of pixel = ' num2str(Stim.N)]);

if Stim.N>450 % limit of matlab ram
    temp1=1:ceil(Stim.N/2);
    temp2=temp1(rem(Stim.N,temp1)==0);
    temp3=400-temp2;
    temp3(temp3<0)=[];
    seqL=400-min(temp3);
    NumofSeq=Stim.N/seqL;
    Stim.Npeaks=seqL;
else
    NumofSeq=1;
    seqL=Stim.N;
    Stim.Npeaks = Stim.N;
end
        
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end

[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
Stim.CropMask=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.CropMask = Stim.CropMask+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+i/Stim.FreqHZ-Stim.DurationMS/10000);
end
Stim.Baseline = Stim.Output(:,1);
Stim.Output(:,5)=0;
select = Stim.UUT<handles.Setup.Scorepikes.sealtestduration;
Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
Stim.Output(:,6)=Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
Cloud.XYZmapVoltage=zeros(Num,Num,Nz,str2num(get(handles.edit9,'string')),numel(Stim.Voltageramp));
Score3D=zeros(Num,Num,Nz);

ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end

Stim.CurrentXYZ = getPosition(handles.Setup.SutterStage);
disp(['Current stage Z position:' num2str(Stim.CurrentXYZ(3))]);
axes(handles.axes2); hold off; cla;axes(handles.axes5); hold off; cla;

for v=1:numel(Stim.Voltageramp)
    if status == 0
        disp('Procedure interrupted'); break; 
    elseif status ==2
        f = figure;set(f,'Position',[800, 800, 400,200]);
        h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                                  'Callback','uiresume(gcbf)');
        uiwait(gcf); 
        status = 1;
        close(f);
    end
    if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
       Stim.Output(:,1)=0;
       Stim.Output(:,2) = Stim.Voltageramp(v).*Stim.Array';
       Stim.nonzerovalues = find(Stim.Output(:,2));
    else   
       Stim.Output(:,1) = Stim.Voltageramp(v).*Stim.Array';
       Stim.Output(:,2)=0;
       Stim.nonzerovalues = find(Stim.Output(:,1));
    end
for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed
    if status == 0
        disp('Procedure interrupted'); break; 
    elseif status ==2
        f = figure;set(f,'Position',[800, 800, 400,200]);
        h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                      'Callback','uiresume(gcbf)');
        uiwait(gcf); 
        status = 1;
        close(f);
    end
    for nz = 1:Nz
        if status == 0; disp('Procedure interrupted'); break; end;
        moveTime = moveTo(handles.Setup.SutterStage,[Stim.CurrentXYZ(1);Stim.CurrentXYZ(2);Stim.CurrentXYZ(3)+UZ(nz)]);
        pause(0.1);
    if j==1 && nz==1 && v==1
        for k=1:NumofSeq
        DMDFrames_final = gpuArray(false(handles.Setup.DMD.LX,handles.Setup.DMD.LY,seqL));
            for i=1:seqL
                if status == 0; disp('Procedure interrupted'); break; end;
                   DMDFrames = function_makespots(handles.Setup,str2num(get(handles.edit16,'string'))+Stim.Data.CX(i+(k-1)*seqL),str2num(get(handles.edit17,'string'))+Stim.Data.CY(i+(k-1)*seqL),0,str2num(get(handles.edit19,'string')));   
                   DMDFrames_final(:,:,i)=DMDFrames(:,:,1);
            end
            [handles.Setup,handles.sequenceid2DXY(k)] = function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames_final))*255);
            disp(['--loading mask: ' num2str(k) '/' num2str(NumofSeq) ' finished']);
        end
    end
    
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        handles.Setup = function_StartProj_DMD(handles.Setup, handles.sequenceid2DXY(i));
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        DataSave.XY{i,j,nz,v}=Data;
        axes(handles.axes5);plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage');title([num2str(seqL) ' coordinate']);
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
        disp(['sequence #' num2str(i) '/' num2str(NumofSeq) ' finished!']);pause(1);
    end
    
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        Data_temp=DataSave.XY{i,j,nz,v};
        Data_temp=medfilt1(Data_temp,10);
        Data_temp=Data_temp.*Stim.CropMask';
        Data_temp(Data_temp==0)=[];
        DataMatrix=reshape(Data_temp,numel(Data_temp)/seqL,seqL);
        DataMatrix=DataMatrix';
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
        for k=1:seqL
            [ Score3D(Ind(k+(i-1)*seqL,1),Ind(k+(i-1)*seqL,2),nz), ~] = function_scorespikes( handles.Setup,Stim,DataMatrix(k,:));
        end
    end
    figure(200);set(gcf, 'Position',  [100, 100, Nz*100, numel(Stim.Voltageramp)*100]);
    subplot(numel(Stim.Voltageramp),Nz,(nz+Nz*(v-1)));
    imagesc(Xq(1,:), Yq(:,1), log(Score3D(:,:,nz)'));colorbar;axis image;
    xlabel('X pixels'); ylabel('Y pixels'); title(['Z' num2str(UZ(nz),2) '\mum, #' num2str(j), ' V=' num2str(Stim.Voltageramp(v),2)]);
    Score2D=max(Score3D,[],3);
    axes(handles.axes2); imagesc(Xq(1,:), Yq(:,1), log(Score2D')); xlabel('X pixels'); ylabel('Y pixels'); title(['Maximum Z Projection:' num2str(j)]);colorbar;
end
ToSave.Score{j,v}=Score3D;
Cloud.XYZmapVoltage(:,:,:,j,v)=Score3D;
disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
end
disp(['---Voltage #' num2str(v) '/' num2str(numel(Stim.Voltageramp)) ' finished!']);
end
moveTime = moveTo(handles.Setup.SutterStage,[Stim.CurrentXYZ(1);Stim.CurrentXYZ(2);Stim.CurrentXYZ(3)]);
try
ToSave.Xq=Xq;
ToSave.Yq=Yq;
ToSave.Ind=Ind;
ToSave.type = 'Fine ROI mapping';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
catch; 
end;
if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved');
end
end


% --- simultaneously stimulate multiple targets in 3D
function pushbutton44_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'Stimulate multiple targets in 3D';
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);
if get(handles.checkbox3,'Value') == 1
UX = function_logvec( -str2num(get(handles.edit20,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = function_logvec( -str2num(get(handles.edit21,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = function_logvec( -str2num(get(handles.edit22,'string')),floor(str2num(get(handles.edit25,'string'))));
else
UX = linspace(str2num(get(handles.edit20,'string')),str2num(get(handles.edit47,'string')),floor(str2num(get(handles.edit23,'string'))));
UY = linspace(str2num(get(handles.edit21,'string')),str2num(get(handles.edit48,'string')),floor(str2num(get(handles.edit24,'string'))));
UZ = linspace(str2num(get(handles.edit22,'string')),str2num(get(handles.edit49,'string')),floor(str2num(get(handles.edit25,'string'))));
end
DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;
Nx=floor(str2num(get(handles.edit23,'string')));
Ny=floor(str2num(get(handles.edit24,'string')));
Nz=floor(str2num(get(handles.edit25,'string')));

Stim.Npeaks = floor(str2num(get(handles.edit6,'string'))); % Number of blue light pulses in test
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
if get(handles.checkbox2,'Value') == 0
    Stim.Output(:,5)=0;
%     select = Stim.UT<2*handles.Setup.Scorepikes.sealtestduration.* Stim.UT>handles.Setup.Scorepikes.sealtestduration;
%     Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
    select = Stim.UT<handles.Setup.Scorepikes.sealtestduration;    
    tempOutput=Stim.Output;
    tempOutput(1:end,:)=0;
    tempOutput(select,5)=1;
    queueOutputData(handles.Setup.Daq,tempOutput);
    startForeground(handles.Setup.Daq);
    pause(0.1);
else
    Stim.Output(:,5) =0;
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value')==1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end
DataSave.MultiTargets = {};DataSave.Score={};

% MAP=mean(Cloud.XYZmap,4);
% [counts, bin]=hist(MAP(:),round(numel(MAP)*0.02));
% Threshold=min(bin(counts<round(numel(MAP)*0.02)));%sparse signal: signal pixels should be less than 5% of total pixels.
% [xind,yind,zind]=ind2sub([Nx,Ny,Nz],find(MAP>Threshold));%use func "find", the result is sorted
% CenterX=UX(xind);CenterY=UY(yind);CenterZ=UZ(zind)/handles.Setup.DataAnalysis.Zratio;
% Stim.Targets=[CenterX',CenterY',CenterZ];
% Distance=sqrt(sum(diff(Stim.Targets).^2,2));%calculate the distance between sorted spots
% Ind_temp=find(Distance<abs(UX(1)-UX(2))*4)+1;
% Stim.Targets(Ind_temp,:)=[];

Stim.Targets = xlsread('targets.xlsx');
Ntarget=size(Stim.Targets,1);
handles.Setup.DMD.SequenceControl.RepeatModeValue=Stim.Npeaks;
axes(handles.axes2); hold off; cla;axes(handles.axes5); hold off; cla;
% axes(handles.axes3); scatter(Stim.Targets(:,1), Stim.Targets(:,2),'blue','filled'); xlabel('X(pixel)'); ylabel('Y(pixel)'); title('Targets');
for indcomb=1:Ntarget
    Stim.IndComb{indcomb}=nchoosek(1:Ntarget,indcomb);
    for p=1:size(Stim.IndComb{indcomb},1)
        ic=Stim.IndComb{indcomb}(p,:);
        ix=Stim.Targets(ic,1);
        iy=Stim.Targets(ic,2);
        iz=Stim.Targets(ic,3);
        for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed
         if status == 0; disp('Procedure interrupted'); break; end;
            [DMDFrames] =  function_makespots_ori(handles.Setup,ix,iy,iz,str2num(get(handles.edit19,'string'))*ones(size(ix)));
            handles.Setup = function_feed_DMD(handles.Setup, DMDFrames);
            queueOutputData(handles.Setup.Daq,Stim.Output);
            Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
            Stim.baseline=mean(Data(1:100));
            if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else handles.Setup.Scorepikes.Method=0; end;
            [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
            axes(handles.axes2);  scatter(j, score,'red','filled'); hold on; xlabel('repeat#'); ylabel('Score'); title(['Stimulate ' num2str(indcomb) ' spots']);
            axes(handles.axes5);  plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage');
            DataSave.MultiTargets{p,indcomb,j} = Data;
            DataSave.Score{p,indcomb,j} = score;
            handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
        end
        axes(handles.axes2); hold off; cla;
    end
    disp(['Combination ' num2str(indcomb) '/' num2str(Ntarget) ' finished!']);
end
try
ToSave.type = 'Simultaneous multiple 3D targets';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
catch; end;
if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end
end


% --- Red stimulation.
function checkbox11_Callback(hObject, eventdata, handles)
end



function edit55_Callback(hObject, eventdata, handles)
end

% --- Executes during object creation, after setting all properties.
function edit55_CreateFcn(hObject, eventdata, handles)
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Executes on button press in pushbutton45.
function pushbutton45_Callback(hObject, eventdata, handles)
global status;
status = 2; % 0: interrupt, 2: pause and show dialog window
f = figure;set(f,'Position',[800, 800, 400,200]);
h = uicontrol('Position',[20 20 200 40],'String','Continue',...
              'Callback','uiresume(gcbf)');
uiwait(gcf); 
status = 1;
close(f);
end


% --- Fill Coarse mapping parameters.
function pushbutton46_Callback(hObject, eventdata, handles)
global DAQstate;
global status; status = 1; % 1 if ok to continue
global SaveID; SaveID=0;
global ToSave;
global Stage;
global Cloud;
global StageStatus; StageStatus=0;
DAQstate=[0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.edit6,'string',int2str(1)); % Number of pulses
set(handles.edit7,'string',int2str(40)); % Frequency in Hertz
set(handles.edit8,'string',int2str(4)); % Pulse duration in ms
set(handles.edit9,'string',int2str(5)); % Number of repetitions
set(handles.edit10,'string',int2str(0)); % Delay between repeitions in seconds
set(handles.edit11,'string',num2str(3)); %Stim laser voltage,center (default)
set(handles.edit50,'string',num2str(5)); %Stim laser voltage,edge
set(handles.edit29,'string',num2str(0.09)); %Pre stimulation delay in seconds
set(handles.edit30,'string',num2str(0.8)); %Pulsed lase Duty cycle between 0 and 1
set(handles.edit12,'string',num2str(2.2)); %Voltage sweep start voltage
set(handles.edit13,'string',num2str(3.8));%Voltage sweep End voltage
set(handles.edit14,'string',num2str(3));%Voltage sweep number of steps
set(handles.edit16,'string',num2str(0)); %Targets positions pixels X
set(handles.edit17,'string',num2str(0)); %Targets positions pixels Y
set(handles.edit18,'string',num2str(0)); %Targets positions pixels Z
set(handles.edit19,'string',num2str(50)); %Target radius
set(handles.edit20,'string',num2str(-600)); % PPSFRange of measurements on X axis in pixels,start
set(handles.edit21,'string',num2str(-600));% PPSF Range of measurements on Y axis in pixels,start
set(handles.edit22,'string',num2str(-60));% PPSFRange of measurements on Z axis in pixels,start
set(handles.edit47,'string',num2str(600)); % PPSFRange of measurements on X axis in pixels,end
set(handles.edit48,'string',num2str(600));% PPSF Range of measurements on Y axis in pixels,end
set(handles.edit49,'string',num2str(-60));% PPSFRange of measurements on Z axis in pixels,end
set(handles.edit23,'string',num2str(20));% PPSF number of points on X axis
set(handles.edit24,'string',num2str(20));% PPSF number of points on Y axis
set(handles.edit25,'string',num2str(1));% PPSF number of points on Z axis
set(handles.edit55,'string',num2str(2.5));% Sampling grid
set(handles.checkbox1,'Value', 1);
set(handles.checkbox2,'Value', 0);
end


% --- Executes on button press in pushbutton47.
function pushbutton47_Callback(hObject, eventdata, handles)
global DAQstate;
global status; status = 1; % 1 if ok to continue
global SaveID; SaveID=0;
global ToSave;
global Stage;
global Cloud;
global StageStatus; StageStatus=0;
DAQstate=[0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.edit6,'string',int2str(1)); % Number of pulses
set(handles.edit7,'string',int2str(80)); % Frequency in Hertz
set(handles.edit8,'string',int2str(4)); % Pulse duration in ms
set(handles.edit9,'string',int2str(5)); % Number of repetitions
set(handles.edit10,'string',int2str(0)); % Delay between repeitions in seconds
set(handles.edit11,'string',num2str(3)); %Stim laser voltage,center (default)
set(handles.edit50,'string',num2str(5)); %Stim laser voltage,edge
set(handles.edit29,'string',num2str(0.09)); %Pre stimulation delay in seconds
set(handles.edit30,'string',num2str(0.8)); %Pulsed lase Duty cycle between 0 and 1
set(handles.edit14,'string',num2str(4));%Voltage sweep number of steps
set(handles.edit16,'string',num2str(0)); %Targets positions pixels X
set(handles.edit17,'string',num2str(0)); %Targets positions pixels Y
set(handles.edit18,'string',num2str(0)); %Targets positions pixels Z
set(handles.edit19,'string',num2str(20)); %Target radius
set(handles.edit22,'string',num2str(-120));% PPSFRange of measurements on Z axis in pixels,start
set(handles.edit49,'string',num2str(20));% PPSFRange of measurements on Z axis in pixels,end
set(handles.edit23,'string',num2str(40));% PPSF number of points on X axis
set(handles.edit24,'string',num2str(40));% PPSF number of points on Y axis
set(handles.edit25,'string',num2str(5));% PPSF number of points on Z axis
set(handles.edit55,'string',num2str(2.5));% Sampling grid
set(handles.checkbox1,'Value', 1);
set(handles.checkbox2,'Value', 0);
end


% --- preload patterns for random mapping
function pushbutton50_Callback(hObject, eventdata, handles)
global DAQstate;
global status;
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
status = 1;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
set(handles.slider3,'Value',0);
set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

% ProjMode = function_CheckProjMode_DMD(handles.Setup);
% if ProjMode==2301
%     [handles.Setup]=function_StopProj_DMD(handles.Setup);
%     [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
% end
%default 48x48x20grid
focicases=[20,30,40,48,60,72,80,96,120];
seqLcases=[48,48,48,40,48,40,36,48,48];
Preload.X=load(['MaskCoordinates_mapping\UX.mat']);
Preload.Y=load(['MaskCoordinates_mapping\UY.mat']);
Preload.Z=load(['MaskCoordinates_mapping\UZ.mat']);
NumofSpot=str2num(get(handles.edit56,'string'));
[~,indtemp]=min(abs(focicases-NumofSpot));
NumofSpot=focicases(indtemp);
seqL=seqLcases(indtemp);
if rem(numel(Preload.X.UX),seqL)~=0
    seqL=1;
end
NumofSeq=numel(Preload.X.UX)/(seqL*NumofSpot);

Cloud.Preload.sequenceid=zeros(NumofSeq,1);
disp('Start calculating masks...');
for k=1:NumofSeq
    if status == 0
        disp('Procedure interrupted'); break; 
    elseif status ==2
        f = figure;set(f,'Position',[800, 800, 400,200]);
        h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                      'Callback','uiresume(gcbf)');
        uiwait(gcf); 
        status = 1;
        close(f);
    end
    DMDFrames_final = gpuArray(false(handles.Setup.DMD.LX,handles.Setup.DMD.LY,...
    handles.Setup.PointCloud.divider*seqL));
        for i=1:seqL
            if status == 0
                disp('Procedure interrupted'); break; 
            elseif status ==2
                f = figure;set(f,'Position',[800, 800, 400,200]);
                h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                              'Callback','uiresume(gcbf)');
                uiwait(gcf); 
                status = 1;
                close(f);
            end
                tempx=Preload.X.UX((1+(k-1)*seqL+(i-1)*NumofSpot):((k-1)*seqL+i*NumofSpot));
                tempy=Preload.Y.UY((1+(k-1)*seqL+(i-1)*NumofSpot):((k-1)*seqL+i*NumofSpot));
                tempz=Preload.Z.UZ((1+(k-1)*seqL+(i-1)*NumofSpot):((k-1)*seqL+i*NumofSpot));
                [DMDFrames] = function_makespots_ori(handles.Setup,tempx,tempy,tempz,ones(size(tempx))*str2num(get(handles.edit19,'string')));
                DMDFrames_final(:,:,((i-1)*handles.Setup.PointCloud.divider+1):(i*handles.Setup.PointCloud.divider))=DMDFrames;
        end
            [handles.Setup,Cloud.Preload.sequenceid(k)]= function_StoreImages_DMD(handles.Setup, uint8(gather(DMDFrames_final))*255);
end
    disp('Random patterns for 4D mapping are loaded!');
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
end

% --- Project preloaded random patterns for mapping
function pushbutton51_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'Digital random mapping';
outputSingleScan(handles.Setup.Daq,DAQstate);
% set(handles.slider3,'Value',0);
% set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end

focicases=[20,30,40,48,60,72,80,96,120];
seqLcases=[48,48,48,40,48,40,36,48,48];
Preload.X=load(['MaskCoordinates_mapping\UX.mat']);
Preload.Y=load(['MaskCoordinates_mapping\UY.mat']);
Preload.Z=load(['MaskCoordinates_mapping\UZ.mat']);
NumofSpot=str2num(get(handles.edit12,'string'));
[~,indtemp]=min(abs(focicases-NumofSpot));
NumofSpot=focicases(indtemp);
seqL=seqLcases(indtemp);
if rem(numel(Preload.X.UX),seqL)~=0
    seqL=1;
end
NumofSeq=numel(Preload.X.UX)/(seqL*NumofSpot);

UX = unique(Preload.X.UX);
UY = unique(Preload.Y.UY);
UZ = unique(Preload.Z.UZ);

DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;
Nx=numel(UX);Ny=numel(UY);Nz=numel(UZ);

Stim.Npeaks = seqL;% instead of repeat one holograph, change holograph equals to the sequence length
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
Stim.CropMask=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.CropMask = Stim.CropMask+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+i/Stim.FreqHZ);
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,5)=0;
select = Stim.UUT<handles.Setup.Scorepikes.sealtestduration;
Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
[PXX,PYY,PZZ] = ndgrid(UX,UY,UZ);
DataSave.PXX = PXX(:);
DataSave.PYY = PYY(:);
DataSave.PZZ = PZZ(:);

DataSave.XYZ = {}; 
load('MaskCoordinates_mapping/Ind.mat');
Score4D=zeros(Nx,Ny,Nz,str2num(get(handles.edit9,'string')));
Cloud.ScoreMap=zeros(Nx,Ny,Nz);
handles.Setup.DMD.SequenceControl.RepeatModeValue=1;

axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed   
    handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        Currentsequenceid=Cloud.Preload.sequenceid(i);
        handles.Setup = function_StartProj_DMD(handles.Setup, Currentsequenceid);
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        DataSave.XYZ{i,j}=Data;
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
        axes(handles.axes5);plot(Stim.UUT,Data);xlabel('Time s'); ylabel('Voltage');title([num2str(seqL) ' spot measurements']);
        disp(['Finish #' num2str(i) '/' num2str(NumofSeq) ' of repeat #' num2str(j)]);
    end
    disp(['Repetition #' num2str(j) '/' get(handles.edit9,'string') ' finished!']);
end
    for i=1:NumofSeq
        if status == 0
            disp('Procedure interrupted'); break; 
        elseif status ==2
            f = figure;set(f,'Position',[800, 800, 400,200]);
            h = uicontrol('Position',[20 20 200 40],'String','Continue',...
                          'Callback','uiresume(gcbf)');
            uiwait(gcf); 
            status = 1;
            close(f);
        end
        Data_temp=DataSave.XYZ{i,j}.*Stim.CropMask';
        Stim.baseline=mean(DataSave.XYZ{i,j}(1:50));
        Data_temp(Data_temp==0)=[];
        if rem(numel(Data_temp),seqL)~=0
           Data_temp=cat(1,Data_temp,0);
        end
        DataMatrix=reshape(Data_temp,numel(Data_temp)/seqL,seqL);
        DataMatrix=DataMatrix';
        if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else Setup.Scorepikes.Method=0; end;
        for k=1:seqL
            indx=Ind((1+(k-1)*seqL+(i-1)*NumofSpot):((k-1)*seqL+i*NumofSpot),1);
            indy=Ind((1+(k-1)*seqL+(i-1)*NumofSpot):((k-1)*seqL+i*NumofSpot),2);
            indz=Ind((1+(k-1)*seqL+(i-1)*NumofSpot):((k-1)*seqL+i*NumofSpot),3);
            [ Score4D(indx,indy,indz,j), ~] = function_scorespikes( handles.Setup,Stim,DataMatrix(k,:));
        end
    end
    axes(handles.axes2); imagesc(UY, UX, sum(squeeze(Score4D(:,:,Nz/2,1:j)),3)); xlabel('X pixels'); ylabel('Y pixels'); title(['XY PPSF mean 1:' num2str(j)]);
    axes(handles.axes3); imagesc(UZ, UX, sum(squeeze(Score4D(:,Ny/2,:,1:j)),3)); xlabel('Z pixels'); ylabel('X pixels'); title(['XZ PPSF mean 1:' num2str(j)]);
    ScoreMap=sum(Score4D,4);
    if isempty(find(ScoreMap, 1))
       disp('No spike is found in the mapping result!');
    else
        [counts,edges] = histcounts(ScoreMap);
        thres=numel(counts)-1;
        while sum(counts(thres:end))<500
            thres=thres-1;
        end
        temp=sub2ind(size(ScoreMap),Ind(:,1),Ind(:,2), Ind(:,3));
        [Indnonzero,timeSeq,~]=intersect(temp,find(ScoreMap>edges(thres+1)),'stable');
        timeMap=zeros(size(ScoreMap));
        timeMap(Indnonzero)=timeSeq;
        figure(300);set(gcf, 'Position',  [100, 100, 500, 400]);imshow3D(timeMap);
    end
try
ToSave.type = 'Digital random mapping';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
ToSave.Score = Score4D;
ScoreMap(ScoreMap<=edges(thres+1))=0;
Cloud.ScoreMap=ScoreMap;
figure(100);set(gcf, 'Position',  [100, 100, 500, 400]);imshow3D(ScoreMap);
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
catch; 
end;

% ToSave.Score = Score4D;
% figure(200);imshow3D(mean(Score4D,4));
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);

if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end

end

function edit56_Callback(hObject, eventdata, handles)
end

% --- # of foci to stimulate simultaneously
function edit56_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
end


% --- Multi-targets illumination simultaneously from previous random
% mapping
function pushbutton52_Callback(hObject, eventdata, handles)
global DAQstate; global status;status = 1;
DAQstate = [0 0 0 0 0 0 0];
global ToSave;
global Cloud;
global SaveID; SaveID=SaveID+1;
ToSave.DMDSTATE = 'Digital random mapping';
outputSingleScan(handles.Setup.Daq,DAQstate);
% set(handles.slider3,'Value',0);
% set(handles.slider2,'Value',0);
set(handles.edit3,'string',0);
set(handles.edit4,'string',0);

ProjMode = function_CheckProjMode_DMD(handles.Setup);
if ProjMode==2301
    [handles.Setup]=function_StopProj_DMD(handles.Setup);
    [handles.Setup] = function_DMDProjMode(handles.Setup,'slave');
end

if isempty(find(Cloud.ScoreMap, 1))
    disp('No spike is found in the mapping result!');
else
    ScoreMap=Cloud.ScoreMap;
    [Indx,Indy,Indz]=ind2sub(size(ScoreMap),find(ScoreMap));
end

Preload.X=load(['MaskCoordinates_mapping\UX.mat']);
Preload.Y=load(['MaskCoordinates_mapping\UY.mat']);
Preload.Z=load(['MaskCoordinates_mapping\UZ.mat']);

UX = unique(Preload.X.UX);
UY = unique(Preload.Y.UY);
UZ = unique(Preload.Z.UZ);

X=UX(Indx);
Y=UY(Indy);
Z=UZ(Indz);

DataSave.UX = UX;
DataSave.UY = UY;
DataSave.UZ = UZ;
DataSave.X=X;
DataSave.Y=Y;
DataSave.Z=Z;

Stim.Npeaks = 1;% instead of repeat one holograph, change holograph equals to the sequence length
Stim.DurationMS = str2num(get(handles.edit8,'string')); % Pulse duration in ms
Cloud.CycleLength=Stim.DurationMS/1000;
Stim.FreqHZ= str2num(get(handles.edit7,'string')); % Frequency of optogenetic stimulation in Hz
Stim.FreqHZ=1000/(round((1000/Stim.FreqHZ)/Stim.DurationMS)*Stim.DurationMS);
Stim.Voltage = str2num(get(handles.edit11,'string'));
Stim.Voltageramp = linspace(str2num(get(handles.edit12,'string')),str2num(get(handles.edit13,'string')),floor(str2num(get(handles.edit14,'string')))); %Voltage ramp to test how much light is needed to stim...
Stim.DelayBorder=str2num(get(handles.edit29,'string')); % In seconds, delay before and after stim train
Stim.DutyCycle = str2num(get(handles.edit30,'string')); %Fraction 0 to 1 of illumianted Fourier circle warning for reoslution
Stim.TargetRadius = str2num(get(handles.edit19,'string')); %Radius of the target once we know location in dmd pixels
Stim.Totalduration = 2*Stim.DelayBorder + Stim.Npeaks/Stim.FreqHZ;
[Setup.XX,Setup.YY] = ndgrid(linspace(-handles.Setup.DMD.LX/2,handles.Setup.DMD.LX/2,handles.Setup.DMD.LX),linspace(-handles.Setup.DMD.LY/2,handles.Setup.DMD.LY/2,handles.Setup.DMD.LY));
if get(handles.checkbox8,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0.2,2.7];
    Cloud.AnlgeMagnitudeOffset=[0.2,2.7];
elseif get(handles.checkbox11,'Value') == 1
    handles.Setup.PointCloud.GalvoOffsetVoltage=[-0.2,-0.6];
    Cloud.AnlgeMagnitudeOffset=[-0.2,-0.6];
else
    handles.Setup.PointCloud.GalvoOffsetVoltage=[0,0];
    Cloud.AnlgeMagnitudeOffset=[0,0];
end
[ Stim.UT,Stim.Output, Stim.Subclock ] = function_makeCycleClock( handles.Setup ,Cloud);
Stim.Output(:,7) =double(Stim.Subclock<Stim.DutyCycle);
if Stim.DutyCycle<0.5
    Stim.Output(:,1) =double(Stim.Subclock<0.5);
else
    Stim.Output(:,1) =double(Stim.Subclock<Stim.DutyCycle);
end
Stim.NumberCycles = floor(Stim.Totalduration/Cloud.CycleLength);
Stim.Output = repmat(Stim.Output,[Stim.NumberCycles 1]);
[Stim.LN,Stim.LX] = size(Stim.Output);
Stim.UUT = linspace(0,Stim.NumberCycles*Stim.UT(end), Stim.LN);
Stim.Array = Stim.UUT-Stim.UUT;
Stim.Array1=Stim.Array;
Stim.CropMask=Stim.Array;
for i = 1:Stim.Npeaks
    Stim.Array = Stim.Array+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.Array1 = Stim.Array1+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+Stim.DurationMS/1000+(i-1)/Stim.FreqHZ);
    Stim.CropMask = Stim.CropMask+double(Stim.UUT>Stim.DelayBorder+(i-1)/Stim.FreqHZ).*double(Stim.UUT<Stim.DelayBorder+i/Stim.FreqHZ);
end
Stim.Baseline = Stim.Output(:,1);
if get(handles.checkbox8,'Value') == 1 || get(handles.checkbox11,'Value') == 1
    Stim.Output(:,1)=0;
    Stim.Output(:,2) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.nonzerovalues = find(Stim.Output(:,2));
else   
    Stim.Output(:,1) = Stim.Voltage*Stim.Baseline.*Stim.Array';
    Stim.Output(:,2)=0;
    Stim.nonzerovalues = find(Stim.Output(:,1));
end
Stim.Output(:,5)=0;
select = Stim.UUT<handles.Setup.Scorepikes.sealtestduration;
Stim.Output(select,5) = handles.Setup.Scorepikes.sealtestvalue;
Stim.Output(:,6)=Stim.Baseline.*Stim.Array1';
Stim.Output(:,7)=Stim.Output(:,7).*Stim.Array1';
Cloud.CycleLength= str2num(get(handles.edit44,'string'))/1000;
Cloud.divider = floor(str2num(get(handles.edit42,'string')));
Cloud.AngleMagnitude = str2num(get(handles.edit43,'string'));
[PXX,PYY,PZZ] = ndgrid(UX,UY,UZ);
DataSave.PXX = PXX(:);
DataSave.PYY = PYY(:);
DataSave.PZZ = PZZ(:);

DataSave.XYZ = {}; 
handles.Setup.DMD.SequenceControl.RepeatModeValue=1;

axes(handles.axes2); hold off; cla;axes(handles.axes3); hold off; cla;axes(handles.axes4); hold off; cla;axes(handles.axes5); hold off; cla;
 for j = 1:floor(str2num(get(handles.edit9,'string'))) %do as many repetitions as needed
     if status == 0; disp('Procedure interrupted'); break; end
     if numel(X)>500 disp('Too many ROIs!'); break; end
        [DMDFrames] =  function_makespots_ori(handles.Setup,X,Y,Z,Stim.TargetRadius*ones(size(X)));
        handles.Setup = function_feed_DMD(handles.Setup, DMDFrames);
        queueOutputData(handles.Setup.Daq,Stim.Output);
        Data=startForeground(handles.Setup.Daq);%RawData is the analog input signal from AI16 pin
        Stim.baseline=mean(Data(1:100));
%         if get(handles.checkbox2,'Value') == 1;handles.Setup.Scorepikes.Method = 1; else handles.Setup.Scorepikes.Method=0; end;
%         [score,odata] = function_scorespikes(handles.Setup,Stim, Data );
%         axes(handles.axes2);  scatter(j, score,'red','filled'); hold on; xlabel('repeat#'); ylabel('Score'); title(['Stimulate ' num2str(indcomb) ' spots']);
        axes(handles.axes5);  plot(Stim.UUT,odata);xlabel('Time s'); ylabel('Voltage');
        DataSave.XYZ{j} = Data;
        handles.Setup.DMD.alp_returnvalue = calllib('DMD', 'AlpProjHalt', handles.Setup.DMD.deviceid);
 end
try
ToSave.type = 'Multi-target illu based on digital mapping';
ToSave.Stim = Stim;
ToSave.status = status;
ToSave.Data = DataSave;
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);
catch 
end
DAQstate = [0 0 0 0 0 0 0];
outputSingleScan(handles.Setup.Daq,DAQstate);

if get(handles.checkbox1,'Value') == 1
    filename = [handles.Setup.SavingPath, get(handles.edit31,'string'), '_', int2str(SaveID), '_.mat'];
    save(filename,'ToSave');
    disp('Data Saved')
end
end
