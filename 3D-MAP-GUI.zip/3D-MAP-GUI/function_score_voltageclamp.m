function [ score, odata, spikeremoveflag] = function_score_voltageclamp( Setup,Stim,data,spikeremoveflag)
%Calculate the score of voltage clamp. No spike.
%   Detailed explanation goes here
Fs = 1/(Stim.UT(2)-Stim.UT(1));
Setup.Scorepikes.SpikeSTDDetectionthreshold=10;
Setup.RCCutoffFrequencyHz=1000;
Setup.Scorepikes.MinPeakDistance=0.003;
Setup.Scorepikes.baselineduration=0.04;
Setup.Scorepikes.Photocurrentwindowduration=0.01;
% figure(1);plot(data);drawnow;
    odata = data;
%     k=(mean(data(end-4:end))-mean(data(1:5)))/(numel(data)-1);
%     baseline=k*((1:numel(data))-1)+mean(data(1:5));
%     if size(baseline,1)~=size(data,1)
%         baseline=baseline';
%     end
    
%     data = data-baseline;
%     figure(1);plot(data);drawnow;
    nonzerovalues = find(Stim.Output(:,1));%change to (:,1) if stim light is blue, (:,2) for yellow stim
if numel( nonzerovalues)==0
    score = 0;
else  
    if numel(data)<600
        score = max(data(50:end));
    else
        score = max(data(150:600));
    end
%     [val,ind] = max(abs(data(100:800)));
%     ind=ind+99;
%     if val>0.03 && Stim.UUT(ind)<0.01
%     score=Stim.UUT(ind);
%     else
%         score=0;
%     end
%     if score>5*mean(baseline)
%         score=0;
%     end
    
end
end

