%% 3D-MAP simultation
% Reference: Xue, Y., Waller, L., Adesnik, H. & Pegard, N. ...
% Three-dimensional Multi-site Random Access Photostimulation (3D-MAP). 
% bioRxiv 2020.06.28.176503 (2020) doi:10.1101/2020.06.28.176503
% Yi Xue (xueyi@berkeley.edu), June 2021

clear all;close all;clc;

%Define simulation propoerties
lambda = 0.473E-6;          % wavelength [m]
M = 20;                     % magnification of the objective lens
ps = 4e-6;                  % Pixel Size [m]
fA = 0.180 ;                % Focal length lens second lens (tube lens)[m]
numberoflegs = 10;          % number of DMD masks and projection angles to generate a focus

NA = 1;                     % Numerical aperture of our objective
fB = fA/M ;                 % Focal length of the objective [m]
n = 1.33;                   % Refractive index of immersion medium
angularrange = 0.2;         % Between 0 and 1, the galvo magnitude to control theta. 0 is center, 1 is full circle covering objective back aperture
zres = 0.3e-6;                % Define the stepsize in the z-axis [m]
LX = 256;                   % Defines the number of pixels in the x-axis of the simulation
LY = 256;                   % Defines the number of pixels in the y-axis of the simulation
LZ = 200;                   % Define the z-layer of the simulation

apertureradius = fB*tan(asin(NA/n)); %The NA of the Objective defines a circular aperture size

%Create coordinates and mesh axis for fast calculation
UX = 1:LX;UX = UX*ps;UX = UX-mean(UX);
UY = 1:LY;UY = UY*ps;UY = UY-mean(UY);
[XX,YY] = ndgrid(UX,UY);
Depths = linspace(-zres*LZ/2,zres*LZ/2, LZ);
%% Generate DMD amplitude masks
% Generate two foci at [0,0,20] (pixel) and [30,50,-10] with a radius of 5
% and 3 pixels, respectively. The coordinates and radius can be changed.
x=[0, 30];%focus location coordinate: x [pixel]
y=[0, 50];%focus location coordinate: y [pixel]
DefocusingRadius=[20, -10];%focus location coordinate: z [pixel]
TargetRadius=[5, 3];%aperture radius, [pixel]
% kick off spots: where don't want any light. Empty= no kick
xyz_kick=[]; % xyz coordinates of the kick off spots
r_kick=[];
%parameters for computing DMD masks
Setup.PointCloud.AngleMagnitude=angularrange;
Setup.PointCloud.divider=numberoflegs;
Setup.DMD.LX=LX;
Setup.DMD.LY=LY;
% compute the DMD masks to generate this focus:
Setup.PointCloud.phiDMD=-pi/5; % phi_DMD in Fig. 1 of the reference paper, change this value to change the relative angle between DMD and scanning mirrors
[DMDFrames, TotalFrame] = function_makespots_ori_cpu(Setup,x,y,DefocusingRadius,TargetRadius);
%% Generate projection angles by scanning mirrors
% Initialize amplitude and phase in z = 0
phiGalvo=pi; % phi_SM in Fig. 1 of the reference paper
I_temp=zeros(LX,LY,LZ,numberoflegs,'single'); % image of each beam
ang=angularrange*apertureradius/fA; % theta
TDMAP=linspace(0+phiGalvo,2*pi+phiGalvo,numberoflegs+1); % projection angles
TDMAP = TDMAP(1:end-1);
A=(2*pi*ang/lambda)*cos(TDMAP); % angle of SMx
B=(2*pi*ang/lambda)*sin(TDMAP); % angle of SMy
%% propagate light from the initial in-focus plane to defocus planes
for k=1:numberoflegs % compute one beam at a time
    Phase = A(k)*XX+B(k)*YY; % Initial phase modulated by the scanning mirrors
    Field1 = sqrt(DMDFrames(:,:,k)).*exp(1i*Phase); % Compute Initial complex field

    % Here, we compute the first propagated field to Fourier space, rediefine a
    %new system of coordinates, and the corresponding axes
    [Field2,psFX,psFY] = function_lens(Field1,ps,ps,fA,lambda);
    UFX = 1:LX;UFX = UFX*psFX;UFX = UFX-mean(UFX);
    UFY = 1:LY;UFY = UFY*psFY;UFY = UFY-mean(UFY);
    [FXX,FYY] = ndgrid(UFX,UFY);

    Mask = double(FXX.^2+FYY.^2<apertureradius^2);% pupil

    % Apply Mask (multiply by zero the amplitude anywhere except inside aperture)
    Field2=Field2.*Mask;
    % light passes another lens. We propagate the field in the Fourier
    % domain to the field in the real domain
    [Field3,psX3,psY3] = function_lens(Field2,psFX,psFY,fB,lambda);
    UX3 = 1:LX;UX3 = UX3*psX3;UX3 = UX3-mean(UX3);
    UY3 = 1:LY;UY3 = UY3*psY3;UY3 = UY3-mean(UY3);
    [XX3,YY3] = ndgrid(UX3,UY3);
    
    % propagate light from in-focus plane to the defocus planes in 3D
    for j = 1:LZ
        field = function_propagate(Field3,lambda,Depths(j),psX3,psY3);
        I_temp(:,:,j,k) = abs(field).^2;
    end
end
stack=sum(I_temp,4);
%% kick off DMD patterns if needed
if ~isempty(xyz_kick)
    K=[LX/2+xyz_kick(:,1),LY/2+xyz_kick(:,2),LZ/2+xyz_kick(:,3)];
    Imax=max(stack(:));
    for m=1:size(xyz_kick,1)
        %kick off spots if the intensity in the black area is larger than
        %0.1 of the maximum intensity of foci
        Imax_loc=max(max(stack(K(m,1)-r_kick(m):K(m,1)+r_kick(m),...
            K(m,2)-r_kick(m):K(m,2)+r_kick(m),K(m,3))));
        if Imax_loc>0.1*Imax
            [x_loc,y_loc]=ind2sub([LX,LY],find(stack(:,:,K(m,3))==Imax_loc));
            [~,indkick]=max(squeeze(I_temp(x_loc,y_loc,K(m,3),:)));
            DMDFrames(:,:,indkick)=[];
            indtemp=1:numberoflegs;
            indtemp(indtemp==indkick)=[];
            stack=sum(I_temp(:,:,:,indtemp),4);
        end
    end
    TotalFrame=zeros(LX,LY);
    for j=1:size(DMDFrames,3)
        TotalFrame = max(TotalFrame ,j*DMDFrames(:,:,j));
    end
end
%% plot results
figure(1);
set(gcf,'position',[100,100,800,200]);
subplot(1,3,1);
imagesc(fliplr(flipud(TotalFrame))); axis image;
title('Total DMD pattern')
axis off;
subplot(1,3,2);
c = linspace(1,10,length(A));
plot(cos(interp(TDMAP,100)),sin(interp(TDMAP,100)),'r--');
hold on
scatter(cos(TDMAP),sin(TDMAP),30,c,'filled');
title('projection angle by SM')
hold off;
axis square;
axis off;
subplot(1,3,3);
plot(pi*cos(TDMAP),'color',[217/255,83/255,25/255],'linewidth',1);
hold on;
plot(pi*sin(TDMAP),'color',[237/255,177/255,32/255],'linewidth',1);
xlabel('time sequence');
ylabel('angle of each SM');
axis tight;
% view 3D stack
figure(2);imshow3D(stack);