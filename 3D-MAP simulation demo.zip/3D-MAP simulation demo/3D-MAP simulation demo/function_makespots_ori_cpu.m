function [DMDFrames, TotalFrame] = function_makespots_ori_cpu(Setup,x,y,DefocusingRadius,TargetRadius)
voltageadjust = Setup.PointCloud.AngleMagnitude*2; %2 volts: maximum voltage to scanning mirrors
divider=Setup.PointCloud.divider;
phi=Setup.PointCloud.phiDMD;
DMDFrames = zeros(Setup.DMD.LX,Setup.DMD.LY,divider);
TotalFrame=zeros(Setup.DMD.LX,Setup.DMD.LY);
[XX,YY] = ndgrid(linspace(-Setup.DMD.LX/2,Setup.DMD.LX/2,Setup.DMD.LX),linspace(-Setup.DMD.LY/2,Setup.DMD.LY/2,Setup.DMD.LY));
LN = numel(x);

for k = 1:LN
    for j=1:divider
        DMDFrames(:,:,j)=DMDFrames(:,:,j)+double(((XX-x(k)-voltageadjust*...
            DefocusingRadius(k)*cos(j*2*pi/divider+phi)).^2+...
            (YY-y(k)-voltageadjust*DefocusingRadius(k)*sin(j*2*pi/divider+phi)).^2)<TargetRadius(k)^2); %Cdot
        TotalFrame = max(TotalFrame ,j*DMDFrames(:,:,j));
    end
end
end

