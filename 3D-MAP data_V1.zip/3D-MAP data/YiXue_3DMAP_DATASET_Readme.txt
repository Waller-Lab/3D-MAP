﻿This Three-dimensional Multi-site Random Access Photostimulation (3D-MAP)readme.txt file was generated on 10/21/2021 by Yi Xue


GENERAL INFORMATION

1. Title of Dataset: Three-dimensional Multi-site Random Access Photostimulation (3D-MAP)

2. Author Information
	A. Principal Investigator Contact Information
		Name: Prof. Hillel Adesnik
		Institution: University of California, Berkeley
		Address: 205 Life Science Addition, Berkeley, CA 94720, U.S.A
		Email: hadesnik@berkeley.edu

	B. Associate or Co-investigator Contact Information
		Name: Prof. Nicolas Pégard
		Institution: University of North Carolina, Chapel Hill
		Email: pegard@unc.edu

	C. Alternate Contact Information
		Name: Dr. Yi Xue
		Institution: University of California, Berkeley
		Address: 206 Life Science Addition, Berkeley, CA 94720, U.S.A
		Email: xueyi@berkeley.edu

3. Date of data collection (single date, range, approximate date): July 2019 - April 2021

4. Geographic location of data collection: 206 Life Science Addition, Berkeley, CA 94720, U.S.A

5. Information about funding sources that supported the collection of the data: This work was supported by DARPA N66001-17-C-40154 to H.A. and L.W., as well as NIH UF1NS107574 to H.A. and L.W. This work was supported by the New York Stem Cell Foundation. H.A. is a New York Stem Cell Foundation Robertson Investigator. Y. X. is a Weill Neurohub Fellow. This work was funded by the Gordon and Betty Moore Foundation's Data-Driven Discovery Initiative through Grant GBMF4562 to L.W, and by the Burroughs Wellcome Fund, Career Award at the Scientific Interface (5113244) to N.P..


SHARING/ACCESS INFORMATION

1. Licenses/restrictions placed on the data:  Creative Commons Zero waiver by Dryad

2. Links to publications that cite or use the data: https://www.biorxiv.org/content/10.1101/2020.06.28.176503v3

3. Links to other publicly accessible locations of the data: N/A

4. Links/relationships to ancillary data sets: N/A

5. Was data derived from another source? No
	A. If yes, list source(s): 

6. Recommended citation for this dataset: Xue, Y., Waller, L., Adesnik, H., & Pegard, N. (2020). Three-dimensional Multi-site Random Access Photostimulation (3D-MAP). In bioRxiv (p. 2020.06.28.176503). https://doi.org/10.1101/2020.06.28.176503


DATA & FILE OVERVIEW

1. File List: 
Folders:Fig2, Fig3, Fig4, Fig5, Fig6. 
Each folder contains data in the corresponding plot in the paper. Files are labeled by figure number and a brief introduction (example, Fig2b_PSF_xplot.fig is the raw image of Fig. 2b in the paper). 


2. Relationship between files, if important: N/A

3. Additional related data collected that was not included in the current data package: N/A

4. Are there multiple versions of the dataset? No
	A. If yes, name of file(s) that was updated: 
		i. Why was the file updated? 
		ii. When was the file updated? 


METHODOLOGICAL INFORMATION

1. Description of methods used for collection/generation of data: Data are collected by imaging and electrophysiology. 

2. Methods for processing the data: Details about data processing are described in the paper when mention the figures. 

3. Instrument- or software-specific information needed to interpret the data: We suggest you to use MATLAB 2017a or later version to open fig and mat files, use ImageJ 1.53e or later version to open tiff files, and use Adobe Acrobat Pro DC 2021.007.20095 or later version to open pdf files.

4. Standards and calibration information, if appropriate: N/A

5. Environmental/experimental conditions: N/A

6. Describe any quality-assurance procedures performed on the data: N/A

7. People involved with sample collection, processing, analysis and/or submission: Yi Xue, Hillel Adesnik


DATA-SPECIFIC INFORMATION FOR: 
Fig2/Fig2b_PSF_xplot.fig: PSF measured along the x-axis. Data for Fig. 2b.
Fig2/Fig2c_PSF_zplot.fig: PSF measured along the z-axis. Data for Fig. 2c. 
Fig2/Fig2d_5x5spots: This folder contains 3D image stack for 5x5 spots array shown in Fig. 2d.
Fig2/Fig2f_Scattering PSF: This folder contains data for the 8 subplots in Fig. 2f.
Fig2/Fig2g_xplot of scattering PSF_473nm: This folder contains data for the 4 line plots in Fig. 2g, showing PSF measured through scattering at 473nm wavelength in x-axis.
Fig2/Fig2h_zplot of scattering PSF_473nm: This folder contains data for the 4 line plots in Fig. 2h, showing PSF measured through scattering at 473nm wavelength in z-axis.
Fig2/Fig2i_PlotallPSF_x_635.fig: This fig plot contains data for Fig. 2i, showing PSF measured through scattering at 635nm wavelength in x-axis.
Fig2/Fig2j_PlotallPSF_z_635.fig: This fig plot contains data for Fig. 2j, showing PSF measured through scattering at 635nm wavelength in z-axis.

Fig3/Fig3b-c_photocurrent_average.fig: This fig plot contains data for Fig. 3b and Fig. 3c, showing the physiological PSF along the x-axis and z-axis.
Fig3/Fig3d_represent photocurrent_rawdata_woAverage_10-4-19-BrainSlice-A-3Drandom.fig: This fig plot contains raw data of Fig. 3d without averaging showing representative traces of photocurrent measurements.
Fig3/Fig3e-f_SingleLineSpikeplot_allcells_SEM_BrainSlice.pdf: This file contains the spike probability plots in Fig. 3e-f. 
Fig3/Fig3g_represent brainsliceSpike_rawdata_071019c_xzspikes2_32_x_Z_7.mat: Data for Fig. 3g.
Fig3/Fig3h-i_SingleLineSpikeplot_allcells_SEM_invivo.pdf: This file contains the spike probability plots in Fig. 3h-i, taken from in vivo mouse brain.
Fig3/Fig3j_represent invivio_rawdata_072319g_L1_spikes_14.mat: Data for Fig. 3j.

Fig4/Fig4b_3DMAP_Widefield.tif: This tif file contains data for Fig. 4b, showing the widefield fluorescence image of the brain slice. 
Fig4/Fig4c_coarse mapping_emx_cre_ChroMES273A_112019h_6_hotmap.fig: This fig file contains the data for the coarse mapping of the synaptic connections, as shown in Fig. 4c.
Fig4/Fig4d map and trace: This folder contains the mapping figures and the representative traces in Fig. 4d.
Fig4/Fig4e_data_unit nA_allpower_emx_cre_ChromeS273A_112019h_11.mat: This mat file contains data for Fig. 4e. The unit of the value in the matrix is nA while the value shows in the paper is converted to pA.
Fig4/Fig4f roi traces: This folder contains the traces in the regions of interest shown in Fig. 4f.
Fig4/Fig4g representative traces: This folder contains the data for each representative traces in Fig. 4g.

Fig5/Fig5c_emx-cre;gad67-gfp;syn-dio-Chrimston_L5_022820d_34.mat: This mat file contains data for Fig. 5c, showing the excitation connection map. The matrix is in 4D where the first 3 dimensions are x, y, and z, and the 4th dimension is power level.
Fig5/Fig5d_emx-cre;gad67-gfp;syn-dio-Chrimston_L5_022820d_35.mat: This mat file contains data for Fig. 5d, showing the inhibition connection map. The matrix is in 4D where the first 3 dimensions are x, y, and z, and the 4th dimension is power level.

Fig6/Fig6b brainslice control exp: This folder contains two fig files of Fig. 6b, showing the calcium activity with and without TTX. 
Fig6/Fig6d power test: This folder contains data for the 4 subplots in Fig. 6d, showing the result of power test.
Fig6/Fig6e_all_optical_invivo_PPSF_x_10cells.fig: This fig plot contains data for in vivo all-optical PPSF along the x-axis in Fig. 6e, averaged across 10 cells.
Fig6/Fig6e_all_optical_invivo_PPSF_z_10cells.fig: This fig plot contains data for in vivo all-optical PPSF along the z-axis in Fig. 6e, averaged across 10 cells.
Fig6/Fig6f_4-2-21_CoChR_RCaMP1a_invivo_mouse4_e_overlap3Dimage_v2_MZP.tif: This tif file contains data of Fig. 6f, showing the maximum intensity projection of the widefield 3D image stack.
Fig6/Fig6g_4-2-21_CoChR_RCaMP1a_invivo_mouse4_e_72_dF2D_allROI_mean_v2.fig: This fig file contains data for Fig. 6g, showing the calcium activity of the neurons in Fig. 6f.
Fig6/Fig6h_4-21-21 CoChR_RCaMP_invivo_mouse4_c_82_dF2D_permute_mean_32target.fig: This fig file contains data for Fig. 6h, showing the calcium activity of 32 neurons under selective photo-stimulation.
Fig6/Fig6i_4-21-21 CoChR_RCaMP_invivo_mouse4_c_82__xcorr_32target.fig: This fig file contains data for Fig. 6i, showing the cross-correlation between the calcium traces in Fig. 6h. 




 

